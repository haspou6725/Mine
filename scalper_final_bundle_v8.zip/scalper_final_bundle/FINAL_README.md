# راهنمای نهایی Scalper Meme+ v6.4

برای اجرا، ZIP را Extract کنید و فقط روی این فایل دوبار کلیک کنید:

```bat
START_ONE_CLICK.bat
```

`START.bat` برای سازگاری باقی مانده و همان لانچر اصلی را اجرا می‌کند.

## خروجی‌های مهم

- Backend: `http://127.0.0.1:8787`
- Streamlit: `http://127.0.0.1:8501`
- Health: `http://127.0.0.1:8787/api/health`
- Safety: `http://127.0.0.1:8787/api/safety`

## نکته بسیار مهم

این پروژه فقط آموزشی/تحلیلی/Simulation است. هیچ معامله واقعی انجام نمی‌دهد. هیچ route اجرای سفارش در بک‌اند فعال وجود ندارد و `LiveExecutor` عمداً credentials یا order options قبول نمی‌کند.

## تست و دیگنوستیک

بعد از اجرای اولیه می‌توانید این فایل‌ها را اجرا کنید:

```bat
RUN_TESTS.bat
RUN_DIAGNOSTIC.bat
```

آخرین وضعیت تست بسته:

```text
compileall: PASS
pytest: pending latest test run, 1 warning
project_audit quick/full: PASS, 0 findings
```

گزارش کامل اصلاحات در فایل زیر است:

```text
ZERO_TO_100_OPTIMIZATION_REPORT.md
```

## Update 6.4.1 — Signal tuning and web navigation fix

- Balanced live signal defaults applied: `score_threshold=78`, `min_volume_spike_for_trigger=1.70`, `max_spread_pct=0.22`, `min_depth_1pct_usd=70000`, `early_confirm_threshold=72`, `trap_threshold=62`.
- Web tabs are now hash-aware and browser Back/Forward friendly.
- Added quick `بازگشت به Signals` button.
- CSV export now opens/downloads without replacing the app page.
- `/api/signals` now respects the current saved `score_threshold` when `min_score` is not explicitly provided.

See `SIGNAL_TUNING_AND_UI_FIX_REPORT.md` for details.
