from app.data.binance_futures import scan_symbols

matches = scan_symbols(price_lt=1.0, vol24_gt=100_000.0, limit=500)
for m in matches:
    print(f"{m['symbol']}: price={m['lastPrice']} vol={m['quoteVolume']}")
print(f"Total matches: {len(matches)}")
