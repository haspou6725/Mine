@echo off
setlocal
cd /d "%~dp0"
if not exist .venv (
  py -3 -m venv .venv
)
call .venv\Scripts\activate.bat
python -m pip install -r requirements.txt -r requirements-financial-datasets.txt
python tools\fd_fetch_ohlcv.py --symbol BTCUSDT --interval day --start 2026-01-01 --end 2026-07-01
pause
