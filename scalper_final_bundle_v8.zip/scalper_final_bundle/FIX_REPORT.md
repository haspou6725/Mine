# گزارش اصلاحات نسخه `risk-fixed`

این نسخه برای جلوگیری از سیگنال‌های اشتباه و خروجی‌های گمراه‌کننده اصلاح شد.

## اصلاحات اصلی

1. **بک‌تستر اصلاح شد**
   - مدل حسابداری قبلی مقدار کامل پوزیشن را به equity اضافه می‌کرد و سود غیرواقعی می‌ساخت.
   - مدل جدید برای پرپچوال خطی استفاده می‌شود: `equity = cash + unrealized_pnl`.
   - LONG و SHORT هر دو پشتیبانی می‌شوند.
   - slippage و commission هم در ورود و هم در خروج اعمال می‌شوند.

2. **سیگنال‌سازی کورکورانه حذف شد**
   - `tools/generate_signals_folder.py` دیگر هر scanned symbol را سیگنال LONG نمی‌کند.
   - خروجی اصلی `signals/scan_results_master.json` فقط شامل سیگنال‌هایی می‌شود که همه گیت‌ها را پاس کنند.
   - موارد ردشده در `signals/rejected_candidates.json` و watchlist در `signals/watchlist_candidates.json` ذخیره می‌شوند.

3. **تنظیمات سختگیرانه‌تر شد**
   - `early_confirmed_to_signals = false`
   - `prefer_side = BOTH`
   - `score_threshold = 78`
   - `min_volume_spike_for_trigger = 1.70`
   - فیلتر ضد ورود دیرهنگام برای پامپ/دامپ اضافه شد.

4. **Early Warning از سیگنال واقعی جدا شد**
   - Early Warning پیش‌فرض فقط watchlist است.
   - حتی اگر کاربر دستی آن را به سیگنال تبدیل کند، باید score و gateهای اجرا/Trap/Data را پاس کند.

5. **گیت‌های جدید کیفیت سیگنال اضافه شد**
   - liquidity gate
   - spread gate
   - depth gate
   - data freshness gate
   - technical trigger gate
   - market regime gate
   - anti late-chase gate
   - stop-distance/risk-plan gate

6. **پیام کانال اصلاح شد**
   - پیام خروجی فقط جمله تبلیغاتی نیست؛ Entry Zone، SL/Invalidation، TPها، سقف اهرم، ریسک و Score را نشان می‌دهد.

7. **گزارش‌ها و بک‌تست‌های قدیمی پاک شدند**
   - فایل‌هایی که با بک‌تستر قبلی ساخته شده بودند حذف/خالی شدند تا دیگر به عنوان نتیجه معتبر دیده نشوند.
   - برای تولید مجدد، بعد از نصب و با دسترسی live Binance، اسکریپت‌های بک‌تست را دوباره اجرا کنید.

## تست انجام‌شده

```text
pytest -q
12 passed
```

## نکته اجرا

این پروژه در این محیط بدون اینترنت نمی‌تواند اسکن live Binance را اجرا کند. اصلاحات کد، تست‌های واحد و پاکسازی artifactها انجام شده‌اند؛ برای تولید سیگنال جدید باید پروژه را روی سیستم/سروری اجرا کنید که به Binance Futures دسترسی شبکه داشته باشد.
