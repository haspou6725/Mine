from pathlib import Path
import sys
BASE = Path(__file__).resolve().parent
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))

import json
from app.data.binance_futures import get_klines
from app.features.indicators import klines_to_df, add_basic_features
from project_paths import SCAN_RESULTS, FEATURE_HEAD


def main() -> int:
    with open(SCAN_RESULTS, 'r', encoding='utf-8') as f:
        matches = json.load(f)
    if not matches:
        print('No matches found')
        return 1
    symbol = matches[0]['symbol']
    print('Testing features on', symbol)
    kl = get_klines(symbol, interval='1m', limit=200)
    df = klines_to_df(kl)
    df2 = add_basic_features(df)
    with open(FEATURE_HEAD, 'w', encoding='utf-8') as f:
        f.write(df2.head(20).to_json(orient='table', date_format='iso'))
    print('WROTE feature snapshot to', FEATURE_HEAD)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
