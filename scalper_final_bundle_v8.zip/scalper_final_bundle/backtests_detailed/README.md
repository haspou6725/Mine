# Detailed backtests

Stale detailed backtest artifacts were removed during audit.

Run `tools/run_backtest_detailed.py` on validated market data to regenerate.
