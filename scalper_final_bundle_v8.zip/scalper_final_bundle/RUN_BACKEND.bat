@echo off
SETLOCAL EnableExtensions
SET "REPO_ROOT=%~dp0"
CD /D "%REPO_ROOT%"
SET "PYTHONPATH=%REPO_ROOT%"
SET "SCALPER_SAFE_MODE=1"
SET "SCALPER_ORDER_EXECUTION=0"
IF "%SCALPER_BIND_HOST%"=="" SET "SCALPER_BIND_HOST=127.0.0.1"
IF "%SCALPER_BACKEND_PORT%"=="" SET "SCALPER_BACKEND_PORT=8787"
SET "VENV_PY=%REPO_ROOT%.venv\Scripts\python.exe"
IF NOT EXIST "%VENV_PY%" (
    echo [ERROR] Virtual environment not found. Run START_ONE_CLICK.bat first.
    PAUSE
    EXIT /B 1
)
"%VENV_PY%" -m uvicorn merged_imports.scalper_meme_plus_backend.main:app --host %SCALPER_BIND_HOST% --port %SCALPER_BACKEND_PORT%
