import json
import runpy
from pathlib import Path

from project_paths import PROJECT_ROOT


def test_compute_risk_metrics_short_window(tmp_path, monkeypatch):
    backtest_dir = tmp_path / "backtests"
    report_dir = tmp_path / "reports"
    backtest_dir.mkdir(parents=True, exist_ok=True)
    report_dir.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("SCALPER_BACKTESTS_DIR", str(backtest_dir))
    monkeypatch.setenv("SCALPER_REPORTS_DIR", str(report_dir))

    test_file = backtest_dir / "TESTSYM.json"
    equity_curve = [
        {"ts": 1700000000, "equity": 1000.0},
        {"ts": 1700000000 + 60, "equity": 1100.0},
    ]
    test_file.write_text(json.dumps({"equity_curve": equity_curve, "trades": []}), encoding="utf-8")

    runpy.run_path(str(PROJECT_ROOT / "tools" / "compute_risk_metrics.py"))

    rpt = report_dir / "risk_metrics_summary.json"
    assert rpt.exists(), "report not generated"
    summary = json.loads(rpt.read_text(encoding="utf-8"))
    found = next((s for s in summary if s.get("symbol") == "TESTSYM"), None)
    assert found is not None, "TESTSYM not in summary"
    assert found.get("cagr") is None
    assert found.get("cagr_note", "").startswith("elapsed_too_short")
