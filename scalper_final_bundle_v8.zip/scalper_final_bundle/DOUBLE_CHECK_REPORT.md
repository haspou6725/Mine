# Double Check Report - Signal Flow

## What was double checked

- Backend import and smoke endpoints
- Active signal settings in `data/settings.json`
- Signal publication gates in `engine/scoring.py`
- Default `/api/signals` visibility filter
- Early-warning-to-signal flow
- Project audit cleanliness and safety contract
- Unit/API test suite

## Extra issue found and fixed

The previous signal-flow fix correctly allowed confirmed early warnings to be inserted as signals from `early_confirm_threshold = 66`.
However, the default `/api/signals` endpoint still filtered rows by `score_threshold = 72` when no `min_score` query parameter was provided.
That meant early-confirmed signals with scores between 66 and 71 could be stored but hidden from the Signals page.

Fixed by adding `_default_visible_signal_score()` in `main.py`:

- Normal mode default remains `score_threshold`.
- When `early_warning_enabled=true` and `early_confirmed_to_signals=true`, the default visible score becomes:

```text
min(score_threshold, early_confirm_threshold)
```

So with current settings the default Signals page shows signals from score `66` upward.

## Verified active settings

```json
{
  "score_threshold": 72.0,
  "early_confirm_threshold": 66.0,
  "early_confirmed_to_signals": true,
  "require_open_interest": false,
  "require_taker_flow": false,
  "require_funding": false,
  "require_depth": true,
  "strict_live_data": true,
  "min_volume_spike_for_trigger": 1.35,
  "max_spread_pct": 0.28,
  "min_depth_1pct_usd": 45000.0
}
```

## Tests

```text
pytest: 27 passed, 1 warning
backend smoke: /api/health = 200, /api/settings = 200, /api/safety = 200, /api/signals = 200
default_visible_signal_score = 66.0
project_audit quick: ok=true, high=0, medium=0, low=0
project_audit full:  ok=true, high=0, medium=0, low=0
```

## Release cleanup

Before packaging, runtime artifacts were removed:

- `data/live_signals.db`
- SQLite WAL/SHM files
- `__pycache__`
- `.pytest_cache`

## Safety note

The project remains educational/analytical/simulation-only. No real order execution path was enabled.
