# CryptoAudit-Inspired Model Fix Report

این نسخه براساس پیشنهادهای CryptoAudit برای جلوگیری از سیگنال‌های صفر، کاهش FOMO و بهتر شدن کیفیت سیگنال‌های میم‌کوین اصلاح شد.

## تغییرات مدل و تنظیمات

- `trap_threshold`: از 62 به 68 تغییر کرد تا fake pump کمتر وارد Signal شود.
- `min_volume_spike_for_trigger`: از 1.35 به 1.45 تغییر کرد تا اسپایک حجم کمی معتبرتر باشد.
- `max_long_chase_1h_pct`: از 9.5 به 5.5 کاهش یافت تا لانگ دیرهنگام بعد از پامپ کمتر شود.
- `max_short_chase_1h_pct`: از 11.0 به 8.5 کاهش یافت.
- `max_long_rsi_5m`: از 80 به 74 کاهش یافت.
- `min_short_rsi_5m`: از 20 به 26 افزایش یافت.
- `max_stop_distance_pct`: از 7.5 به 6.0 کاهش یافت.
- `cooldown_minutes`: از 12 به 20 افزایش یافت تا سیگنال تکراری کمتر شود.

## لایه جدید BTC Market Context

در `market_context` موارد زیر با داده زنده Binance محاسبه می‌شوند:

- BTC RSI روی کندل‌های 5m
- BTC MACD histogram روی 15m
- نسبت حجم فعلی BTC به میانگین
- تشخیص حالت `btc_overbought_low_volume`
- تشخیص `btc_macd_bearish`
- برچسب روند BTC: bullish / bearish / mixed

این داده‌ها از منبع واقعی بازار گرفته می‌شوند و هیچ داده mock یا دستی تزریق نشده است.

## ضد FOMO و ضد Chase

تنظیمات جدید:

```json
{
  "btc_overbought_rsi": 70.0,
  "btc_overbought_long_penalty": 6.0,
  "btc_overbought_required_volume_spike": 1.70,
  "btc_low_volume_ratio_threshold": 0.80,
  "btc_macd_bearish_long_penalty": 4.0,
  "hard_block_long_if_1h_move_above": 12.0,
  "anti_chase_penalty": 8.0
}
```

اگر BTC overbought باشد و حجم زمینه‌ای ضعیف باشد، لانگ میم‌کوین فقط با Volume Spike قوی‌تر معتبرتر می‌شود و در غیر این صورت جریمه امتیاز و هشدار می‌گیرد.

## Trap Score بهتر

در Early Warning، اگر پامپ در شرایط BTC overbought + volume ضعیف یا MACD ضعیف BTC رخ دهد، Trap Score افزایش می‌گیرد تا fake pumpها بهتر مشخص شوند.

## UI و تنظیمات

فیلدهای جدید BTC Context به پنل تنظیمات وب اضافه شدند و در ذخیره تنظیمات ارسال می‌شوند.
همچنین در کارت‌های Gate، دو Gate جدید نمایش داده می‌شود:

- `No FOMO`
- `BTC Context`

## تست

```text
pytest: 27 passed, 1 warning
project_audit quick: ok=true, high=0, medium=0, low=0
backend smoke: /api/health, /api/settings, /api/signals, /api/skipped = 200
```

## نکته ایمنی

پروژه همچنان Simulation/Analysis only است و مسیر سفارش واقعی فعال ندارد.
