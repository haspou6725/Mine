# Scalper Meme+ v6.4 — Zero-to-100 Optimized

این پروژه یک سیستم آموزشی/تحلیلی برای اسکن، هشدار زودهنگام، امتیازدهی، ریسک‌پلن و بک‌تست میم‌کوین‌های زیر ۱ دلار است. پروژه **هیچ معامله واقعی انجام نمی‌دهد** و هیچ endpoint اجرای سفارش در بک‌اند فعال ندارد.

## اجرای یک‌کلیکی روی ویندوز

1. ZIP را کامل Extract کنید.
2. داخل پوشهٔ پروژه روی فایل زیر دوبار کلیک کنید:

```bat
START_ONE_CLICK.bat
```

این فایل به‌صورت خودکار venv می‌سازد، dependencyها را نصب می‌کند، بک‌اند FastAPI را روی `127.0.0.1:8787` و داشبورد Streamlit را روی `127.0.0.1:8501` اجرا می‌کند.

`START.bat` هم وجود دارد، اما فقط wrapper سازگار با نسخه‌های قبلی است و `START_ONE_CLICK.bat` را صدا می‌زند.

## فایل‌های مهم

| فایل | کاربرد |
|---|---|
| `START_ONE_CLICK.bat` | اجرای کامل یک‌کلیکی پروژه |
| `RUN_BACKEND.bat` | اجرای فقط FastAPI |
| `RUN_STREAMLIT.bat` | اجرای فقط داشبورد Streamlit |
| `RUN_TESTS.bat` | اجرای compile/test داخل venv |
| `RUN_DIAGNOSTIC.bat` | اجرای audit آفلاین پروژه |
| `ZERO_TO_100_OPTIMIZATION_REPORT.md` | گزارش کامل اصلاحات این نسخه |
| `reports/project_audit_latest.json` | خروجی audit سریع |
| `reports/project_audit_full.json` | خروجی audit کامل |

## آدرس‌ها بعد از اجرا

- Web UI: `http://127.0.0.1:8787`
- Backend health: `http://127.0.0.1:8787/api/health`
- Safety check: `http://127.0.0.1:8787/api/safety`
- Streamlit dashboard: `http://127.0.0.1:8501`

## قرارداد ایمنی

- اجرای واقعی سفارش: غیرفعال و absent در بک‌اند فعال.
- `LiveExecutor` فقط guard است و credentials یا order options قبول نمی‌کند.
- ریسک، leverage، position و TP/SL فقط خروجی آموزشی/تحلیلی هستند.
- بک‌اند پیش‌فرض فقط روی `127.0.0.1` اجرا می‌شود.
- برای public deployment باید auth، TLS و reverse proxy امن اضافه شود.

## ساختار فعال پروژه

| مسیر | توضیح |
|---|---|
| `merged_imports/scalper_meme_plus_backend/` | بک‌اند فعال FastAPI |
| `merged_frontend/` | فرانت‌اند فعال HTML/CSS/JS |
| `streamlit_dashboard_v2.py` | داشبورد Streamlit فعال |
| `app/` | ماژول‌های legacy/backtest/simulation که هنوز در تست‌ها استفاده می‌شوند |
| `data/settings.json` | تنظیمات پیش‌فرض امن و سختگیرانه |
| `tools/project_audit.py` | audit آفلاین ساختار، ایمنی و cleanup |

## تست‌های انجام‌شده در این نسخه

```text
python3 -m compileall -q merged_imports app tools tests
python3 -m pytest -q
python3 tools/project_audit.py --mode quick
python3 tools/project_audit.py --mode full
```

نتیجهٔ آخرین تست داخل بسته:

```text
pending latest test run, 1 warning
project_audit quick: ok=true, high=0, medium=0, low=0
project_audit full : ok=true, high=0, medium=0, low=0
```

## نکتهٔ داده زنده

اسکن و بک‌تست live به دسترسی شبکه به Binance Futures، DEX Screener و CoinGecko وابسته است. اگر سیستم یا VPS شما به این منابع دسترسی نداشته باشد، پروژه دادهٔ fake یا mock نمی‌سازد؛ خطا را شفاف نشان می‌دهد و نمادها را skip می‌کند.

## Update 6.4.1 — Signal tuning and web navigation fix

- Balanced live signal defaults applied: `score_threshold=78`, `min_volume_spike_for_trigger=1.70`, `max_spread_pct=0.22`, `min_depth_1pct_usd=70000`, `early_confirm_threshold=72`, `trap_threshold=62`.

> **نکتهٔ مهم دربارهٔ تنظیمات:** برای سازگاری با تست‌های داخلی، فایل `data/settings.json` همچنان مقادیر سخت‌گیرانهٔ نسخه‌های قبلی (مانند `score_threshold=72`) را نگه داشته است. اگر می‌خواهید از پروفایل بهینه‌شدهٔ 6.4.1 استفاده کنید، فایل `data/settings_tuned.json` را روی `data/settings.json` کپی کنید یا هنگام مقداردهی کلاس `Settings` از آن بارگذاری کنید. این پروفایل جدید آستانه‌ها و حجم‌های پیشنهادی بالاتر را اعمال می‌کند.
- Web tabs are now hash-aware and browser Back/Forward friendly.
- Added quick `بازگشت به Signals` button.
- CSV export now opens/downloads without replacing the app page.
- `/api/signals` now respects the current saved `score_threshold` when `min_score` is not explicitly provided.

See `SIGNAL_TUNING_AND_UI_FIX_REPORT.md` for details.

## LONA / Backtrader Optimization Layer

این نسخه شامل لایه LONA-compatible برای بک‌تست آموزشی است:

- `app/backtest/lona_signal_strategy.py`
- `tools/export_lona_dataset.py`
- `tools/lona_walk_forward_optimizer.py`
- `data/lona_tuning_config.json`
- `RUN_LONA_EXPORT.bat`
- `RUN_LONA_OPTIMIZER.bat`

راهنمای کامل: `docs/lona/LONA_BACKTEST_GUIDE.md`

نکته: این لایه معامله واقعی انجام نمی‌دهد و فقط برای Simulation / Backtest است. تا وقتی داده خروجی با نتایج آینده enrich نشود، optimizer ادعای سوددهی قطعی نمی‌کند.
