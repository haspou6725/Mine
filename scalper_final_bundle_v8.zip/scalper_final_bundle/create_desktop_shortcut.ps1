# Creates a desktop shortcut that runs START.bat (double-click to launch the project)
$ProjectRoot = $PSScriptRoot
$WScriptShell = New-Object -ComObject WScript.Shell
$Desktop = [Environment]::GetFolderPath('Desktop')
$target = Join-Path $ProjectRoot 'START.bat'
$shortcut = $WScriptShell.CreateShortcut((Join-Path $Desktop 'Scalper Launcher.lnk'))
$shortcut.TargetPath = $target
$shortcut.WorkingDirectory = $ProjectRoot
$shortcut.WindowStyle = 1
$shortcut.IconLocation = "$target,0"
$shortcut.Save()
Write-Output "Created shortcut on desktop: Scalper Launcher.lnk -> $target"
