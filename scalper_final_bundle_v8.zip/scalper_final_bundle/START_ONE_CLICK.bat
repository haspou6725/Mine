@echo off
REM ============================================================
REM  START_ONE_CLICK.bat - One-click launcher for Scalper Meme+
REM  Educational/live-data scanner only. No real order execution.
REM ============================================================

SETLOCAL EnableExtensions
SET "REPO_ROOT=%~dp0"
CD /D "%REPO_ROOT%"
SET "PYTHONPATH=%REPO_ROOT%"
SET "SCALPER_SAFE_MODE=1"
SET "SCALPER_ORDER_EXECUTION=0"
SET "SCALPER_BIND_HOST=127.0.0.1"
SET "SCALPER_BACKEND_PORT=8787"
SET "SCALPER_STREAMLIT_PORT=8501"
REM Default UX: open only the main FastAPI web UI.
REM Set SCALPER_START_STREAMLIT=1 before running this file if you also want the Streamlit dashboard.
IF "%SCALPER_START_STREAMLIT%"=="" SET "SCALPER_START_STREAMLIT=0"

REM ---- 0) Basic safety checks -----------------------------------------
IF NOT EXIST "%REPO_ROOT%requirements.txt" (
    echo.
    echo [ERROR] requirements.txt was not found.
    echo Make sure you extracted the ZIP first, then run START_ONE_CLICK.bat from the extracted project folder.
    echo.
    PAUSE
    EXIT /B 1
)

IF NOT EXIST "%REPO_ROOT%merged_imports\scalper_meme_plus_backend\main.py" (
    echo.
    echo [ERROR] Active backend was not found.
    echo Expected: merged_imports\scalper_meme_plus_backend\main.py
    echo.
    PAUSE
    EXIT /B 1
)

IF EXIST "%REPO_ROOT%data\live_signals.db" (
    echo Existing runtime database found: data\live_signals.db
    echo It will be reused. Delete it manually only if you want a fresh local history.
)

REM ---- 1) Find Python --------------------------------------------------
WHERE py >nul 2>nul
IF %ERRORLEVEL%==0 (
    SET "PY=py -3"
) ELSE (
    WHERE python >nul 2>nul
    IF %ERRORLEVEL%==0 (
        SET "PY=python"
    ) ELSE (
        echo.
        echo [ERROR] Python was not found on this computer.
        echo Install Python 3.10+ and enable "Add python.exe to PATH".
        echo.
        PAUSE
        EXIT /B 1
    )
)

echo Using project folder:
echo %REPO_ROOT%
echo.

REM ---- 2) Create virtual environment ----------------------------------
IF NOT EXIST "%REPO_ROOT%.venv\Scripts\python.exe" (
    echo Creating virtual environment ^(first run only^) ...
    %PY% -m venv "%REPO_ROOT%.venv"
    IF ERRORLEVEL 1 (
        echo.
        echo [ERROR] Failed to create the virtual environment.
        echo Try running this from a normal extracted folder, not from inside the ZIP.
        echo.
        PAUSE
        EXIT /B 1
    )
)

SET "VENV_PY=%REPO_ROOT%.venv\Scripts\python.exe"

REM ---- 3) Install dependencies when requirements changed ---------------
SET "STAMP_FILE=%REPO_ROOT%.venv\requirements.stamp"
SET "REQ_HASH="
FOR /F "usebackq tokens=*" %%H IN (`powershell -NoProfile -ExecutionPolicy Bypass -Command "(Get-FileHash -Algorithm SHA256 -LiteralPath '%REPO_ROOT%requirements.txt').Hash"`) DO SET "REQ_HASH=%%H"
IF "%REQ_HASH%"=="" SET "REQ_HASH=force-install"

SET "NEED_INSTALL=0"
IF NOT EXIST "%STAMP_FILE%" SET "NEED_INSTALL=1"
IF EXIST "%STAMP_FILE%" (
    SET /P OLD_HASH=<"%STAMP_FILE%"
    IF NOT "%OLD_HASH%"=="%REQ_HASH%" SET "NEED_INSTALL=1"
)

IF "%NEED_INSTALL%"=="1" (
    echo Installing required packages. This is needed only when the venv or requirements changed...
    "%VENV_PY%" -m pip install --upgrade pip
    IF ERRORLEVEL 1 GOTO :INSTALL_ERROR
    "%VENV_PY%" -m pip install -r "%REPO_ROOT%requirements.txt"
    IF ERRORLEVEL 1 GOTO :INSTALL_ERROR
    > "%STAMP_FILE%" echo %REQ_HASH%
)

REM ---- 4) Optional offline diagnostic ---------------------------------
echo Running offline diagnostic...
"%VENV_PY%" "%REPO_ROOT%tools\project_audit.py" --mode quick --output "%REPO_ROOT%reports\startup_diagnostic.json" >nul 2>nul
IF ERRORLEVEL 1 (
    echo [WARNING] Offline diagnostic found issues. See reports\startup_diagnostic.json
)

REM ---- 5) Start services in separate windows ---------------------------
echo Starting backend API on http://127.0.0.1:%SCALPER_BACKEND_PORT% ...
start "Scalper Backend" /D "%REPO_ROOT%" cmd /k call "%REPO_ROOT%RUN_BACKEND.bat"

IF "%SCALPER_START_STREAMLIT%"=="1" (
    echo Starting Streamlit dashboard on http://127.0.0.1:%SCALPER_STREAMLIT_PORT% ...
    start "Scalper Streamlit" /D "%REPO_ROOT%" cmd /k call "%REPO_ROOT%RUN_STREAMLIT.bat"
) ELSE (
    echo Streamlit dashboard is disabled by default to avoid opening a second browser page.
    echo To enable it, run: set SCALPER_START_STREAMLIT=1 ^& START_ONE_CLICK.bat
)

REM ---- 6) Wait briefly, then open browser ------------------------------
echo Waiting for backend to become ready...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$port=$env:SCALPER_BACKEND_PORT; $ok=$false; for($i=0;$i -lt 25;$i++){ try { $r=Invoke-WebRequest -UseBasicParsing \"http://127.0.0.1:$port/api/health\" -TimeoutSec 2; if($r.StatusCode -eq 200){$ok=$true; break} } catch {}; Start-Sleep -Seconds 1 }; if(-not $ok){ exit 1 }"
IF ERRORLEVEL 1 (
    echo.
    echo [WARNING] Backend did not answer yet. Check the "Scalper Backend" window for the real error.
    echo You can also open this manually after a few seconds:
    echo http://127.0.0.1:%SCALPER_BACKEND_PORT%
    echo.
) ELSE (
    start "" "http://127.0.0.1:%SCALPER_BACKEND_PORT%"
)

IF "%SCALPER_START_STREAMLIT%"=="1" start "" "http://127.0.0.1:%SCALPER_STREAMLIT_PORT%"

echo.
echo ============================================================
echo  Scalper Meme+ launch command finished.
echo  Backend   : http://127.0.0.1:%SCALPER_BACKEND_PORT%
IF "%SCALPER_START_STREAMLIT%"=="1" echo  Streamlit : http://127.0.0.1:%SCALPER_STREAMLIT_PORT%
echo  Safety    : real order execution is disabled by design.
IF "%SCALPER_START_STREAMLIT%"=="1" (
    echo  Close the Backend and Streamlit service windows to stop the app.
) ELSE (
    echo  Close the Backend service window to stop the app.
)
echo ============================================================
echo.
PAUSE
EXIT /B 0

:INSTALL_ERROR
echo.
echo [ERROR] Package installation failed.
echo Check your internet connection, then run START_ONE_CLICK.bat again.
echo If the error mentions permissions, move the project to a simple path like C:\Scalper\ and retry.
echo.
PAUSE
EXIT /B 1
