# Runtime reports

Stale reports generated before the audit were removed/reset so they are not mistaken for live or valid backtest results.

Regenerate reports after running the corrected backtester/scanner on real data.
