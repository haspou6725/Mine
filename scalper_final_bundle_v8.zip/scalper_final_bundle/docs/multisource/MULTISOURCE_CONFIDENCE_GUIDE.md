# Multi-source Confidence Layer

This version adds a read-only model confidence layer inspired by TickerSage, Kraken, RealOpen, Alpaca and Figma.

## What changed

- **TickerSage-style chart confirmation**: EMA/VWAP/RSI/momentum/volume confirmation derived from the scanner's own live candles, so it remains deterministic even if the external chart tool times out.
- **Kraken-style narrative/news risk**: neutral unless live/news context is attached; security/delisting/exploit keywords can hard-block if configured.
- **RealOpen-style liquidity tier**: major liquid assets receive a small stability bonus; unknown thin microcaps receive a risk penalty.
- **Alpaca-style cross-feed validation**: optional secondary feed price/spread validation; missing secondary feed is neutral, disagreement increases execution risk.
- **Figma-ready UI contract**: `/api/design/system` documents cards, badges and sections for later Figma import or UI implementation.
- **Explainability**: signal cards include Multi-source Confidence and the gate panel includes Chart, News Risk and Cross-Feed.

## New endpoints

- `/api/multisource/confidence?symbol=BTCUSDT`
- `/api/design/system`

## Safety

No real execution, no order routes, no credentialed trading client. This is an educational analytics/simulation layer.
