# Audit report — `scalper_final_bundle_RISK_FIXED`

## Scope

Role coverage: Senior Python/FastAPI Engineer, Quant/Trading Systems Engineer, QA Engineer, Security Auditor, Frontend Engineer, Streamlit Engineer and DevOps Engineer.

The active backend path is `merged_imports/scalper_meme_plus_backend/`. The legacy `app/` path is not mounted by `RUN_BACKEND.bat`; it is still used by backtest/simulation tools and tests. The active frontend is `merged_frontend/`. The active Streamlit launcher is `streamlit_dashboard_v2.py`; `ui/streamlit_app.py` is a compatibility wrapper.

## Executive status

| Area | Status | Notes |
|---|---:|---|
| Backend FastAPI | Pass | Runs on `127.0.0.1:8787`; smoke endpoints returned JSON/HTML/CSV without unexpected 500s. |
| Frontend | Pass | `node --check merged_frontend/app.js` passes; XSS escape helpers are used for rendered external text and external links use `noopener noreferrer`. |
| Streamlit | Pass | Runs on `127.0.0.1:8501` after dependencies are installed in venv. |
| Live Data | Partial | Live network from this sandbox failed DNS/connectivity to Binance/DEX/CoinGecko, so real market data freshness and exchange schemas require server/system validation. Failure handling returned clear JSON and did not crash. |
| Universe | Partial | Offline behavior tested: empty universe returns an explicit error and does not hang. Full live universe construction requires network. |
| Early Warning | Pass for unit logic | Added test that high-trap pump becomes `TRAP`, not `CONFIRMED`. |
| Scoring / Hard Gates | Pass for unit logic | Added test that missing live sources and bad execution fail hard gates. Live behavior requires network. |
| Risk Planner | Pass | Unit test confirms risk-based sizing and no order execution. |
| Backtester | Pass | Existing accounting tests pass; accounting model is `cash + unrealized PnL`, not full position market value. |
| SQLite | Pass | WAL enabled, parameterized queries used. Patched corrupted JSON payload handling so API lists do not 500. |
| Security | Partial | No secrets found and live execution is disabled. Auth is not implemented; safe only while bound to localhost or behind a trusted reverse proxy/auth layer. |
| Performance | Partial | Concurrency caps and rate-limit estimate exist. Full rate-limit/memory/CPU tests with 20/50/220 live symbols require real network. |
| Tests | Pass | `18 passed`. Added API validation, storage-corruption, hard-gate, early-trap and risk-plan tests. |
| Deployment scripts | Pass/Partial | Batch/PowerShell paths are relative. `pytest` was missing from runtime requirements, so `requirements-dev.txt` was added. |

## Commands executed

```text
python3 -m compileall -q merged_imports app tools tests
python3 -m pytest -q
node --check merged_frontend/app.js
python3 -m venv /mnt/data/scalper_venv
/mnt/data/scalper_venv/bin/python -m pip install -r requirements.txt
PYTHONPATH=$PWD /mnt/data/scalper_venv/bin/python -m uvicorn merged_imports.scalper_meme_plus_backend.main:app --host 127.0.0.1 --port 8787
curl http://127.0.0.1:8787/api/health
PYTHONPATH=$PWD /mnt/data/scalper_venv/bin/python -m streamlit run streamlit_dashboard_v2.py --server.port=8501 --server.headless=true
curl http://127.0.0.1:8501/
```

Result summary:

```text
compileall: PASS
pytest: 18 passed, 1 warning
node --check: PASS
backend port 8787: PASS
Streamlit port 8501: PASS after installing requirements
/api/data-health in sandbox: returned 200 with source failures, no crash
/api/scan/wait in sandbox: returned ok=false/no_universe, no crash
```

## Code changes made in this audit

### 1. Structured API errors

File: `merged_imports/scalper_meme_plus_backend/main.py`

Added handlers for `HTTPException` and `RequestValidationError`. Bad query/body inputs now return consistent JSON like:

```json
{"ok": false, "error": "validation_error", "details": [...]}
```

### 2. Symbol validation

File: `merged_imports/scalper_meme_plus_backend/main.py`

Added `_normalize_symbol()` with `^[A-Z0-9]{2,30}$` validation and used it for:

- `GET /api/analyze/{exchange}/{symbol}`
- `GET /api/backtest/{symbol}`
- `GET /api/backtest/detailed/{symbol}`

This prevents malformed symbols from being sent to external APIs or file paths.

### 3. Corrupted SQLite JSON resilience

File: `merged_imports/scalper_meme_plus_backend/services/storage.py`

Patched `list_signals`, `latest_snapshots` and `latest_skips` JSON decoding paths so a corrupted `payload_json`/`details_json` row does not cause a user-facing endpoint to return 500.

### 4. Additional tests

Files added:

- `tests/test_api_validation_and_storage.py`
- `tests/test_engine_gates.py`
- `requirements-dev.txt`

Coverage added:

- invalid endpoint/settings inputs do not return 500;
- invalid JSON body is a clean 422;
- corrupted SQLite payload rows do not crash list endpoints;
- hard gates fail when live sources/execution quality are bad;
- Early Warning high-trap scenarios become `TRAP`;
- risk planner sizes by risk and states no order is sent.

### 5. Stale artifacts cleaned

Cleaned/emptied runtime artifacts so old scan/report data is not presented as live truth:

- `data/live_signals.db*` removed from package;
- `scan_results.json` reset to `[]`;
- `feature_head.json` reset to `{}`;
- `reports/*.json` reset to empty safe structures;
- reports/backtest README files updated.

## Pipeline trace

| Stage | File / function | Input | Output | Empty/timeout behavior | Status | Severity / Fix |
|---|---|---|---|---|---:|---|
| Live Sources | `clients/http.py::get_json` | REST paths/params | JSON payload | retries twice then `LiveDataError` | Partial | Requires live network validation. |
| Data Health | `ScannerService.data_health` | source probes | source status list | each failed source returns `ok=false`, no crash | Pass offline | Add per-symbol OI/taker probes in a future version if needed. |
| Universe | `_build_binance_universe`, `_build_lbank_universe` | exchangeInfo/tickers/markets | ranked universe rows | empty universe returns explicit `ok=false` in scan | Partial | Live symbol validity requires real exchange test. |
| Klines/Candles | `analyze_binance_symbol`, `analyze_lbank_symbol` | symbol/timeframes | 1m/5m/15m/1h candles | strict mode skips when required sources missing | Partial | Live endpoint schemas require network. |
| Orderbook/Depth | `depth`, `orderbook_metrics` | order book | spread, depth ±1%, imbalance | strict mode skips if required and missing | Partial | Live depth quality requires network. |
| Open Interest | `open_interest_hist` | symbol | OI history | missing source skipped in strict mode | Partial | Binance live required. |
| Funding | `premium_index` | all symbols | funding/mark | missing source skipped in strict mode | Partial | Binance live required. |
| Taker Flow | `taker_buy_sell_volume` | symbol | taker ratios | missing source skipped in strict mode | Partial | Binance live required. |
| Market Context | `market_context` | BTC/ETH klines | risk_on/off/neutral | returns `ok=false`, `bias=unknown` | Pass offline | No crash. |
| Features | `_score_from_klines` | klines/depth/context | metrics dict | stale/missing marks skipped or failed gates | Pass unit | Need live quality validation. |
| Early Warning | `compute_early_warning` | metrics + 1m/5m klines | INFO/WATCH/CONFIRMED/TRAP | incomplete data reduces execution score/warnings | Pass | Added trap unit test. |
| Scoring | `score_long`, `score_short` | metrics/settings | score, reasons, warnings, gates | failed gates prevent storage as signal | Pass | Added hard-gate unit test. |
| Risk Plan | `build_trade_plan` | side/price/ATR/capital/risk/leverage | educational plan only | price<=0 returns `{}` | Pass | No exchange call. |
| Signal Creation | `build_signal`, `_score_from_klines` | passed score+gates | signal row | failed gates/skips stored | Pass unit | Live signal creation not tested due network. |
| SQLite | `Storage` | signal/snapshot/skip/run | WAL SQLite rows | corrupted JSON now skipped safely | Pass | Patched. |
| API Output | `main.py` | HTTP requests | JSON/CSV/HTML | bad inputs structured 400/422 | Pass | Patched. |
| Frontend | `merged_frontend/app.js` | API JSON | DOM tables/cards | empty states and errors rendered escaped | Pass syntax | Browser UI click test not automated. |
| Streamlit | `streamlit_dashboard_v2.py` | backend/files | dashboard | backend down shows error | Pass startup | Browser interaction not automated. |
| Export | `/api/export/signals.csv` | SQLite signals | CSV stream | empty CSV header only | Pass smoke | Large CSV perf not tested. |

## Endpoint smoke matrix

Offline/mocked smoke covered:

| Endpoint | Status |
|---|---:|
| `GET /` | 200 |
| `GET /api/health` | 200 |
| `GET /api/data-health` | 200 |
| `GET /api/market-context` | 200 |
| `GET /api/settings` | 200 |
| `PATCH/POST /api/settings` | 200/422 as expected |
| `POST /api/scan` | smoke only |
| `POST /api/scan/wait` | 200 `ok=false` when no network/universe |
| `GET /api/analyze/{exchange}/{symbol}` | 400 for bad exchange/symbol; live test required for valid symbol |
| `GET /api/scan/status` | 200 |
| `POST /api/loop/start` / `/stop` | smoke only; no duplicate task seen in code |
| `GET /api/universe` | 200 empty offline |
| `GET /api/early` | 200 |
| `GET /api/live/state` | 200 |
| `GET /api/snapshots` | 200 |
| `GET /api/skipped` | 200 |
| `GET /api/signals` | 200; 400/422 for bad params |
| `GET /api/dex/radar` | 200 empty/error offline |
| `GET /api/coingecko/trending` | 200 empty/error offline |
| `GET /api/backtest/detailed/{symbol}` | 400/404 for invalid/missing; saved backtest live not regenerated |
| `GET /api/backtest/{symbol}` | 200 mocked; live required for valid Binance symbol |
| `GET /api/export/signals.csv` | 200 text/csv |

## Critical findings

No critical issue remains in the audited package that would execute live trades. `LiveExecutor.place_order()` still raises `NotImplementedError`, active FastAPI has no execution endpoint, no credentialed exchange-order client was found, and all risk/position fields are educational simulation/planning only.

## High findings

### H1 — No authentication for scan/settings/loop endpoints

- File: `merged_imports/scalper_meme_plus_backend/main.py`
- Risk: if exposed publicly, a third party could alter settings or trigger scans/loops.
- Current mitigation: Windows launch binds backend to `127.0.0.1`; CORS only allows local origins.
- Required before production: add auth/API token or put behind a reverse proxy with authentication and TLS.

### H2 — Live source behavior not fully validated in this sandbox

- Files: `clients/*.py`, `services/scanner.py`
- Risk: exchange schema/rate-limit changes can affect production results.
- Evidence: sandbox returned DNS/connect timeout for Binance/DEX/CoinGecko, but API handled it cleanly.
- Required before serious use: run the live checklist on the actual server/network.

### H3 — Requirements are unpinned

- File: `requirements.txt`
- Risk: future installs can silently pull incompatible versions.
- Fix added: `requirements-dev.txt` for tests.
- Recommended: freeze a known-good `requirements.lock.txt` after validating on the deployment Python version.

## Medium findings

### M1 — Legacy `app/` path is still present

- Active API path: `merged_imports/scalper_meme_plus_backend/`.
- Legacy path: `app/` is still used by backtest/executor tests and tools.
- Risk: future contributors may edit the wrong backend.
- Recommendation: rename legacy code to `legacy_app/` or document it very clearly.

### M2 — Streamlit reads saved files when backend has no signals

- File: `streamlit_dashboard_v2.py`
- Risk: stale files could be mistaken for live.
- Fix: stale report files were cleaned in this package.
- Recommendation: add a visible “file snapshot / not live” label for fallback reads.

### M3 — Data health is broad, not per-symbol exhaustive

- File: `services/scanner.py::data_health`
- Current: global Binance time/exchangeInfo/ticker/premium + optional sources + market context.
- Recommendation: add a user-configurable probe symbol, e.g. BTCUSDT, to health-check klines/depth/open interest/taker flow/funding directly.

## Low findings

- `tools/generate_icon.py` emits compile-time warnings for Windows path string escapes; non-runtime cosmetic issue.
- Streamlit import outside `streamlit run` emits expected ScriptRunContext warnings; startup via `streamlit run` is OK.
- `pytest` is not a runtime dependency; tests need `requirements-dev.txt`.

## Security audit

| Check | Result |
|---|---:|
| credentials/secrets in code | None found. |
| Real order endpoint in active backend | None found. |
| Live executor | Disabled via `NotImplementedError`. |
| SQL injection | Parameterized SQLite queries. |
| Path traversal | Patched symbol validation for backtest/analyze paths. |
| XSS | Frontend uses `esc()` and `safeUrl()`; external links use `rel="noopener noreferrer"`. |
| SSRF | No user-controlled arbitrary URL fetch found. |
| CORS | Localhost only. |
| Public deployment | Not safe without auth/TLS/reverse proxy. |
| Sensitive stack traces | General exception handler hides stack traces from responses. |

## Tests not completed here

| Test | Reason | Needed |
|---|---|---|
| Full Binance Futures live success path | Sandbox DNS/connectivity failed. | Server/network with Binance access. |
| LBank live contract data | Disabled by default and live network unavailable. | Enable setting + server/network. |
| DEX Screener/CoinGecko success path | Sandbox DNS/connectivity failed. | Server/network. |
| 20/50/220 symbol performance scan | Requires real network and time. | Deployment-like server. |
| Browser click/UI visual regression | No browser automation here. | Playwright/Selenium. |
| Dependency vulnerability scan | No safety/pip-audit installed. | `pip-audit` or SCA in CI. |

## Final checklist before serious handoff

- Install from a fresh venv: `pip install -r requirements.txt`; for tests use `pip install -r requirements-dev.txt`.
- Run `python -m compileall merged_imports app tools tests`.
- Run `python -m pytest`.
- Run `node --check merged_frontend/app.js`.
- Start backend and test `/api/health`, `/api/data-health`, `/api/settings`, `/api/scan/wait`, `/api/universe`, `/api/analyze/binance-futures/BTCUSDT`, `/api/signals`, `/api/export/signals.csv`.
- Start Streamlit and confirm backend-down and backend-up states.
- Confirm Binance/LBank outage handling.
- Confirm no mock/fake data is displayed as live.
- Add auth before public exposure.
- Never enable real execution without a separate code review and explicit paper/live mode gates.
