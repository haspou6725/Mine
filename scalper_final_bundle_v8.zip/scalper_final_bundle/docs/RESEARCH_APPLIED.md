# Research rules applied to the signal engine

The uploaded Persian research report recommended a professional signal system with these principles:

- separate asset discovery from final trade signals;
- use multi-source scoring, not a single indicator;
- require liquidity, spread/depth, fresh data, and clear price/volume trigger;
- keep Early Warning as watchlist unless stricter gates pass;
- use fixed risk per trade and explicit invalidation/SL/TP in every message;
- keep complete logs instead of only showing winners.

Applied changes:

- `early_confirmed_to_signals` default is now `false`.
- `score_threshold` default is now `78` for the balanced live profile.
- `generate_signals_folder.py` now separates `SIGNAL`, `WATCHLIST`, and `REJECTED`.
- `hard_gates()` now checks liquidity, spread, depth, data freshness, technical trigger, market regime, anti-late-chase, and stop-distance.
- `channel_text()` now includes Entry Zone, SL/Invalidation, TP1-TP3, leverage cap, risk amount, score, and grade.
- Stale generated reports from the old backtester were removed.
