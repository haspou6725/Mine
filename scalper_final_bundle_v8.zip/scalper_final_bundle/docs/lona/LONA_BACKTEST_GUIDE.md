# LONA Backtest / Optimization Guide

این نسخه یک لایه سازگار با LONA اضافه می‌کند تا مدل اسکالپر از حالت «فقط اسکنر لایو» به حالت قابل بک‌تست و قابل بهینه‌سازی نزدیک شود.

## فایل‌های جدید

- `app/backtest/lona_signal_strategy.py`  
  نسخه Backtrader/LONA-compatible از منطق سیگنال. این فایل معامله واقعی انجام نمی‌دهد.

- `tools/export_lona_dataset.py`  
  سیگنال‌ها، snapshotها و rejected/skipped reasons را به CSV تبدیل می‌کند.

- `tools/lona_walk_forward_optimizer.py`  
  Grid-search و walk-forward ساده روی CSV خروجی انجام می‌دهد. اگر ستون‌های نتیجه آینده (`result_r`) پر نشده باشند، فقط گزارش فرکانس/انتخاب می‌دهد و ادعای سوددهی نمی‌کند.

- `data/lona_tuning_config.json`  
  بازه‌های پارامترها برای آزمون و خطا.

## اجرای سریع در ویندوز

```bat
RUN_LONA_EXPORT.bat
RUN_LONA_OPTIMIZER.bat
```

## خروجی‌ها

```text
reports/lona/signals_dataset.csv
reports/lona/signals_dataset.meta.json
reports/lona/walk_forward_results.json
```

## نکته مهم

تا وقتی CSV با نتیجه آینده کندل‌ها enrich نشود، optimizer نباید به عنوان «بهترین ترکیب سودده» تفسیر شود. این نسخه زیرساخت را آماده می‌کند و جلوی بک‌تست فیک را می‌گیرد.
