# Binance Microstructure Layer

این نسخه، Binance را به عنوان منبع اصلی کیفیت اجرای زنده و microstructure استفاده می‌کند. این لایه فقط read-only است و هیچ API key، سفارش، leverage واقعی یا execution واقعی ندارد.

## ویژگی‌های اضافه‌شده

- Binance USDⓈ Futures universe builder برای نمادهای USDT Perpetual زیر ۱ دلار.
- Dynamic spread gate بر اساس نقدشوندگی ۲۴ ساعته.
- Dynamic depth gate بر اساس حجم و عمق ±1% order book.
- Mark/Index premium risk برای تشخیص فاصله غیرعادی mark price از index price.
- Taker buy/sell pressure برای تایید جهت حجم.
- Open Interest delta scoring برای تشخیص confirmation یا trap.
- Funding crowded-trade penalty برای جلوگیری از ورود در جهت بیش از حد crowded.
- Read-only endpoint: `/api/binance/microstructure?symbol=BTCUSDT`.
- ابزار CSV: `RUN_BINANCE_MICROSTRUCTURE.bat` و `RUN_BINANCE_FEATURE_EXPORT.bat`.

## تنظیمات مهم

```json
{
  "binance_microstructure_enabled": true,
  "use_dynamic_spread_threshold": true,
  "use_dynamic_depth_threshold": true,
  "use_open_interest_score": true,
  "use_funding_score": true,
  "use_mark_index_premium": true,
  "use_taker_flow_score": true,
  "min_taker_buy_ratio_for_long": 0.55,
  "max_taker_buy_ratio_for_short": 0.45,
  "max_mark_index_premium_pct": 0.12,
  "crowded_funding_abs_threshold": 0.00025
}
```

## فلسفه Gateها

- Live sources, freshness, price, liquidity, spread, depth, mark/index premium, volume trigger و technical trigger همچنان gateهای حیاتی‌اند.
- Taker flow، funding و OI بیشتر score/warning می‌سازند تا مدل با قطع شدن یک endpoint کاملاً صفر نشود.
- اگر premium mark/index غیرعادی باشد، سیگنال برای جلوگیری از execution risk بلاک می‌شود.

## خروجی UI

کارت سیگنال حالا بخش `Binance Microstructure` دارد:

- Spread Gate
- Depth Gate
- Taker Buy
- Mark Premium
- OI
- Funding

## اجرای ابزارها

```bat
RUN_BINANCE_MICROSTRUCTURE.bat
RUN_BINANCE_FEATURE_EXPORT.bat
```

یا از خط فرمان:

```bash
python tools/binance_microstructure_snapshot.py --symbols BTCUSDT ETHUSDT DOGEUSDT
python tools/binance_feature_export.py --symbol DOGEUSDT --interval 5m --limit 500
```
