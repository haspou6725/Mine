# Financial Datasets Integration Guide

This release adds a Financial Datasets layer for historical OHLCV, market-regime analysis, benchmark reporting, feature dataset creation, and walk-forward optimization.

## What it does

- Fetches crypto OHLCV into normalized CSV.
- Caches raw responses under `data/financial_datasets_cache/`.
- Builds a supervised feature dataset with future-return labels.
- Generates a benchmark report comparing buy-and-hold against a conservative signal proxy.
- Runs a walk-forward optimizer and exports `data/best_params_financial_datasets.json`.

## What it does not do

- It does not execute trades.
- It does not replace live order book, spread, depth, funding, OI, or taker-flow feeds.
- It does not fabricate market data if Financial Datasets is unavailable.

## Environment variables

```bat
set FINANCIAL_DATASETS_API_KEY=your_key_here
set FINANCIAL_DATASETS_ALLOW_NETWORK=1
set FINANCIAL_DATASETS_CACHE_TTL_SEC=3600
```

## One-click pipeline

Run:

```bat
RUN_FINANCIAL_DATASETS_PIPELINE.bat
```

## Manual steps

```bash
python tools/fd_fetch_ohlcv.py --symbol BTCUSDT --interval day --start 2026-01-01 --end 2026-07-01
python tools/fd_build_feature_dataset.py --ohlcv data/financial_datasets/BTC-USD_day_2026-01-01_2026-07-01.csv --symbol BTCUSDT
python tools/fd_benchmark_report.py --dataset data/financial_datasets/feature_dataset.csv
python tools/fd_walk_forward_optimizer.py --dataset data/financial_datasets/feature_dataset.csv
```

## Interpretation

The optimizer output should be treated as a research aid. The final parameters should only be promoted to live settings after:

1. Enough out-of-sample trades exist.
2. Profit factor and max drawdown are acceptable.
3. Results remain stable across bullish, bearish, range, high-volatility, and low-volume BTC regimes.
