param(
    [string]$Target = (Join-Path $PSScriptRoot 'START.bat'),
    [string]$ShortcutName = "Scalper Launcher",
    [string]$IconPath = ""
)

$WScriptShell = New-Object -ComObject WScript.Shell
$Desktop = [Environment]::GetFolderPath('Desktop')
$shortcutPath = Join-Path $Desktop ($ShortcutName + '.lnk')
$shortcut = $WScriptShell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $Target
$shortcut.WorkingDirectory = Split-Path $Target
$shortcut.WindowStyle = 1
if ($IconPath -and (Test-Path $IconPath)) {
    $shortcut.IconLocation = $IconPath
} else {
    $shortcut.IconLocation = "$Target,0"
}
$shortcut.Save()
Write-Output "Created shortcut on desktop: $shortcutPath"
