const $ = (id) => document.getElementById(id);
const queryAll = (selector) => Array.from(document.querySelectorAll(selector));
const esc = (value) => String(value ?? '').replace(/[&<>'"]/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const safeUrl = (value) => {
  try {
    const u = new URL(String(value || ''));
    return (u.protocol === 'http:' || u.protocol === 'https:') ? u.href : '';
  } catch { return ''; }
};
const api = async (url, opts={}) => {
  const headers = opts.body ? {'Content-Type':'application/json'} : {};
  const res = await fetch(url, {headers, ...opts});
  const bodyText = await res.text().catch(() => '');
  const data = bodyText ? (() => { try { return JSON.parse(bodyText); } catch { return null; } })() : null;
  if(!res.ok){
    const detail = data?.detail || data?.error || `${res.status} ${res.statusText}`;
    throw new Error(typeof detail === 'string' ? detail : JSON.stringify(detail));
  }
  return data ?? {};
};
const fmt = (n, d=2) => (n === null || n === undefined || Number.isNaN(Number(n))) ? '-' : Number(n).toLocaleString('en-US',{maximumFractionDigits:d});
const fmtPrice = (n) => (n === null || n === undefined || Number.isNaN(Number(n))) ? '-' : Number(n).toLocaleString('en-US',{maximumFractionDigits:Number(n)<1?8:4});
const joinEsc = (items, sep=' • ') => (items || []).map(esc).join(sep);
const formatTehranTime = (value) => {
  if (!value) return '-';
  const date = new Date(value);
  if (Number.isNaN(date.valueOf())) return String(value);
  return new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Tehran',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  }).format(date) + ' تهران';
};
const formatSymbolDisplay = (exchange, symbol) => {
  const base = String(symbol || '').trim();
  if (!base) return '-';
  if (String(exchange).toLowerCase() === 'binance-futures' && base.endsWith('USDT')) {
    return `${base}.P`;
  }
  return base;
};
const formatVenueLabel = (exchange) => {
  if (!exchange) return '';
  const lower = String(exchange).toLowerCase();
  if (lower === 'binance-futures') return 'Binance Futures';
  if (lower === 'lbank-contract') return 'LBank Contract';
  return exchange;
};
const SIGNAL_FORMULA_SUMMARY = 'Total = Technical + Liquidity + Volume + Bias - Risk';
function scoreChip(label, value, klass=''){
  const numeric = typeof value === 'number' && !Number.isNaN(value);
  const empty = value === null || value === undefined || value === '';
  const display = numeric ? fmt(value,1) : (empty ? '-' : esc(value));
  return `<span class="formulaChip ${klass}"><strong>${esc(label)}</strong> <span class="formulaValue">${display}</span></span>`;
}
function signalFormulaHtml(s){
  const fields = [
    ['technical_score','Technical',''],
    ['trend_score','Trend',''],
    ['liquidity_score','Liquidity',''],
    ['volume_score','Volume',''],
    ['bias_score','Bias',''],
    ['risk_score','Risk','negative'],
    ['trap_score','Trap','trap'],
    ['execution_score','Execution','']
  ];
  const chips = [];
  for(const [key,label,klass] of fields){
    const value = s[key];
    if (value !== null && value !== undefined && !Number.isNaN(Number(value))){
      chips.push(scoreChip(label, Number(value), klass));
    }
  }
  const total = typeof s.score === 'number' ? fmt(s.score,1) : null;
  const formulaText = `${total ? 'Total ' + total : 'Score'} = Technical + Liquidity + Volume + Bias - Risk`;
  return `<div class="formulaBox"><div class="formulaLabel">Formula</div><div class="formulaTotal">${esc(formulaText)}</div><div class="formulaSegments">${chips.join('')}</div></div>`;
}
const TABS = queryAll('.tab');
const TAB_PANES = queryAll('.tabpage');
const STATUS_TEXT = $('statusText');
const LOOP_DOT = $('loopDot');
const LOG_OUTPUT = $('logs');
const MARKET_BIAS = $('marketBias');
const PROBE_RESULT = $('probeResult');
const PROGRESS_EL = $('progress');
const SIGNAL_COUNT = $('signalCount');
const SKIP_COUNT = $('skipCount');
const SCAN_SECONDS = $('scanSeconds');
const LAST_SCAN = $('lastScan');
let pollInProgress = false;
let marketInProgress = false;
let visibleSignalCount = 0;

function setText(el, value){ if(el) el.textContent = value ?? ''; }

function getValidTab(name){
  return TABS.some((b) => b.dataset.tab === name) ? name : 'signals';
}
function setTab(name, opts={}){
  const next = getValidTab(name);
  TABS.forEach((b) => b.classList.toggle('active', b.dataset.tab === next));
  TAB_PANES.forEach((p) => p.classList.toggle('active', p.id === `tab-${next}`));
  if (opts.updateHash !== false) {
    const nextHash = `#${next}`;
    if (window.location.hash !== nextHash) {
      if (opts.replaceHash === true) history.replaceState({tab: next}, '', nextHash);
      else history.pushState({tab: next}, '', nextHash);
    }
  }
  const tabsPanel = document.querySelector('.tabs');
  if (opts.scroll !== false && tabsPanel) {
    tabsPanel.scrollIntoView({block: 'start', behavior: opts.smooth === false ? 'auto' : 'smooth'});
  }
}
TABS.forEach((b) => b.addEventListener('click', (event) => {
  event.preventDefault();
  setTab(b.dataset.tab);
}));
window.addEventListener('popstate', () => setTab((window.location.hash || '#signals').slice(1), {updateHash:false, scroll:false}));
window.addEventListener('hashchange', () => setTab((window.location.hash || '#signals').slice(1), {updateHash:false, scroll:false}));

function goSignals(){
  setTab('signals', {smooth:true});
}

async function withBusy(button, fn){
  if(!button || button.disabled) return;
  button.disabled = true;
  const oldText = button.textContent;
  button.textContent = 'در حال اجرا...';
  try { return await fn(); }
  finally { button.disabled = false; button.textContent = oldText; }
}

const parseNumberField = (el) => {
  if (!el) return null;
  const text = String(el.value ?? '').trim();
  return text === '' ? null : Number(text);
};

async function loadSettings(){
  const s = await api('/api/settings');
  for(const [k,v] of Object.entries(s)){
    const el = $(k);
    if(!el) continue;
    if(el.type === 'checkbox') el.checked = !!v;
    else el.value = v === null || v === undefined ? '' : v;
  }
}
async function saveSettings(){
  const fields = ['max_price','min_quote_volume','min_abs_price_change_pct','min_24h_range_pct','target_request_weight_per_min','depth_limit','kline_limit_1m','kline_limit_5m','kline_limit_15m','kline_limit_1h','lbank_min_quote_volume','lbank_max_spread_pct','min_depth_1pct_usd','lbank_min_depth_1pct_usd','max_data_age_sec','max_symbols','score_threshold','early_watch_threshold','early_confirm_threshold','trap_threshold','early_volume_spike','cooldown_minutes','scan_interval_sec','concurrent_requests','max_spread_pct','min_volume_spike_for_trigger','capital_usdt','risk_per_trade_pct','max_total_open_risk_pct','leverage','btc_overbought_rsi','btc_overbought_long_penalty','btc_overbought_required_volume_spike','btc_low_volume_ratio_threshold','btc_macd_bearish_long_penalty','hard_block_long_if_1h_move_above','anti_chase_penalty','min_taker_buy_ratio_for_long','max_taker_buy_ratio_for_short','max_mark_index_premium_pct','crowded_funding_abs_threshold','binance_weight_budget_per_min','chart_confirmation_min_score','chart_min_volume_spike','chart_bollinger_overextension_rsi','chart_short_overextension_rsi','positive_narrative_bonus','negative_news_penalty','listing_or_etf_bonus','major_asset_stability_bonus','unknown_microcap_risk_penalty','max_trade_vs_daily_volume_pct','max_cross_feed_price_deviation_pct','alpaca_spread_warning_pct','cross_feed_disagreement_penalty'];
  const checks = ['include_binance_futures','include_lbank_contract','include_low_liquidity','rate_limit_safe_mode','strict_live_data','require_depth','require_open_interest','require_taker_flow','require_funding','market_regime_filter','allow_lbank_partial_derivatives','early_warning_enabled','meme_mode','early_confirmed_to_signals','dex_context_enabled','coingecko_context_enabled','binance_microstructure_enabled','use_usds_futures_universe','use_dynamic_spread_threshold','use_dynamic_depth_threshold','use_dynamic_volume_filter','use_percentile_thresholds','use_open_interest_score','use_open_interest_delta','use_funding_score','use_mark_index_premium','use_taker_flow_score','crowded_funding_penalty_enabled','use_chart_confirmation','use_kraken_news_context','news_risk_penalty_enabled','security_issue_hard_block','use_liquidity_tier','use_alpaca_cross_feed_validation','zero_volume_bar_warning','ui_signal_explainability','ui_why_no_signal_panel','ui_risk_badges','ui_source_health_cards','ui_model_confidence_meter'];
  const payload = {prefer_side:$('prefer_side').value};
  for(const f of fields){
    const el=$(f);
    const value = parseNumberField(el);
    if (value !== null) payload[f] = value;
  }
  for(const f of checks){ const el=$(f); if(el) payload[f] = !!el.checked; }
  try{
    await api('/api/settings',{method:'POST', body:JSON.stringify(payload)});
    setText(STATUS_TEXT, 'تنظیمات ذخیره شد');
  }catch(e){
    setText(STATUS_TEXT, `خطای تنظیمات: ${esc(e.message)}`);
  }
}
function gatesHtml(gates){
  if(!gates) return '';
  const labels = {live_required_sources_ok:'Live sources',data_fresh_ok:'Fresh',price_ok:'Price',liquidity_ok:'Liquidity',execution_spread_ok:'Spread',depth_1pct_ok:'Depth',volume_trigger_ok:'Volume',technical_trigger_ok:'Trigger',anti_extreme_chase_ok:'No FOMO',btc_overbought_volume_ok:'BTC Context',mark_index_premium_ok:'Mark/Index',taker_flow_ok:'Taker Flow',chart_confirmation_ok:'Chart',news_security_ok:'News Risk',cross_feed_ok:'Cross-Feed'};
  return `<div class="gates">${Object.entries(gates).map(([k,v])=>`<span class="gate ${v?'ok':'bad'}">${v?'✓':'×'} ${esc(labels[k]||k)}</span>`).join('')}</div>`;
}
function microstructureHtml(metrics){
  const m = metrics?.binance_microstructure;
  if(!m || m.enabled === false) return '';
  const parts = [
    ['Spread Gate', m.dynamic_spread_gate_pct !== undefined ? `${fmt(m.dynamic_spread_gate_pct,3)}%` : '-'],
    ['Depth Gate', m.dynamic_depth_gate_usdt !== undefined ? fmt(m.dynamic_depth_gate_usdt,0) : '-'],
    ['Taker Buy', m.taker_buy_ratio !== null && m.taker_buy_ratio !== undefined ? `${fmt(Number(m.taker_buy_ratio)*100,1)}%` : '-'],
    ['Mark Premium', m.mark_index_premium_pct !== null && m.mark_index_premium_pct !== undefined ? `${fmt(m.mark_index_premium_pct,4)}%` : '-'],
    ['OI', m.open_interest?.available ? `${fmt(m.open_interest.oi_change_pct,2)}%` : '-'],
    ['Funding', m.funding?.available ? fmt(m.funding.funding_rate,6) : '-']
  ];
  return `<div class="formulaBox"><div class="formulaLabel">Binance Microstructure</div><div class="formulaSegments">${parts.map(([k,v])=>scoreChip(k,v)).join('')}</div></div>`;
}
function modelConfidenceHtml(metrics){
  const c = metrics?.model_confidence;
  if(!c) return '';
  const comps = c.components || {};
  const chart = comps.chart_confirmation || {};
  const liq = comps.liquidity_tier || {};
  const news = comps.news_risk || {};
  const cross = comps.cross_feed_validation || {};
  const parts = [
    ['Confidence', `${fmt(c.score,1)} / ${esc(c.level||'-')}`],
    ['Chart L/S', `${fmt(chart.long_score,0)} / ${fmt(chart.short_score,0)}`],
    ['Liquidity', `${esc(liq.tier||'-')} (${fmt(liq.score,0)})`],
    ['News', `${esc(news.level||'-')}`],
    ['Cross-feed', `${esc(cross.risk_level||'-')}`]
  ];
  return `<div class="formulaBox multi"><div class="formulaLabel">Multi-source Confidence</div><div class="formulaSegments">${parts.map(([k,v])=>scoreChip(k,v)).join('')}</div></div>`;
}

function channelBlock(s){
  if(!s.channel_text) return '';
  return `<pre class="channelText">${esc(s.channel_text)}</pre>`;
}
function levelBadge(level){
  const cls = level === 'CONFIRMED' ? 'ok' : (level === 'TRAP' ? 'bad' : 'watch');
  return `<span class="gate ${cls}">${esc(level || 'INFO')}</span>`;
}
function renderEarly(rows){
  if(!rows.length){ $('early').innerHTML='<div class="empty">هنوز Early Warning نداریم.</div>'; return; }
  $('early').innerHTML = `<table><thead><tr><th>Level</th><th>Symbol</th><th>Dir</th><th>Final</th><th>Move</th><th>Trap</th><th>Execution</th><th>1m%</th><th>VolSpike1m</th><th>Spread</th><th>Reasons</th><th>Trap Reasons</th></tr></thead><tbody>${rows.map(r=>{
    const e = r.early_warning || {};
    return `<tr><td>${levelBadge(e.level)}</td><td><b>${esc(r.exchange||'-')}:${esc(r.symbol)}</b><br><small>${esc(r.venue_tag||'')}</small></td><td>${esc(e.direction||'-')}</td><td><b>${fmt(e.final_score,1)}</b></td><td>${fmt(e.move_score,1)}</td><td>${fmt(e.trap_score,1)}</td><td>${fmt(e.execution_score,1)}</td><td>${fmt(e.change_1m,2)}</td><td>${fmt(e.volume_spike_1m,2)}x</td><td>${fmt(r.spread_pct,3)}</td><td><small>${joinEsc(e.reasons)}</small></td><td><small>${joinEsc(e.trap_reasons)}</small></td></tr>`;
  }).join('')}</tbody></table>`;
}

const currentNumberSetting = (id, fallback) => {
  const el = $(id);
  const n = Number(el?.value);
  return Number.isFinite(n) ? n : fallback;
};
function failedGateNames(gates){
  return Object.entries(gates || {}).filter(([,v]) => v === false).map(([k]) => k);
}
function signalLevelInfo(s){
  const score = Number(s.score || 0);
  const confirmedThreshold = currentNumberSetting('score_threshold', 72);
  const earlyThreshold = currentNumberSetting('early_confirm_threshold', 66);
  const failed = failedGateNames(s.hard_gates);
  const cautionGates = new Set(['taker_flow_ok','anti_late_chase_ok','anti_extreme_chase_ok','chart_confirmation_ok','cross_feed_ok','mark_index_premium_ok','news_security_ok','btc_overbought_volume_ok']);
  const caution = failed.some((name) => cautionGates.has(name)) || (s.warnings || []).some((w) => !String(w).toLowerCase().includes('early-to-signal'));
  if (failed.includes('news_security_ok')) return {label:'TRAP / NEWS RISK', cls:'bad', note:'ریسک خبر/امنیت؛ فقط برای بررسی، نه سیگنال قطعی'};
  if (score < confirmedThreshold && score >= earlyThreshold) return {label:'EARLY SIGNAL', cls:'watch', note:'امتیاز هنوز زیر Confirmed است؛ ورود فقط با احتیاط و مدیریت ریسک'};
  if (caution) return {label:'CAUTION / WATCH ONLY', cls:'watch', note:'چند Gate نرم/کیفی هشدار داده‌اند؛ این کارت را سیگنال قطعی حساب نکن'};
  return {label:'CONFIRMED SIGNAL', cls:'ok', note:'Gateهای حیاتی و سطح امتیاز تأیید شده‌اند'};
}
function levelBannerHtml(info){
  return `<div class="signalLevel ${esc(info.cls)}"><span>${esc(info.label)}</span><small>${esc(info.note)}</small></div>`;
}
function renderSignals(rows, target='signals'){
  if (target === 'signals') {
    visibleSignalCount = rows.length;
    setText(SIGNAL_COUNT, visibleSignalCount);
  }
  if(!rows.length){ $(target).innerHTML = '<div class="empty">هنوز سیگنال واقعی ثبت نشده. برای علت، تب Skipped / ردشده‌ها و Data Health را چک کن.</div>'; return; }
  $(target).innerHTML = rows.map(s=>{
    const symbolDisplay = formatSymbolDisplay(s.exchange, s.symbol);
    const venueLabel = formatVenueLabel(s.exchange);
    const warningsHtml = (s.warnings||[]).length ? `<div class="hint">⚠ ${joinEsc(s.warnings)}</div>` : '';
    const formulaHtml = signalFormulaHtml(s);
    const level = signalLevelInfo(s);
    return `
    <article class="signal ${esc(level.cls)}">
      <div class="signalTop">
        <div><span class="badge ${s.side==='SHORT'?'short':'long'}">${esc(s.side)}</span> <span class="gate ${esc(level.cls)}">${esc(level.label)}</span> <strong>${esc(symbolDisplay)}</strong> <small>${esc(venueLabel)} • ${esc(formatTehranTime(s.ts))}</small></div>
        <div class="score">${fmt(s.score,1)} <small>${esc(s.grade)}</small></div>
      </div>
      ${levelBannerHtml(level)}
      <div class="reasons">${joinEsc(s.reasons)}</div>
      ${formulaHtml}
      ${microstructureHtml(s.metrics)}
      ${modelConfidenceHtml(s.metrics)}
      ${warningsHtml}
      ${gatesHtml(s.hard_gates)}
      <div class="plan">
        <div class="pill">Price<br><b>${fmtPrice(s.price)}</b></div>
        <div class="pill">Entry<br><b>${(s.plan?.entry_zone||[]).map(fmtPrice).join(' - ')}</b></div>
        <div class="pill">Stop<br><b>${fmtPrice(s.plan?.stop)}</b></div>
        <div class="pill">TPs<br><b>${fmtPrice(s.plan?.tp1)} / ${fmtPrice(s.plan?.tp2)} / ${fmtPrice(s.plan?.tp3)}</b></div>
      </div>
      ${channelBlock(s)}
    </article>`;
  }).join('');
}

function renderWatch(rows){
  if(!rows.length){ $('watchlist').innerHTML='<div class="empty">داده‌ای نیست.</div>'; return; }
  $('watchlist').innerHTML = `<table><thead><tr><th>Venue</th><th>Symbol</th><th>Early</th><th>Dir</th><th>Move</th><th>Trap</th><th>Exec</th><th>Price</th><th>Short</th><th>Long</th><th>Vol 24h</th><th>24h %</th><th>Range 24h</th><th>VSpike</th><th>Spread%</th><th>Depth±1%</th><th>Fresh</th><th>Coverage</th></tr></thead><tbody>${rows.map(r=>{
    const cov = r.source_coverage || {};
    const covText = Object.entries(cov).filter(([k,v])=>v===true).map(([k])=>k.replace('_',' ')).slice(0,6).join(', ');
    const e = r.early_warning || {};
    const symbolDisplay = formatSymbolDisplay(r.exchange, r.symbol);
    const venueLabel = formatVenueLabel(r.exchange);
    return `<tr><td>${esc(venueLabel)}</td><td><b>${esc(symbolDisplay)}</b><br><small>${esc(r.venue_tag||'')}</small></td><td>${levelBadge(e.level)}</td><td>${esc(e.direction||'-')}</td><td>${fmt(e.move_score,1)}</td><td>${fmt(e.trap_score,1)}</td><td>${fmt(e.execution_score,1)}</td><td>${fmtPrice(r.price)}</td><td>${fmt(r.short_score,1)}</td><td>${fmt(r.long_score,1)}</td><td>${fmt(r.quote_volume_24h,0)}</td><td>${fmt(r.price_change_24h,2)}</td><td>${fmt(r.range_24h_pct,2)}</td><td>${fmt(r.volume_spike,2)}x</td><td>${fmt(r.spread_pct,3)}</td><td>${fmt(r.depth_1pct_usd,0)}</td><td>${r.data_fresh_ok?'✅':'❌'}</td><td><small>${esc(covText)}</small></td></tr>`;
  }).join('')}</tbody></table>`;
}
function renderSkips(rows){
  if(!rows.length){ $('skips').innerHTML='<div class="empty">ردشده‌ای نیست.</div>'; return; }
  $('skips').innerHTML = rows.map(r=>`<article class="signal"><div class="signalTop"><b>${esc(formatSymbolDisplay(r.exchange, r.symbol))}</b><small>${esc(formatTehranTime(r.ts))}</small></div><div class="hint">${esc(r.reason)}</div><pre class="logs">${esc(JSON.stringify(r.details,null,2))}</pre></article>`).join('');
}
function renderHealth(rows){
  $('health').innerHTML = rows.map(h=>`<article class="signal"><div class="signalTop"><b>${h.ok?'✅':'❌'} ${esc(h.source)}</b><small>${esc(h.latency_ms ?? '-')} ms</small></div><div class="hint">${esc(h.error || JSON.stringify(h.details))}</div></article>`).join('');
}
function renderDex(rows){
  if(!rows.length){ $('dex').innerHTML='<div class="empty">DEX داده‌ای نداد.</div>'; return; }
  $('dex').innerHTML = `<table><thead><tr><th>Token</th><th>Chain</th><th>Score</th><th>Price</th><th>Liquidity</th><th>Vol24</th><th>Change24</th><th>Source</th><th>Link</th></tr></thead><tbody>${rows.map(r=>{
    const url = safeUrl(r.url);
    return `<tr><td><b>${esc(r.symbol||'-')}</b><br><small>${esc(r.name||'')}</small></td><td>${esc(r.chain_id)}</td><td>${fmt(r.score,1)}</td><td>${fmtPrice(r.price_usd)}</td><td>${fmt(r.liquidity_usd,0)}</td><td>${fmt(r.volume_24h,0)}</td><td>${fmt(r.price_change_24h,2)}</td><td>${esc(r.source)}</td><td>${url?`<a href="${esc(url)}" target="_blank" rel="noopener noreferrer">open</a>`:'-'}</td></tr>`;
  }).join('')}</tbody></table>`;
}
function renderCg(data){
  const coins = data?.data?.coins || [];
  if(!coins.length){ $('cg').innerHTML='<div class="empty">داده‌ای نیست.</div>'; return; }
  $('cg').innerHTML = `<table><thead><tr><th>Coin</th><th>Symbol</th><th>Market cap rank</th><th>BTC price</th></tr></thead><tbody>${coins.map(x=>x.item).map(c=>`<tr><td><b>${esc(c.name)}</b></td><td>${esc(c.symbol)}</td><td>${esc(c.market_cap_rank ?? '-')}</td><td>${fmt(c.price_btc,10)}</td></tr>`).join('')}</tbody></table><p class="hint">Fetched at: ${esc(data.fetched_at)}</p>`;
}

function backtestSymbolInput(){
  return ($('backtestSymbol').value || 'DOGEUSDT').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
}

function renderQuickBacktest(data){
  const target = $('backtestResult');
  if(!data || data.ok === false){
    target.innerHTML = `<div class="signal"><b>خطا</b><div class="hint">${esc(data?.error || data?.note || 'backtest failed')}</div></div>`;
    return;
  }
  if(data.side === 'BOTH' && data.results){
    const blocks = Object.entries(data.results).map(([side, result]) => {
      const rows = result.rows || [];
      const wins = rows.filter(r => r.success).length;
      const rate = rows.length ? ((wins / rows.length) * 100).toFixed(1) : '0.0';
      const table = rows.length ? `<table><thead><tr><th>Time</th><th>Price</th><th>Score</th><th>40m %</th><th>Success</th><th>Reasons</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(formatTehranTime(r.time))}</td><td>${fmtPrice(r.price)}</td><td>${fmt(r.score,1)}</td><td>${fmt(r.future_40m_pct,2)}</td><td>${r.success?'✅':'❌'}</td><td><small>${joinEsc(r.reasons)}</small></td></tr>`).join('')}</tbody></table>` : '<div class="empty">بدون hit</div>';
      return `<article class="signal"><div class="signalTop"><b>${esc(side)}</b><small>${esc(result.hits || 0)} hits • win rate ${esc(rate)}%</small></div>${table}</article>`;
    }).join('');
    target.innerHTML = `<div class="formula-overview">${esc(data.note || data.results?.LONG?.note || '')}</div>${blocks}`;
    return;
  }
  const rows = data.rows || [];
  const wins = rows.filter(r => r.success).length;
  const rate = rows.length ? ((wins / rows.length) * 100).toFixed(1) : '0.0';
  const table = rows.length ? `<table><thead><tr><th>Time</th><th>Price</th><th>Score</th><th>40m %</th><th>Success</th><th>Reasons</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(formatTehranTime(r.time))}</td><td>${fmtPrice(r.price)}</td><td>${fmt(r.score,1)}</td><td>${fmt(r.future_40m_pct,2)}</td><td>${r.success?'✅':'❌'}</td><td><small>${joinEsc(r.reasons)}</small></td></tr>`).join('')}</tbody></table>` : '<div class="empty">بدون hit</div>';
  target.innerHTML = `<article class="signal"><div class="signalTop"><b>${esc(data.symbol || '-')}</b><small>${esc(data.side || '-')} • ${esc(data.hits || 0)} hits • win rate ${esc(rate)}%</small></div><div class="hint">${esc(data.note || '')}</div>${table}</article>`;
}

function renderDetailedBacktest(data){
  const target = $('backtestResult');
  if(!data){
    target.innerHTML = '<div class="empty">داده‌ای دریافت نشد.</div>';
    return;
  }
  const trades = data.trades || [];
  const equity = data.equity_curve || [];
  const exits = trades.filter(t => t.action === 'EXIT');
  const pnlRows = exits.filter(t => t.realized_pnl !== undefined && t.realized_pnl !== null);
  const totalPnl = pnlRows.reduce((sum, t) => sum + Number(t.realized_pnl || 0), 0);
  const tradeTable = trades.length ? `<table><thead><tr><th>Side</th><th>Action</th><th>Price</th><th>Qty</th><th>PnL</th><th>Reason</th></tr></thead><tbody>${trades.slice(-40).map(t=>`<tr><td>${esc(t.side)}</td><td>${esc(t.action)}</td><td>${fmtPrice(t.price)}</td><td>${fmt(t.qty,4)}</td><td>${t.realized_pnl !== undefined ? fmt(t.realized_pnl,4) : '-'}</td><td>${esc(t.exit_reason || '-')}</td></tr>`).join('')}</tbody></table>` : '<div class="empty">بدون معامله</div>';
  target.innerHTML = `<article class="signal"><div class="signalTop"><b>Detailed Backtest</b><small>${esc(equity.length)} equity points • ${esc(trades.length)} trades</small></div><div class="plan"><div class="pill">Final Equity<br><b>${fmt(data.final_equity,2)}</b></div><div class="pill">Closed Trades<br><b>${esc(exits.length)}</b></div><div class="pill">Realized PnL<br><b>${fmt(totalPnl,4)}</b></div></div>${tradeTable}</article>`;
}

async function refreshTables(){
  await Promise.all([
    api('/api/signals?limit=80').then((data) => renderSignals(data.rows||[])).catch((e) => { console.warn('refreshTables signals failed', e); }),
    api('/api/snapshots?limit=180').then((data) => renderWatch(data.rows||[])).catch((e) => { console.warn('refreshTables snapshots failed', e); }),
    api('/api/skipped?limit=60').then((data) => renderSkips(data.rows||[])).catch((e) => { console.warn('refreshTables skips failed', e); }),
    api('/api/early?limit=120').then((data) => renderEarly(data.rows||[])).catch((e) => { console.warn('refreshTables early failed', e); }),
  ]);
}
async function loadMarket(){
  if(marketInProgress) return;
  marketInProgress = true;
  try{
    const m = await api('/api/market-context');
    const biasLabels = {
      risk_off: 'Risk-Off / بازار محتاط',
      risk_on: 'Risk-On / بازار ریسک‌پذیر',
      neutral: 'Neutral / بازار خنثی',
      unknown: 'Unknown'
    };
    const biasText = biasLabels[m.bias] || m.bias || '-';
    setText(MARKET_BIAS, `${biasText} | BTC 1h ${fmt(m.btc_change_1h,2)}% | ETH 1h ${fmt(m.eth_change_1h,2)}%`);
  }catch(e){ setText(MARKET_BIAS, 'unknown'); console.warn('loadMarket failed', e); }
  finally { marketInProgress = false; }
}
async function loadStatus(){
  try {
    const x = await api('/api/scan/status');
    const s = x.status || {};
    setText(STATUS_TEXT, s.message || 'idle');
    setText(PROGRESS_EL, `${s.progress_done || 0}/${s.progress_total || 0}`);
    if (visibleSignalCount === 0) setText(SIGNAL_COUNT, s.produced_signals || 0);
    setText(SKIP_COUNT, s.skipped_symbols || 0);
    setText(SCAN_SECONDS, s.last_scan_seconds ? `${s.last_scan_seconds}s` : '-');
    setText(LAST_SCAN, formatTehranTime(s.finished_at || s.started_at || '-'));
    LOG_OUTPUT.textContent = (x.logs||[]).join('\n');
    LOOP_DOT.className = `dot ${s.running ? 'run' : (s.loop_enabled ? 'on' : '')}`;
  } catch (e) {
    setText(STATUS_TEXT, 'خطای وضعیت بک‌اند');
    console.warn('loadStatus failed', e);
  }
}

$('saveSettings').onclick = ()=>withBusy($('saveSettings'), saveSettings);
$('goSignals').onclick = () => setTab('signals');
$('floatingSignals').onclick = goSignals;
$('scanNow').onclick = ()=>withBusy($('scanNow'), async()=>{ await api('/api/scan',{method:'POST'}); setTab('watchlist'); await loadStatus(); });
$('startLoop').onclick = ()=>withBusy($('startLoop'), async()=>{ await api('/api/loop/start',{method:'POST'}); await loadStatus(); });
$('stopLoop').onclick = ()=>withBusy($('stopLoop'), async()=>{ await api('/api/loop/stop',{method:'POST'}); await loadStatus(); });
$('healthBtn').onclick = ()=>withBusy($('healthBtn'), async()=>{ setTab('health'); $('health').innerHTML='<div class="empty">در حال چک منابع زنده...</div>'; const h=await api('/api/data-health'); renderHealth(h.sources||[]); });
$('loadDex').onclick = ()=>withBusy($('loadDex'), async()=>{ $('dex').innerHTML='<div class="empty">در حال دریافت داده زنده DEX...</div>'; const d=await api('/api/dex/radar'); renderDex(d.rows||[]); });
$('loadCg').onclick = ()=>withBusy($('loadCg'), async()=>{ $('cg').innerHTML='<div class="empty">در حال دریافت CoinGecko...</div>'; const d=await api('/api/coingecko/trending'); renderCg(d); });
$('probeBtn').onclick = ()=>withBusy($('probeBtn'), async()=>{
  const ex = $('probeExchange').value;
  const sym = ($('probeSymbol').value || 'GUAUSDT').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
  setTab('signals');
  $('probeResult').innerHTML = `<div class="empty">در حال تحلیل زنده ${esc(ex)}:${esc(sym)}...</div>`;
  try{
    const r = await api(`/api/analyze/${encodeURIComponent(ex)}/${encodeURIComponent(sym)}`);
    if(!r.ok){ $('probeResult').innerHTML = `<div class="signal"><b>خطا</b><div class="hint">${esc(r.error || r.detail || 'analysis failed')}</div></div>`; return; }
    if((r.signals||[]).length) renderSignals(r.signals, 'probeResult');
    else $('probeResult').innerHTML = `<div class="signal"><b>${esc(r.exchange)}:${esc(r.symbol)}</b><div class="hint">تحلیل انجام شد اما Hard Gate/Score اجازه سیگنال نداد. بخش Watchlist/Skipped را ببین.</div></div>`;
    await refreshTables();
  }catch(e){ $('probeResult').innerHTML = `<div class="signal"><b>خطا</b><div class="hint">${esc(e.message)}</div></div>`; }
});
$('runQuickBacktest').onclick = ()=>withBusy($('runQuickBacktest'), async()=>{
  const sym = backtestSymbolInput();
  const threshold = Number($('backtestThreshold').value || 78);
  const side = $('backtestSide').value || 'SHORT';
  setTab('backtest');
  $('backtestResult').innerHTML = `<div class="empty">در حال اجرای بک‌تست سریع ${esc(sym)}...</div>`;
  try{
    const data = await api(`/api/backtest/${encodeURIComponent(sym)}?threshold=${encodeURIComponent(threshold)}&side=${encodeURIComponent(side)}`);
    renderQuickBacktest(data);
  }catch(e){
    $('backtestResult').innerHTML = `<div class="signal"><b>خطا</b><div class="hint">${esc(e.message)}</div></div>`;
  }
});
$('loadDetailedBacktest').onclick = ()=>withBusy($('loadDetailedBacktest'), async()=>{
  const sym = backtestSymbolInput();
  setTab('backtest');
  $('backtestResult').innerHTML = `<div class="empty">در حال بارگذاری بک‌تست ذخیره‌شده ${esc(sym)}...</div>`;
  try{
    const data = await api(`/api/backtest/detailed/${encodeURIComponent(sym)}`);
    renderDetailedBacktest(data);
  }catch(e){
    $('backtestResult').innerHTML = `<div class="signal"><b>خطا</b><div class="hint">${esc(e.message)}</div></div>`;
  }
});

(async function boot(){
  setTab((window.location.hash || '#signals').slice(1), {replaceHash:true, scroll:false});
  try{ await loadSettings(); await loadStatus(); await refreshTables(); await loadMarket(); }
  catch(e){ setText(STATUS_TEXT, 'خطای اتصال به بک‌اند'); console.error(e); }
  setInterval(async()=>{ if(pollInProgress) return; pollInProgress = true; try{ await loadStatus(); await refreshTables(); }catch(e){ console.warn(e); } finally { pollInProgress = false; } }, 5000);
  setInterval(() => { if(!pollInProgress) loadMarket().catch((e)=>console.warn(e)); }, 30000);
})();
