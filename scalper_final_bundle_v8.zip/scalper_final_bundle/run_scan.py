from app.data.binance_futures import scan_symbols
import json

matches = scan_symbols(price_lt=1.0, vol24_gt=100_000.0, limit=500)
print(json.dumps(matches, indent=2))
