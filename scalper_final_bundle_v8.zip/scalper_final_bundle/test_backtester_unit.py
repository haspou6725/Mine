import pandas as pd
from app.backtest.simple_backtester import backtest


def test_backtester_basic_unit():
    # tiny dataframe with 3 candles where a signal appears on first candle
    data = [
        {'open_time': 0, 'open': 100.0, 'signal': 1},
        {'open_time': 60, 'open': 101.0, 'signal': 0},
        {'open_time': 120, 'open': 102.0, 'signal': 0},
    ]
    df = pd.DataFrame(data)
    res = backtest(df, initial_capital=1000.0, position_size_pct=0.1, profit_target=0.01, stop_loss=0.02)
    assert 'final_equity' in res
    assert isinstance(res['final_equity'], float)
    assert isinstance(res.get('trades', []), list)
    assert isinstance(res.get('equity_curve', []), list)
    assert len(res.get('equity_curve', [])) >= 1
