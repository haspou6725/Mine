@echo off
setlocal
cd /d "%~dp0"
python tools\binance_feature_export.py --symbol BTCUSDT --interval 5m --limit 500
pause
