# Signal Flow Fix Report

این نسخه برای رفع مشکل «صفر بودن سیگنال‌ها» ساخته شد. هدف این نبود که داده ساختگی تولید شود؛ هدف این بود که فیلترهای بیش از حد سخت‌گیرانه، مخصوصاً وابستگی به endpointهای مشتقه‌ای که گاهی روی اتصال عمومی timeout/ratelimit می‌شوند، باعث صفر شدن کامل خروجی نشوند.

## تغییرات تنظیمات پیش‌فرض

- `score_threshold`: 78 → 72
- `early_watch_threshold`: 52 → 48
- `early_confirm_threshold`: 72 → 66
- `early_volume_spike`: 1.40 → 1.25
- `min_volume_spike_for_trigger`: 1.70 → 1.35
- `max_spread_pct`: 0.22 → 0.28
- `min_depth_1pct_usd`: 70,000 → 45,000
- `early_confirmed_to_signals`: false → true
- `require_open_interest`: true → false
- `require_taker_flow`: true → false
- `require_funding`: true → false
- `require_depth`: true باقی ماند
- `strict_live_data`: true باقی ماند

## تغییرات منطق انتشار سیگنال

قبلاً انتشار سیگنال فقط وقتی انجام می‌شد که همه Gateها بدون استثنا `True` باشند. این باعث می‌شد حتی Gateهای زمینه‌ای مثل وضعیت کلی بازار یا anti-late-chase هم خروجی را کامل صفر کنند.

در نسخه جدید Gateها دو سطحی شدند:

### Gateهای حیاتی که هنوز اجباری هستند

- live_required_sources_ok
- data_fresh_ok
- price_ok
- liquidity_ok
- execution_spread_ok
- depth_1pct_ok
- volume_trigger_ok
- technical_trigger_ok
- risk_plan_stop_ok

### Gateهای نرم که هشدار و جریمه امتیاز می‌دهند، ولی به‌تنهایی سیگنال را صفر نمی‌کنند

- market_regime_ok
- anti_late_chase_ok

## Early Warning به Signal

هشدارهای Early که سطح `CONFIRMED` بگیرند، اگر trap و execution و freshness مناسب باشد، می‌توانند وارد Signals شوند. شرط امتیاز Early حالا با `early_confirm_threshold` سنجیده می‌شود، نه `score_threshold` عمومی.

## دیباگ بهتر

اگر امتیاز LONG/SHORT از threshold عبور کند ولی Gate حیاتی رد شود، علت در `/api/skipped` ذخیره می‌شود تا مشخص باشد دقیقاً کدام Gate جلوی انتشار را گرفته است.

## تست‌ها

- pytest: 26 passed, 1 warning
- Backend smoke: `/api/health`, `/api/settings`, `/api/signals?min_score=0`, `/api/skipped` پاسخ سالم دادند.
- project_audit quick: ok=true, high=0, medium=0, low=0

## نکته ایمنی

پروژه همچنان هیچ سفارش واقعی ارسال نمی‌کند و فقط آموزشی/تحلیلی/Simulation است. این اصلاحات فقط منطق نمایش و انتشار سیگنال تحلیلی را عملی‌تر کرده‌اند.
