@echo off
SETLOCAL EnableExtensions
SET "REPO_ROOT=%~dp0"
CD /D "%REPO_ROOT%"
SET "PYTHONPATH=%REPO_ROOT%"
SET "SCALPER_SAFE_MODE=1"
SET "SCALPER_ORDER_EXECUTION=0"
IF "%SCALPER_STREAMLIT_PORT%"=="" SET "SCALPER_STREAMLIT_PORT=8501"
SET "VENV_PY=%REPO_ROOT%.venv\Scripts\python.exe"
IF NOT EXIST "%VENV_PY%" (
    echo [ERROR] Virtual environment not found. Run START_ONE_CLICK.bat first.
    PAUSE
    EXIT /B 1
)
"%VENV_PY%" -m streamlit run "%REPO_ROOT%streamlit_dashboard_v2.py" --server.address 127.0.0.1 --server.port %SCALPER_STREAMLIT_PORT%
