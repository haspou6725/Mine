# Web Navigation Fix Report

## Fixed issues

1. **One-click launcher opened two browser pages**
   - `START_ONE_CLICK.bat` now opens only the main FastAPI web UI by default.
   - Streamlit is still available, but optional: run `set SCALPER_START_STREAMLIT=1 & START_ONE_CLICK.bat` if needed.

2. **Could not easily return to Signals after moving to another tab**
   - Added a persistent floating `↩ Signals` button that is always visible.
   - Kept the top `بازگشت به Signals` button.
   - Made the tab bar sticky so the tab buttons remain accessible while scrolling.
   - Improved tab/hash synchronization so browser Back/Forward and tab clicks remain consistent.

3. **Backtest tab behavior**
   - Backtest buttons stay inside the same dashboard page.
   - Buttons use `type="button"`, so they do not submit or navigate unexpectedly.

## Validation

- `pytest`: 19 passed, 1 warning
- `project_audit quick`: ok=true, high=0, medium=0, low=0

## Safety

No real order execution was added or enabled. The project remains simulation/analytics only.
