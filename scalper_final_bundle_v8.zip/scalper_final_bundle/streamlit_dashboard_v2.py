import streamlit as st
import httpx
import json
from pathlib import Path
import pandas as pd
import numpy as np
import altair as alt

from project_paths import PROJECT_ROOT, SIGNALS_MASTER, RISK_SUMMARY, PORTFOLIO_SNAPSHOT, BACKTESTS_DIR

st.set_page_config(page_title='Scalper Dashboard v6.4', layout='wide')

BACKEND_BASE = 'http://127.0.0.1:8787'
FILES_ROOT = PROJECT_ROOT

st.title('Meme-coin Scalper — Dashboard v6.4')
st.caption('Educational analytics/simulation only — no real exchange orders are sent.')

col1, col2 = st.columns([2,1])

with col1:
    st.subheader('Live Market Snapshot (Binance Public)')
    symbol = st.text_input('Symbol (e.g. BTCUSDT)', value='BTCUSDT')
    if st.button('Fetch Live Ticker'):
        try:
            r = httpx.get(f'https://fapi.binance.com/fapi/v1/ticker/24hr?symbol={symbol}', timeout=10.0)
            r.raise_for_status()
            data = r.json()
            st.json(data)
        except Exception as e:
            st.error(f'Error fetching ticker: {e}')

    st.subheader('Recent Signals')
    signals_loaded = False
    try:
        r = httpx.get(f'{BACKEND_BASE}/api/signals?limit=50', timeout=3.0)
        if r.status_code == 200:
            payload = r.json()
            rows = payload.get('rows', [])
            if rows:
                df = pd.DataFrame(rows)
                if 'score' in df.columns:
                    df = df.sort_values('score', ascending=False)
                st.dataframe(df.head(50))
                try:
                    csv_bytes = df.to_csv(index=False).encode('utf-8')
                    st.download_button('Download signals CSV', data=csv_bytes, file_name='live_signals.csv', mime='text/csv')
                except Exception:
                    pass
                signals_loaded = True
    except Exception:
        pass

    if not signals_loaded:
        signals_file = SIGNALS_MASTER
        if signals_file.exists():
            try:
                with open(signals_file, 'r', encoding='utf-8') as fh:
                    master = json.load(fh)
                df = pd.DataFrame(master)
                if not df.empty:
                    if 'score' in df.columns:
                        df = df.sort_values('score', ascending=False)
                    st.dataframe(df.head(50))
                    try:
                        csv_bytes = df.to_csv(index=False).encode('utf-8')
                        st.download_button('Download signals CSV', data=csv_bytes, file_name='scan_results_master.csv', mime='text/csv')
                    except Exception:
                        pass
                else:
                    st.info('Signals file empty')
            except Exception as e:
                st.error(f'Error reading signals: {e}')
        else:
            st.info('Signals not found — start backend scan or run scanning/tuning to generate signals')

    st.subheader('Risk Metrics Summary')
    risk_file = RISK_SUMMARY
    if risk_file.exists():
        try:
            with open(risk_file, 'r', encoding='utf-8') as fh:
                risks = json.load(fh)
            rdf = pd.DataFrame(risks)
            if not rdf.empty:
                sort_cols = [c for c in ['elapsed_days', 'cagr'] if c in rdf.columns]
                if sort_cols:
                    rdf = rdf.sort_values(sort_cols, ascending=[False] * len(sort_cols))
                st.dataframe(rdf.head(50))
                try:
                    csv_bytes_r = rdf.to_csv(index=False).encode('utf-8')
                    st.download_button('Download risk metrics CSV', data=csv_bytes_r, file_name='risk_metrics_summary.csv', mime='text/csv')
                except Exception:
                    pass
            else:
                st.info('Risk file empty')
        except Exception as e:
            st.error(f'Error reading risk metrics: {e}')
    else:
        st.info('Risk metrics file not found — run compute_risk_metrics')

with col2:
    st.subheader('Portfolio Snapshot (Simulated)')
    port_file = PORTFOLIO_SNAPSHOT
    if port_file.exists():
        try:
            with open(port_file, 'r', encoding='utf-8') as fh:
                port = json.load(fh)
            st.json(port)
        except Exception as e:
            st.error(f'Error reading portfolio: {e}')
    else:
        st.info('Portfolio snapshot not found — run portfolio simulation')

    st.subheader('Backend Health / Safety')
    try:
        r = httpx.get(f'{BACKEND_BASE}/api/health', timeout=3.0)
        if r.status_code == 200:
            st.success('Backend reachable')
            payload = r.json()
            st.write(payload)
            if payload.get('real_order_execution_enabled') is False:
                st.success('Safety: real order execution is disabled')
        else:
            st.warning(f'Backend responded: {r.status_code}')
    except Exception as e:
        st.error(f'Backend unreachable: {e}')

st.markdown('---')

st.header('Backtest Explorer')
cols = st.columns([1, 2])
with cols[0]:
    symbol_choice = st.text_input('Symbol for backtest', value='DOGEUSDT').upper()
    bt_threshold = st.number_input('Score threshold', min_value=1, max_value=100, value=72, step=1)
    bt_side = st.selectbox('Side', ['SHORT', 'LONG', 'BOTH'])

    if st.button('Run Live Quick Backtest'):
        try:
            r = httpx.get(
                f'{BACKEND_BASE}/api/backtest/{symbol_choice}',
                params={'threshold': bt_threshold, 'side': bt_side},
                timeout=30.0,
            )
            r.raise_for_status()
            payload = r.json()
            st.session_state['_quick_backtest'] = payload
            st.session_state.pop('_backtest_df', None)
            st.session_state.pop('_backtest_trades', None)
        except Exception as e:
            st.error(f'Live backtest failed: {e}')

    if st.button('Load Saved Detailed Backtest'):
        candidate = BACKTESTS_DIR / f'{symbol_choice}.json'
        if candidate.exists():
            try:
                with open(candidate, 'r', encoding='utf-8') as fh:
                    b = json.load(fh)
                eq = b.get('equity_curve', [])
                trades = b.get('trades', [])
                if eq:
                    df = pd.DataFrame(eq).dropna(subset=['equity']).reset_index(drop=True)
                    if 'ts' in df.columns:
                        df['ts_readable'] = pd.to_datetime(df['ts'], unit='ms', errors='coerce')
                    else:
                        df['ts_readable'] = pd.RangeIndex(start=0, stop=len(df))
                    st.session_state['_backtest_df'] = df
                    st.session_state['_backtest_trades'] = trades
                    st.session_state.pop('_quick_backtest', None)
                else:
                    st.info('No equity curve in file')
            except Exception as e:
                st.error(f'Error reading file: {e}')
        else:
            st.info('Backtest file not found')

with cols[1]:
    if '_quick_backtest' in st.session_state:
        payload = st.session_state['_quick_backtest']
        st.subheader('Quick Backtest (Live API)')
        if payload.get('side') == 'BOTH' and payload.get('results'):
            for side, result in payload['results'].items():
                rows = result.get('rows', [])
                wins = sum(1 for row in rows if row.get('success'))
                rate = (wins / len(rows) * 100) if rows else 0.0
                st.markdown(f'**{side}** — {result.get("hits", 0)} hits, win rate {rate:.1f}%')
                if result.get('note'):
                    st.caption(result['note'])
                if rows:
                    st.dataframe(pd.DataFrame(rows))
        else:
            rows = payload.get('rows', [])
            wins = sum(1 for row in rows if row.get('success'))
            rate = (wins / len(rows) * 100) if rows else 0.0
            st.markdown(f'**{payload.get("symbol", symbol_choice)}** — {payload.get("hits", 0)} hits, win rate {rate:.1f}%')
            if payload.get('note'):
                st.caption(payload['note'])
            if payload.get('error'):
                st.warning(payload['error'])
            if rows:
                st.dataframe(pd.DataFrame(rows))
            elif payload.get('ok') is False:
                st.info('No hits returned')
    elif '_backtest_df' in st.session_state:
        df = st.session_state['_backtest_df']
        st.subheader('Equity Curve')
        chart_df = df[['ts_readable', 'equity']].dropna()
        if not chart_df.empty:
            chart = alt.Chart(chart_df).mark_line().encode(x='ts_readable:T', y='equity:Q').interactive()
            st.altair_chart(chart, use_container_width=True)
        st.subheader('Drawdown')
        eq = df['equity'].astype(float).values
        peak = np.maximum.accumulate(eq)
        dd = (peak - eq) / peak
        dd_df = pd.DataFrame({'ts_readable': df['ts_readable'], 'drawdown': dd})
        dd_chart = alt.Chart(dd_df).mark_area(color='orange').encode(x='ts_readable:T', y='drawdown:Q')
        st.altair_chart(dd_chart, use_container_width=True)
        trades = st.session_state.get('_backtest_trades', [])
        if trades:
            tdf = pd.DataFrame(trades)
            st.subheader('Trades')
            st.dataframe(tdf)
            if 'pnl' in tdf.columns:
                hist = alt.Chart(tdf).mark_bar().encode(x=alt.X('pnl:Q', bin=True), y='count()')
                st.altair_chart(hist, use_container_width=True)
    else:
        st.info('Run a live quick backtest or load a saved detailed backtest to see results')

st.write('Notes: Drawdown and per-trade PnL help diagnose risk. Always verify elapsed_days in risk report before trusting annualized metrics.')

st.sidebar.header('Utilities')
if st.sidebar.button('Refresh files'):
    st.rerun()

st.sidebar.markdown('For production use, authenticate and host the dashboard behind TLS.')
