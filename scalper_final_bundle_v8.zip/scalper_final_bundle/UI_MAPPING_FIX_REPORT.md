# UI Mapping / Signal Visibility Fix Report

Date: 2026-07-03
Base artifact: `scalper_final_bundle_MULTISOURCE_CONFIDENCE_READY.zip`
Output artifact: `scalper_final_bundle_UI_MAPPING_FIXED.zip`

## What was checked

The user-provided UI PDF showed that the scanner was running and signal cards were rendered, but three front-end presentation issues remained:

1. The dashboard counter showed `SIGNALS = 0` while visible signal cards existed.
2. Binance Microstructure chips showed `-` even when lower gate badges contained valid microstructure results.
3. Multi-source Confidence chips showed `-` even when Chart / News / Cross-feed gates were present.
4. Early/cautionary signals looked too similar to confirmed signals.

## Fixes applied

### 1. Visible signal counter

`merged_frontend/app.js` now updates the Signals counter from the actually rendered `/api/signals` rows. During scanning, backend status can still report in-progress scan counts, but once visible signals are rendered the top counter matches the visible cards.

### 2. Formula chip rendering

The `scoreChip()` function previously displayed only numeric values and rendered all string values as `-`. This caused labels such as `0.55%`, `HIGH`, `LOW`, `tier_1`, `UNAVAILABLE`, and formatted percentages to disappear.

The chip renderer now supports:

- numbers
- formatted strings
- enum labels
- unavailable values as `-`

### 3. Binance Microstructure card values

The following values now render correctly when available:

- Spread Gate
- Depth Gate
- Taker Buy
- Mark Premium
- Open Interest
- Funding

### 4. Multi-source Confidence card values

The following values now render correctly when available:

- Confidence score/level
- Chart long/short score
- Liquidity tier/score
- News risk
- Cross-feed risk

### 5. Signal level banner

Each signal card now shows a clear classification:

- `CONFIRMED SIGNAL`
- `EARLY SIGNAL`
- `CAUTION / WATCH ONLY`
- `TRAP / NEWS RISK`

This prevents early or soft-gate-warning cards from looking like fully confirmed entries.

### 6. UI polish

Added visual styling for signal level banners and caution/warning card borders.

## Validation

```text
pytest: 40 passed, 1 warning
compileall: OK via pytest/import coverage
project_audit quick: ok=true, high=0, medium=0, low=0
project_audit full: ok=true, high=0, medium=0, low=0
backend smoke:
  /api/health 200
  /api/settings 200
  /api/safety 200
  /api/signals 200
  /api/skipped 200
  /api/multisource/confidence?symbol=BTCUSDT 200
  /api/design/system 200
```

## Safety

No real trading execution was added. The system remains read-only / educational / analytical / simulation-only.
