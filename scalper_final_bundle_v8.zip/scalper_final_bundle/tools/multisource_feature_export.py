from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from project_paths import PROJECT_ROOT


def main() -> None:
    parser = argparse.ArgumentParser(description="Export latest snapshots with multi-source confidence fields.")
    parser.add_argument("--snapshots", default=str(PROJECT_ROOT / "signals" / "scan_results_master.json"))
    parser.add_argument("--output", default=str(PROJECT_ROOT / "reports" / "multisource_features.csv"))
    args = parser.parse_args()

    src = Path(args.snapshots)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    if src.exists():
        data = json.loads(src.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            rows = data.get("rows") or data.get("snapshots") or []
        elif isinstance(data, list):
            rows = data
    fields = [
        "symbol", "exchange", "price", "short_score", "long_score", "volume_spike", "spread_pct",
        "model_confidence_score", "model_confidence_level", "liquidity_tier", "news_risk_level",
        "cross_feed_risk", "chart_long_score", "chart_short_score",
    ]
    with out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in rows:
            m = r.get("metrics", r) if isinstance(r, dict) else {}
            conf = m.get("model_confidence") or {}
            comps = conf.get("components") or {}
            chart = comps.get("chart_confirmation") or m.get("chart_confirmation") or {}
            liq = comps.get("liquidity_tier") or m.get("liquidity_tier") or {}
            news = comps.get("news_risk") or m.get("news_risk") or {}
            cross = comps.get("cross_feed_validation") or m.get("cross_feed_validation") or {}
            writer.writerow({
                "symbol": m.get("symbol") or r.get("symbol"),
                "exchange": m.get("exchange") or r.get("exchange"),
                "price": m.get("price") or r.get("price"),
                "short_score": m.get("short_score") or r.get("short_score"),
                "long_score": m.get("long_score") or r.get("long_score"),
                "volume_spike": m.get("volume_spike"),
                "spread_pct": m.get("spread_pct"),
                "model_confidence_score": conf.get("score"),
                "model_confidence_level": conf.get("level"),
                "liquidity_tier": liq.get("tier"),
                "news_risk_level": news.get("level"),
                "cross_feed_risk": cross.get("risk_level"),
                "chart_long_score": chart.get("long_score"),
                "chart_short_score": chart.get("short_score"),
            })
    print(f"Wrote {out}")


if __name__ == "__main__":
    main()
