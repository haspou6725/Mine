from pathlib import Path
import sys
BASE = Path(__file__).resolve().parents[1] if Path(__file__).resolve().parent.name == "tools" else Path(__file__).resolve().parent
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))

import json
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

from project_paths import RISK_SUMMARY_INMEMORY, REPORTS_DIR

IN = RISK_SUMMARY_INMEMORY
OUT_DIR = REPORTS_DIR
OUT_DIR.mkdir(parents=True, exist_ok=True)

with IN.open('r',encoding='utf-8') as f:
    data = json.load(f)

df = pd.DataFrame(data)
# clean and sort
df['final_equity'] = pd.to_numeric(df['final_equity'], errors='coerce')
df = df.sort_values('final_equity', ascending=False)
# save CSV
csv = OUT_DIR / 'risk_metrics_report.csv'
df.to_csv(csv, index=False)
# top10 by final_equity
top10 = df.head(10)
plt.figure(figsize=(10,6))
plt.bar(top10['symbol'], top10['final_equity'].astype(float))
plt.xticks(rotation=45, ha='right')
plt.title('Top 10 Final Equity')
plt.tight_layout()
png1 = OUT_DIR / 'top10_final_equity.png'
plt.savefig(png1)
# top10 by sharpe
if 'sharpe' in df.columns:
    df_sh = df.sort_values('sharpe', ascending=False)
    top10s = df_sh.head(10)
    plt.figure(figsize=(10,6))
    plt.bar(top10s['symbol'], top10s['sharpe'].astype(float))
    plt.xticks(rotation=45, ha='right')
    plt.title('Top 10 Sharpe')
    plt.tight_layout()
    png2 = OUT_DIR / 'top10_sharpe.png'
    plt.savefig(png2)

print('WROTE', csv, png1)
if 'png2' in locals():
    print('WROTE', png2)
