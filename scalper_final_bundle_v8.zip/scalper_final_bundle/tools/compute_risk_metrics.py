from pathlib import Path
import sys
BASE = Path(__file__).resolve().parents[1] if Path(__file__).resolve().parent.name == "tools" else Path(__file__).resolve().parent
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))

import json
import glob
import math
import os
from pathlib import Path
import pandas as pd

from project_paths import BACKTESTS_DIR, REPORTS_DIR

IN_DIR = Path(os.environ.get("SCALPER_BACKTESTS_DIR", str(BACKTESTS_DIR)))
OUT_DIR = Path(os.environ.get("SCALPER_REPORTS_DIR", str(REPORTS_DIR)))
OUT_DIR.mkdir(parents=True, exist_ok=True)

summary = []

# configuration: minimum elapsed time (days) to consider CAGR meaningful
MIN_ELAPSED_DAYS = 7  # 1 week
MAX_ABS_CAGR = 10.0    # cap absolute CAGR to 1000% to avoid extreme values from tiny windows


def compute_drawdown(equity_series):
    peak = -math.inf
    max_dd = 0.0
    for v in equity_series:
        if v > peak:
            peak = v
        dd = (peak - v) / peak if peak > 0 else 0
        if dd > max_dd:
            max_dd = dd
    return max_dd


for f in glob.glob(str(IN_DIR / "*.json")):
    name = Path(f).stem
    try:
        with open(f, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        equity_curve = data.get('equity_curve', [])
        if not equity_curve:
            summary.append({'symbol': name, 'error': 'no equity_curve', 'final_equity': data.get('final_equity')})
            continue
        df = pd.DataFrame(equity_curve)
        if 'equity' not in df.columns:
            summary.append({'symbol': name, 'error': 'equity_missing_in_curve'})
            continue
        df = df.dropna(subset=['equity']).reset_index(drop=True)
        # compute returns per step
        df['ret'] = df['equity'].pct_change().fillna(0)

        # determine elapsed time in years from timestamps if present
        years = None
        elapsed_seconds = None
        if 'ts' in df.columns and len(df) >= 2:
            try:
                first_ts = int(df['ts'].iloc[0])
                last_ts = int(df['ts'].iloc[-1])
                # heuristic: ms timestamps are typically >= 1e12
                if first_ts > 1e12 or last_ts > 1e12:
                    first_ts_s = first_ts / 1000.0
                    last_ts_s = last_ts / 1000.0
                else:
                    first_ts_s = first_ts
                    last_ts_s = last_ts
                elapsed_seconds = max(1.0, last_ts_s - first_ts_s)
                years = elapsed_seconds / (3600.0 * 24.0 * 365.0)
            except Exception:
                years = None

        if years is None or years == 0:
            # fallback to minute-based assumption
            minutes_per_year = 525600
            periods_per_year = minutes_per_year
            years = len(df) / minutes_per_year if minutes_per_year > 0 else 1
        else:
            periods_per_year = len(df) / years if years > 0 else len(df)

        mean_ret = df['ret'].mean()
        std_ret = df['ret'].std(ddof=0)
        if std_ret == 0 or periods_per_year <= 0:
            sharpe = 0.0
        else:
            sharpe = (mean_ret / std_ret) * math.sqrt(periods_per_year)

        max_dd = compute_drawdown(df['equity'].tolist())

        # approximate CAGR using elapsed years, but guard short windows
        start = float(df['equity'].iloc[0])
        end = float(df['equity'].iloc[-1])
        cagr = None
        cagr_note = None
        if elapsed_seconds is not None:
            elapsed_days = elapsed_seconds / (3600.0 * 24.0)
        else:
            elapsed_days = years * 365.0 if years is not None else 0

        if elapsed_days < MIN_ELAPSED_DAYS:
            # window too short for meaningful CAGR
            cagr_note = f'elapsed_too_short ({elapsed_days:.2f} days)'
            cagr = None
        else:
            if years > 0 and start > 0:
                raw_cagr = (end / start) ** (1 / years) - 1
                # cap extreme values
                if math.isfinite(raw_cagr):
                    if abs(raw_cagr) > MAX_ABS_CAGR:
                        cagr = math.copysign(MAX_ABS_CAGR, raw_cagr)
                        cagr_note = 'capped'
                    else:
                        cagr = raw_cagr
                else:
                    cagr = None
                    cagr_note = 'non_finite'
            else:
                cagr = None
                cagr_note = 'invalid_years_or_start'

        entry = {
            'symbol': name,
            'final_equity': float(end),
            'trades': int(len(data.get('trades', []))),
            'sharpe': float(sharpe) if sharpe is not None else None,
            'max_drawdown': float(max_dd) if max_dd is not None else None,
            'cagr': float(cagr) if cagr is not None else None,
            'cagr_note': cagr_note,
            'elapsed_days': float(elapsed_days)
        }
        summary.append(entry)
    except Exception as e:
        summary.append({'symbol': name, 'error': str(e)})

summary_path = OUT_DIR / 'risk_metrics_summary.json'
with open(summary_path, 'w', encoding='utf-8') as of:
    json.dump(summary, of, ensure_ascii=False, indent=2)

# also write CSV (coerce None to empty)
pd.DataFrame(summary).to_csv(OUT_DIR / 'risk_metrics_summary.csv', index=False)
print('WROTE', summary_path)
