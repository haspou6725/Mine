"""
Auto improvement loop scaffold.
- Runs unit tests, recomputes risk metrics, checks tuning results, and optionally triggers actions.
- This script is interactive; run manually. It will loop until you press 'n'.

Safety: Does NOT enable live execution.
"""
import subprocess
import time
from pathlib import Path
import json

BASE = Path(__file__).resolve().parents[1]
REPORTS = BASE / 'reports'
TUNING = BASE / 'tuning_results_wide.json'

def run_tests():
    print('Running unit tests...')
    proc = subprocess.run(['pytest','-q','test_backtester_unit.py','test_executor_unit.py','test_compute_risk_metrics_unit.py','test_backtester_entry_timing.py','test_backtester_risk_rules.py'], cwd=str(BASE))
    return proc.returncode == 0

def recompute_metrics():
    print('Recomputing risk metrics...')
    subprocess.run(['python', str(BASE / 'tools' / 'compute_risk_metrics.py')])

def check_tuning():
    if TUNING.exists():
        try:
            with open(TUNING,'r',encoding='utf-8') as f:
                data = json.load(f)
            if len(data)>0:
                top = data[0]
                print('Top tuning config:', top.get('params'), 'mean_final_equity=', top.get('mean_final_equity'))
                return top.get('mean_final_equity')
        except Exception as e:
            print('Error reading tuning results:', e)
    else:
        print('No tuning_results_wide.json present yet')
    return None


def loop_once():
    ok = run_tests()
    if not ok:
        print('Tests failed — fix before continuing')
        return False
    recompute_metrics()
    top = check_tuning()
    return True

if __name__ == '__main__':
    print('Auto-improve loop started. Manual confirmation required to continue each iteration.')
    while True:
        cont = input('Run iteration? (Y/n): ').strip().lower() or 'y'
        if cont != 'y':
            print('Stopping loop.')
            break
        try:
            ok = loop_once()
            if not ok:
                print('Iteration found issues. Resolve them and re-run.')
                break
        except KeyboardInterrupt:
            print('Interrupted by user')
            break
        time.sleep(1)
