from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable

ROOT = Path(__file__).resolve().parents[1]

RUNTIME_DIR_NAMES = {".git", ".venv", "venv", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", "node_modules"}
RUNTIME_FILE_SUFFIXES = {".pyc", ".pyo", ".sqlite", ".sqlite3"}
RUNTIME_FILE_NAMES = {"live_signals.db", "live_signals.db-wal", "live_signals.db-shm"}
SECRET_RE = re.compile(
    r"(?i)(api[_-]?key|api[_-]?secret|secret[_-]?key|password|passwd|private[_-]?key|bearer\s+[a-z0-9._\-]{20,}|sk-[a-z0-9]{20,})"
)
REAL_ORDER_RE = re.compile(
    r"(?i)(/order\b|place_order\(|create_order\(|new_order\(|signed.*order|leverage.*endpoint|positionSide)"
)
SAFE_ORDER_ALLOWLIST = (
    "PortfolioSimulator",
    "LiveExecutor",
    "NotImplementedError",
    "هیچ سفارشی",
    "no order execution",
    "never sends orders",
    "educational",
    "simulation",
    "disabled",
)

SECRET_ALLOWLIST = (
    "FINANCIAL_DATASETS_API_KEY",
    "api_key: str | None = None",
    "self.config.api_key",
    "X-API-KEY",
    "API-key optional",
    "api key",
)

@dataclass
class Finding:
    severity: str
    area: str
    path: str
    message: str


def iter_files() -> Iterable[Path]:
    for path in ROOT.rglob("*"):
        if any(part in RUNTIME_DIR_NAMES for part in path.parts):
            continue
        if path.is_file():
            yield path


def rel(path: Path) -> str:
    try:
        return str(path.relative_to(ROOT)).replace("\\", "/")
    except ValueError:
        return str(path)


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return ""


def audit_structure() -> list[Finding]:
    findings: list[Finding] = []
    required = [
        "START_ONE_CLICK.bat",
        "RUN_BACKEND.bat",
        "RUN_STREAMLIT.bat",
        "requirements.txt",
        "merged_imports/scalper_meme_plus_backend/main.py",
        "merged_frontend/index.html",
        "streamlit_dashboard_v2.py",
        "data/settings.json",
    ]
    for item in required:
        if not (ROOT / item).exists():
            findings.append(Finding("HIGH", "structure", item, "Required project file is missing."))
    for path in iter_files():
        if path.name in RUNTIME_FILE_NAMES or path.suffix in RUNTIME_FILE_SUFFIXES:
            findings.append(Finding("MEDIUM", "cleanup", rel(path), "Runtime/cache/database file should not be included in a clean release."))
    return findings


def audit_security(mode: str) -> list[Finding]:
    findings: list[Finding] = []
    for path in iter_files():
        if path == Path(__file__).resolve():
            continue
        if path.suffix.lower() not in {".py", ".js", ".html", ".css", ".bat", ".ps1", ".md", ".txt", ".yml", ".yaml", ".json"}:
            continue
        text = read_text(path)
        if not text:
            continue
        for idx, line in enumerate(text.splitlines(), start=1):
            if SECRET_RE.search(line):
                if any(allowed in line for allowed in SECRET_ALLOWLIST):
                    continue
                # Terms inside explanatory docs/tests are lower risk but should still be visible in full mode.
                severity = "LOW" if path.suffix.lower() in {".md", ".txt"} or "NotImplementedError" in line else "MEDIUM"
                if mode == "quick" and severity == "LOW":
                    continue
                findings.append(Finding(severity, "secrets", f"{rel(path)}:{idx}", "Potential secret/key wording found; verify it is not a real credential."))
            if REAL_ORDER_RE.search(line):
                context = "\n".join(text.splitlines()[max(0, idx - 4): idx + 4])
                if not any(allowed in context for allowed in SAFE_ORDER_ALLOWLIST):
                    findings.append(Finding("HIGH", "execution", f"{rel(path)}:{idx}", "Potential real-order execution reference; must remain disabled/absent."))
    return findings


def audit_settings() -> list[Finding]:
    findings: list[Finding] = []
    settings_path = ROOT / "data" / "settings.json"
    try:
        settings = json.loads(settings_path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        return [Finding("HIGH", "settings", rel(settings_path), f"Settings JSON is not readable: {exc}")]
    expectations = {
        "strict_live_data": True,
        "include_binance_futures": True,
        "rate_limit_safe_mode": True,
    }
    for key, expected in expectations.items():
        if settings.get(key) is not expected:
            findings.append(Finding("MEDIUM", "settings", rel(settings_path), f"{key} should default to {expected!r} for safe release."))
    # Signal-ready profile: still strict about real live core data and execution quality,
    # but it allows confirmed early warnings and does not hard-require optional derivative
    # endpoints that are frequently unavailable/ratelimited on public connections.
    if float(settings.get("score_threshold", 0)) < 72:
        findings.append(Finding("MEDIUM", "settings", rel(settings_path), "score_threshold is below the signal-ready safety floor."))
    if settings.get("early_confirmed_to_signals") is True:
        if settings.get("strict_live_data") is not True or settings.get("require_depth") is not True:
            findings.append(Finding("MEDIUM", "settings", rel(settings_path), "early_confirmed_to_signals requires strict live data and order-book depth."))
    if float(settings.get("leverage", 0)) > 5:
        findings.append(Finding("LOW", "settings", rel(settings_path), "Default leverage is high for an educational risk planner."))
    if float(settings.get("risk_per_trade_pct", 0)) > 1:
        findings.append(Finding("LOW", "settings", rel(settings_path), "Default risk_per_trade_pct is above conservative demo sizing."))
    return findings


def build_report(mode: str) -> dict:
    files = list(iter_files())
    findings = audit_structure() + audit_settings() + audit_security(mode)
    sev_order = {"HIGH": 3, "MEDIUM": 2, "LOW": 1}
    findings.sort(key=lambda f: (-sev_order.get(f.severity, 0), f.area, f.path))
    passed = not any(f.severity in {"HIGH", "MEDIUM"} for f in findings)
    return {
        "ok": passed,
        "mode": mode,
        "project_root": str(ROOT),
        "file_count": len(files),
        "safety_contract": {
            "real_order_execution": "disabled by design",
            "active_backend": "merged_imports.scalper_meme_plus_backend.main:app",
            "default_bind_host": "127.0.0.1",
            "strict_live_data_default": True,
        },
        "findings": [asdict(f) for f in findings],
        "summary": {
            "high": sum(1 for f in findings if f.severity == "HIGH"),
            "medium": sum(1 for f in findings if f.severity == "MEDIUM"),
            "low": sum(1 for f in findings if f.severity == "LOW"),
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Offline project audit for the Scalper Meme+ package.")
    parser.add_argument("--mode", choices=["quick", "full"], default="quick")
    parser.add_argument("--output", type=Path, default=None)
    args = parser.parse_args()
    report = build_report(args.mode)
    payload = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload, encoding="utf-8")
    print(payload)
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
