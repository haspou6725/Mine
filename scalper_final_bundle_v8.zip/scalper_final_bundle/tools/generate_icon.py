from PIL import Image, ImageDraw, ImageFont
import os

# Determine desktop path (try OneDrive Desktop first)
user = os.environ.get('USERPROFILE')
desktop_candidates = [
    os.path.join(user, 'OneDrive', 'Desktop'),
    os.path.join(user, 'Desktop')
]

desktop = None
for p in desktop_candidates:
    if os.path.isdir(p):
        desktop = p
        break
if desktop is None:
    desktop = os.path.join(user, 'Desktop')

out_ico = os.path.join(desktop, 'ScalperDashboard.ico')

# Create base image
size = 512
img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
d = ImageDraw.Draw(img)

# background gradient
for i in range(size):
    r = int(10 + (30 - 10) * (i/size))
    g = int(20 + (180 - 20) * (i/size))
    b = int(40 + (50 - 40) * (i/size))
    d.line([(0, i), (size, i)], fill=(r, g, b))

# draw circular badge
cx, cy = size//2, size//2
radius = int(size*0.38)
for r in range(radius, 0, -1):
    # green ring gradient
    t = r / radius
    color = (int(20 + (180-20)*(1-t)), int(200*t + 40*(1-t)), int(40))
    d.ellipse((cx-r, cy-r, cx+r, cy+r), outline=color)

# fill inner circle
d.ellipse((cx-radius+6, cy-radius+6, cx+radius-6, cy+radius-6), fill=(12,24,36,220))

# draw lightning / S shape
try:
    # prefer a truetype font if available
    font_path = None
    possible = [
        os.path.join(os.environ.get('WINDIR', r'C:\Windows'), 'Fonts', 'seguisym.ttf'),
        os.path.join(os.environ.get('WINDIR', r'C:\Windows'), 'Fonts', 'arialbd.ttf')
    ]
    for p in possible:
        if os.path.exists(p):
            font_path = p
            break
    if font_path:
        font = ImageFont.truetype(font_path, int(size*0.34))
    else:
        font = ImageFont.load_default()

    text = 'SC'
    w, h = d.textsize(text, font=font)
    d.text((cx - w/2, cy - h/2), text, font=font, fill=(255,255,255,255))
except Exception:
    d.text((cx-40, cy-30), 'SC', fill=(255,255,255,255))

# save as ICO with multiple sizes
try:
    img.save(out_ico, format='ICO', sizes=[(256,256),(128,128),(64,64),(48,48),(32,32)])
    print('Icon saved to', out_ico)
except Exception as e:
    print('Failed to save icon:', e)
    # fallback: save PNG
    out_png = os.path.join(desktop, 'ScalperDashboard.png')
    img.save(out_png)
    print('PNG saved to', out_png)
