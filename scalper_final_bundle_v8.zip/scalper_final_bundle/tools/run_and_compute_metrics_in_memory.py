from __future__ import annotations

from pathlib import Path
import sys
BASE = Path(__file__).resolve().parents[1]
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))

import json
import math
import pandas as pd

from app.data.binance_futures import get_klines
from app.features.indicators import klines_to_df, add_basic_features
from app.strategy.scalper import generate_signals
from app.backtest.simple_backtester import backtest
from project_paths import SCAN_RESULTS, REPORTS_DIR

SCAN_PATH = SCAN_RESULTS
OUT_DIR = REPORTS_DIR
OUT_DIR.mkdir(parents=True, exist_ok=True)

MIN_ELAPSED_DAYS = 7.0
MAX_ABS_CAGR = 10.0


def _ts_seconds(value) -> float | None:
    try:
        # pandas Timestamp
        if hasattr(value, "timestamp"):
            return float(value.timestamp())
        v = float(value)
        return v / 1000.0 if v > 1e12 else v
    except Exception:
        return None


def compute_elapsed_days(equity_curve: list[dict]) -> float:
    if len(equity_curve) < 2:
        return 0.0
    a = _ts_seconds(equity_curve[0].get("ts"))
    b = _ts_seconds(equity_curve[-1].get("ts"))
    if a is None or b is None:
        return 0.0
    return max(0.0, (b - a) / 86400.0)


def compute_metrics(symbol: str, res: dict) -> dict:
    eq = res.get("equity_curve", [])
    if not eq:
        return {"symbol": symbol, "final_equity": res.get("final_equity"), "trades": len(res.get("trades", [])), "sharpe": None, "max_drawdown": None, "cagr": None, "elapsed_days": 0.0}
    edf = pd.DataFrame(eq)
    edf["equity"] = pd.to_numeric(edf["equity"], errors="coerce")
    edf = edf.dropna(subset=["equity"]).reset_index(drop=True)
    edf["ret"] = edf["equity"].pct_change().fillna(0)
    elapsed_days = compute_elapsed_days(eq)
    years = elapsed_days / 365.0 if elapsed_days > 0 else len(edf) / 525600.0
    periods_per_year = len(edf) / years if years > 0 else 0
    std_ret = edf["ret"].std(ddof=0)
    sharpe = 0.0 if not std_ret or periods_per_year <= 0 else (edf["ret"].mean() / std_ret) * math.sqrt(periods_per_year)
    peak = -math.inf
    max_dd = 0.0
    for v in edf["equity"].tolist():
        peak = max(peak, v)
        if peak > 0:
            max_dd = max(max_dd, (peak - v) / peak)
    start = float(edf["equity"].iloc[0])
    end = float(edf["equity"].iloc[-1])
    cagr = None
    cagr_note = None
    if elapsed_days < MIN_ELAPSED_DAYS:
        cagr_note = f"elapsed_too_short ({elapsed_days:.2f} days)"
    elif start > 0 and years > 0:
        raw = (end / start) ** (1 / years) - 1
        if math.isfinite(raw):
            cagr = max(-MAX_ABS_CAGR, min(MAX_ABS_CAGR, raw))
            if cagr != raw:
                cagr_note = "capped"
    return {
        "symbol": symbol,
        "final_equity": float(end),
        "trades": int(len(res.get("trades", []))),
        "sharpe": float(sharpe),
        "max_drawdown": float(max_dd),
        "cagr": cagr,
        "cagr_note": cagr_note,
        "elapsed_days": float(elapsed_days),
        "accounting_model": (res.get("metrics") or {}).get("accounting_model"),
    }


def main() -> int:
    with open(SCAN_PATH, "r", encoding="utf-8") as f:
        matches = json.load(f)
    summary = []
    for m in matches[:50]:
        symbol = m["symbol"]
        try:
            kl = get_klines(symbol, interval="1m", limit=800)
            df = klines_to_df(kl)
            df = add_basic_features(df)
            df = generate_signals(df, vol_z_threshold=2.0, profit_target=0.02, stop_loss=0.01, side="BOTH")
            res = backtest(df, initial_capital=1000.0, position_size_pct=0.1, profit_target=0.02, stop_loss=0.01)
            summary.append(compute_metrics(symbol, res))
        except Exception as e:  # noqa: BLE001
            summary.append({"symbol": symbol, "error": str(e)})
    with open(OUT_DIR / "risk_metrics_summary_inmemory.json", "w", encoding="utf-8") as of:
        json.dump(summary, of, ensure_ascii=False, indent=2)
    pd.DataFrame(summary).to_csv(OUT_DIR / "risk_metrics_summary_inmemory.csv", index=False)
    print("WROTE inmemory risk metrics to", OUT_DIR)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
