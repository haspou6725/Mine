import json
import os
from pathlib import Path

try:
    import pandas as pd
    import matplotlib.pyplot as plt
except Exception:
    pd = None
    plt = None

BASE = Path(__file__).resolve().parents[2] / "files"

INPUT_FILES = [
    BASE / "backtest_bestparams_top50.json",
    BASE / "backtest_batch.json",
    BASE / "backtest_metrics_quick.json",
]

OUT_DIR = BASE / "reports"
OUT_DIR.mkdir(parents=True, exist_ok=True)


def load_json(p: Path):
    if not p.exists():
        return None
    with p.open("r", encoding="utf-8") as f:
        return json.load(f)


def combine_results():
    results = {}
    for p in INPUT_FILES:
        data = load_json(p)
        if not data:
            continue
        if isinstance(data, list):
            for item in data:
                sym = item.get("symbol")
                if not sym:
                    continue
                if sym not in results:
                    results[sym] = {}
                # merge simple fields
                for k, v in item.items():
                    if k == "symbol":
                        continue
                    results[sym][k] = v
        elif isinstance(data, dict):
            # single entry or mapping
            if "symbol" in data and "result" in data:
                sym = data["symbol"]
                results[sym] = data["result"]
            else:
                # unknown dict shape, skip
                pass
    return results


def compute_metrics(results):
    rows = []
    for sym, info in results.items():
        final_equity = info.get("final_equity")
        trades = info.get("trades")
        # if trades is a list of trades, handle
        if isinstance(trades, list):
            trade_list = trades
            trades_count = len(trade_list)
        else:
            trade_list = None
            trades_count = trades if trades is not None else 0

        ret = None
        avg_ret_per_trade = None
        if final_equity is not None:
            try:
                ret = (float(final_equity) - 1000.0) / 1000.0
                if trades_count and trade_list is None:
                    # approximate per-trade average
                    avg_ret_per_trade = (float(final_equity) - 1000.0) / trades_count
            except Exception:
                ret = None

        row = {
            "symbol": sym,
            "final_equity": final_equity,
            "trades_count": trades_count,
            "return_pct": ret,
            "avg_return_per_trade_est": avg_ret_per_trade,
            "has_trade_list": bool(trade_list),
        }
        rows.append(row)
    return rows


def save_outputs(rows):
    # sort by final_equity desc
    rows_sorted = sorted(rows, key=lambda r: (r["final_equity"] or 0), reverse=True)
    out_json = OUT_DIR / "report_summary.json"
    out_csv = OUT_DIR / "report_summary.csv"
    with out_json.open("w", encoding="utf-8") as f:
        json.dump(rows_sorted, f, indent=2, ensure_ascii=False)

    if pd is not None:
        df = pd.DataFrame(rows_sorted)
        df.to_csv(out_csv, index=False)
        # produce simple bar chart for top 10
        try:
            top10 = df.head(10)
            plt.figure(figsize=(10,6))
            plt.bar(top10['symbol'], top10['final_equity'].astype(float))
            plt.xticks(rotation=45, ha='right')
            plt.title('Top 10 final_equity')
            plt.tight_layout()
            png_path = OUT_DIR / 'top10_final_equity.png'
            plt.savefig(png_path)
            print(f"Saved chart: {png_path}")
        except Exception as e:
            print("Could not generate chart:", e)
    else:
        # dump CSV manually
        with out_csv.open("w", encoding="utf-8") as f:
            headers = ["symbol","final_equity","trades_count","return_pct","avg_return_per_trade_est","has_trade_list"]
            f.write(",".join(headers) + "\n")
            for r in rows_sorted:
                f.write(",".join([str(r.get(h, "")) for h in headers]) + "\n")

    print(f"Wrote summary JSON: {out_json}")
    print(f"Wrote summary CSV: {out_csv}")


if __name__ == '__main__':
    results = combine_results()
    rows = compute_metrics(results)
    save_outputs(rows)
    print('Report generation completed. Note: detailed trade-level metrics require per-trade lists or equity time series which are not present in these files.')
