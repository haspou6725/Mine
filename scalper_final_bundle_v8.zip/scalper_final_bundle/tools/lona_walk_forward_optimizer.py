"""Walk-forward/grid-search optimizer for exported LONA signal datasets.

This optimizer expects `tools/export_lona_dataset.py` output. To compute real
performance, enrich the CSV with `result_r` or `result_after_1h` first. Without
labels, it still writes a diagnostic report but will not claim a profitable best
parameter set.
"""
from __future__ import annotations

import argparse
import csv
import itertools
import json
from pathlib import Path
from statistics import mean
from typing import Any

BASE = Path(__file__).resolve().parents[1]
DEFAULT_DATASET = BASE / "reports" / "lona" / "signals_dataset.csv"
DEFAULT_CONFIG = BASE / "data" / "lona_tuning_config.json"
DEFAULT_OUT = BASE / "reports" / "lona" / "walk_forward_results.json"

PARAM_KEYS = [
    "score_threshold", "trap_threshold", "min_volume_spike_for_trigger", "max_spread_pct",
    "min_depth_1pct_usd", "max_long_chase_1h_pct", "max_long_rsi_5m", "cooldown_minutes",
]


def _float(row: dict[str, str], key: str, default: float = 0.0) -> float:
    try:
        value = row.get(key, "")
        return default if value in (None, "") else float(value)
    except ValueError:
        return default


def _bool_pass(row: dict[str, str], params: dict[str, Any]) -> bool:
    score = _float(row, "score")
    trap = _float(row, "trap_score", 0)
    vspike = max(_float(row, "volume_spike", 1), _float(row, "quote_volume_spike", 1))
    spread = _float(row, "spread_pct", 999)
    depth = _float(row, "depth_1pct_usd", 0)
    change_1h = _float(row, "change_1h", 0)
    rsi5 = _float(row, "rsi_5m", 50)
    return (
        score >= float(params["score_threshold"])
        and (trap == 0 or trap < float(params["trap_threshold"]))
        and vspike >= float(params["min_volume_spike_for_trigger"])
        and spread <= float(params["max_spread_pct"])
        and depth >= float(params["min_depth_1pct_usd"])
        and change_1h <= float(params["max_long_chase_1h_pct"])
        and rsi5 <= float(params["max_long_rsi_5m"])
    )


def _evaluate(rows: list[dict[str, str]], params: dict[str, Any]) -> dict[str, Any]:
    selected = [r for r in rows if _bool_pass(r, params)]
    r_values = [_float(r, "result_r") for r in selected if r.get("result_r") not in (None, "")]
    if not r_values:
        return {
            "params": params,
            "selected": len(selected),
            "label_ready": False,
            "score": None,
            "note": "No result_r labels were available, so this is a selection/frequency diagnostic only.",
        }
    wins = [x for x in r_values if x > 0]
    losses = [abs(x) for x in r_values if x < 0]
    gross_win = sum(wins)
    gross_loss = sum(losses)
    profit_factor = gross_win / gross_loss if gross_loss else None
    return {
        "params": params,
        "selected": len(selected),
        "label_ready": True,
        "trades": len(r_values),
        "win_rate": len(wins) / len(r_values) if r_values else 0,
        "average_r": mean(r_values),
        "profit_factor": profit_factor,
        "score": (profit_factor or 0) * 10 + mean(r_values) - max(0, 8 - len(r_values)),
    }


def run_optimizer(dataset: Path = DEFAULT_DATASET, config_path: Path = DEFAULT_CONFIG, out_path: Path = DEFAULT_OUT) -> Path:
    config = json.loads(config_path.read_text(encoding="utf-8"))
    with dataset.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    grid_values = [config[k] for k in PARAM_KEYS]
    results = []
    for combo in itertools.product(*grid_values):
        params = dict(zip(PARAM_KEYS, combo))
        results.append(_evaluate(rows, params))

    labelled = [r for r in results if r.get("label_ready") and r.get("score") is not None]
    if labelled:
        results.sort(key=lambda r: r.get("score", -10**9), reverse=True)
    else:
        results.sort(key=lambda r: r.get("selected", 0), reverse=True)

    report = {
        "dataset": str(dataset),
        "rows": len(rows),
        "has_forward_labels": bool(labelled),
        "best": results[0] if results else None,
        "top_25": results[:25],
        "warning": None if labelled else "No forward-result labels were found. Do not treat top selection-frequency configs as profitability-optimized.",
    }
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return out_path


def main() -> None:
    parser = argparse.ArgumentParser(description="Run LONA-style walk-forward grid search on exported signal dataset.")
    parser.add_argument("--dataset", default=str(DEFAULT_DATASET))
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--out", default=str(DEFAULT_OUT))
    args = parser.parse_args()
    out = run_optimizer(Path(args.dataset), Path(args.config), Path(args.out))
    print(f"WROTE {out}")


if __name__ == "__main__":
    main()
