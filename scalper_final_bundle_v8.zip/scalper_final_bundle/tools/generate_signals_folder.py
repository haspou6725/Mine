"""Build audited signal files from scan + backtest metrics.

This script used to convert every scanned symbol into a LONG signal. That was
unsafe. The new behavior is deliberately conservative:

- only writes trade signals to signals/scan_results_master.json when all gates
  pass;
- writes watchlist/rejected rows separately for review;
- refuses short backtest windows unless --allow-short-window is explicitly used;
- never invents a LONG side by default.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

BASE = Path(__file__).resolve().parents[1]
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))

from project_paths import REPORTS_DIR, SCAN_RESULTS, SIGNALS_DIR

try:
    from merged_imports.scalper_meme_plus_backend.config import load_settings
except Exception:  # pragma: no cover - fallback for stripped packages
    load_settings = None


INITIAL_EQUITY = 1000.0
MIN_ELAPSED_DAYS = 7.0
MIN_CLOSED_TRADES = 5
MAX_DRAWDOWN = 0.18


def grade(score: float) -> str:
    if score >= 90:
        return "A+"
    if score >= 82:
        return "A"
    if score >= 72:
        return "B"
    if score >= 62:
        return "C"
    return "D"


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None:
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def _load_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default


def score_backtest_metric(m: dict[str, Any]) -> float:
    final_equity = _safe_float(m.get("final_equity"), INITIAL_EQUITY)
    return_pct = ((final_equity / INITIAL_EQUITY) - 1.0) * 100.0
    sharpe = max(0.0, min(_safe_float(m.get("sharpe")), 5.0))
    max_dd = max(0.0, _safe_float(m.get("max_drawdown"))) * 100.0
    trades = _safe_float(m.get("trades"))

    score = 50.0
    score += min(18.0, max(-20.0, return_pct) * 0.9)
    score += sharpe * 4.0
    score += min(10.0, trades * 0.8)
    score -= min(25.0, max_dd * 0.8)
    return max(0.0, min(100.0, score))


def side_from_scan(info: dict[str, Any]) -> str | None:
    raw = info.get("raw", {}) or {}
    change = _safe_float(raw.get("priceChangePercent", info.get("price_change_24h", 0)))
    if change <= -2.0:
        return "SHORT"
    if change >= 2.0:
        return "LONG"
    return None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--allow-short-window", action="store_true", help="allow elapsed_days < 7 for research only")
    parser.add_argument("--threshold", type=float, default=None)
    args = parser.parse_args()

    settings = load_settings() if load_settings else None
    threshold = float(args.threshold if args.threshold is not None else getattr(settings, "score_threshold", 78.0))

    out_dir = SIGNALS_DIR
    out_dir.mkdir(parents=True, exist_ok=True)
    for old in out_dir.glob("*.json"):
        old.unlink()

    metrics_path = REPORTS_DIR / "risk_metrics_summary_inmemory.json"
    metrics = {r.get("symbol"): r for r in _load_json(metrics_path, []) if isinstance(r, dict) and r.get("symbol")}
    scan_rows = _load_json(SCAN_RESULTS, [])
    scan = {r.get("symbol"): r for r in scan_rows if isinstance(r, dict) and r.get("symbol")}

    signals: list[dict[str, Any]] = []
    watchlist: list[dict[str, Any]] = []
    rejected: list[dict[str, Any]] = []

    for symbol, info in scan.items():
        m = metrics.get(symbol, {})
        score = round(score_backtest_metric(m), 2)
        side = side_from_scan(info)
        elapsed_days = _safe_float(m.get("elapsed_days"))
        closed_trades = int(_safe_float(m.get("trades")))
        max_dd = _safe_float(m.get("max_drawdown"))
        reasons: list[str] = []

        if not side:
            reasons.append("no directional 24h bias")
        if score < threshold:
            reasons.append(f"score {score} below threshold {threshold}")
        if elapsed_days < MIN_ELAPSED_DAYS and not args.allow_short_window:
            reasons.append(f"backtest window too short: {elapsed_days:.2f}d < {MIN_ELAPSED_DAYS}d")
        if closed_trades < MIN_CLOSED_TRADES:
            reasons.append(f"not enough closed trades: {closed_trades} < {MIN_CLOSED_TRADES}")
        if max_dd > MAX_DRAWDOWN:
            reasons.append(f"max drawdown too high: {max_dd:.2%}")

        base = {
            "ts": (info.get("raw", {}) or {}).get("closeTime"),
            "exchange": "binance-futures",
            "symbol": symbol,
            "side": side,
            "score": score,
            "grade": grade(score),
            "price": info.get("lastPrice"),
            "quote_volume_24h": info.get("quoteVolume"),
            "price_change_24h": _safe_float((info.get("raw", {}) or {}).get("priceChangePercent")),
            "metrics": m,
        }
        if reasons:
            row = {**base, "status": "REJECTED", "reject_reasons": reasons}
            rejected.append(row)
            if score >= 62:
                watchlist.append({**row, "status": "WATCHLIST"})
            continue

        entry = {**base, "status": "SIGNAL", "reasons": ["audited_backtest_gate", "direction_from_live_scan"]}
        signals.append(entry)
        (out_dir / f"{symbol}.json").write_text(json.dumps(entry, ensure_ascii=False, indent=2), encoding="utf-8")

    signals.sort(key=lambda x: x.get("score", 0), reverse=True)
    watchlist.sort(key=lambda x: x.get("score", 0), reverse=True)
    rejected.sort(key=lambda x: x.get("score", 0), reverse=True)

    (out_dir / "scan_results_master.json").write_text(json.dumps(signals, ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "watchlist_candidates.json").write_text(json.dumps(watchlist[:250], ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "rejected_candidates.json").write_text(json.dumps(rejected[:500], ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "README.md").write_text(
        "# Signals folder\n\n"
        "`scan_results_master.json` now contains only audited trade signals. "
        "Rejected/watchlist rows are separated so scanned symbols are not displayed as live signals.\n",
        encoding="utf-8",
    )
    print(f"WROTE {len(signals)} audited signals, {len(watchlist)} watchlist rows, {len(rejected)} rejected rows to {out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
