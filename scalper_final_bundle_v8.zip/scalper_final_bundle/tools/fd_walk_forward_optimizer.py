from __future__ import annotations
import argparse, itertools, json
from pathlib import Path
import pandas as pd


def evaluate(df: pd.DataFrame, params: dict) -> dict:
    mask = (
        (df["volume_ratio"] >= params["min_volume_spike_for_trigger"]) &
        (df["rsi_14"] <= params["max_long_rsi_5m"]) &
        (df["change_1h_proxy"] <= params["max_long_chase_1h_pct"])
    )
    if "overbought_low_volume" in df.columns:
        mask &= ~df["overbought_low_volume"].astype(bool)
    trades = df[mask].dropna(subset=["future_return"])
    if trades.empty:
        return {"trades": 0, "score": -999, "return_pct": 0, "win_rate": None, "avg_return_pct": None}
    returns = trades["future_return"]
    win_rate = float((returns > 0).mean())
    total = float(returns.sum())
    downside = abs(float(returns[returns < 0].sum()))
    profit_factor = float(returns[returns > 0].sum()) / downside if downside > 0 else 9.99
    # Penalize tiny sample sizes and overfitting.
    score = total * 100 + win_rate * 10 + min(profit_factor, 5) - max(0, 20 - len(trades)) * 0.25
    return {"trades": int(len(trades)), "score": score, "return_pct": total * 100, "win_rate": win_rate * 100, "profit_factor": profit_factor, "avg_return_pct": float(returns.mean() * 100)}


def walk_forward(df: pd.DataFrame, train_ratio: float = 0.7) -> list[dict]:
    n = len(df)
    split = max(10, min(n - 5, int(n * train_ratio)))
    train = df.iloc[:split].copy()
    test = df.iloc[split:].copy()
    grid = {
        "min_volume_spike_for_trigger": [1.25, 1.35, 1.45, 1.60, 1.80],
        "max_long_rsi_5m": [70, 72, 74, 76, 78],
        "max_long_chase_1h_pct": [4.5, 5.5, 7.0, 9.0],
    }
    keys = list(grid)
    rows = []
    for values in itertools.product(*(grid[k] for k in keys)):
        params = dict(zip(keys, values))
        train_eval = evaluate(train, params)
        test_eval = evaluate(test, params)
        rows.append({"params": params, "train": train_eval, "test": test_eval, "combined_score": train_eval["score"] * 0.4 + test_eval["score"] * 0.6})
    return sorted(rows, key=lambda r: r["combined_score"], reverse=True)


def main() -> None:
    ap = argparse.ArgumentParser(description="Walk-forward optimizer over Financial Datasets feature CSV")
    ap.add_argument("--dataset", required=True)
    ap.add_argument("--out", default="reports/financial_datasets_walk_forward_results.json")
    ap.add_argument("--best-out", default="data/best_params_financial_datasets.json")
    args = ap.parse_args()
    df = pd.read_csv(args.dataset)
    results = walk_forward(df)
    out = Path(args.out); out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(results[:50], ensure_ascii=False, indent=2), encoding="utf-8")
    best = results[0] if results else {"params": {}}
    best_out = Path(args.best_out); best_out.parent.mkdir(parents=True, exist_ok=True)
    best_out.write_text(json.dumps(best.get("params", {}), ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"WROTE {out}")
    print(f"WROTE {best_out}")

if __name__ == "__main__":
    main()
