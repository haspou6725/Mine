"""Export scanner signals/snapshots to a LONA-friendly research CSV.

The exporter does not create synthetic trades. It simply flattens live scanner
signals, snapshots and skipped reasons into a tabular dataset suitable for LONA
or offline walk-forward analysis. Forward-result columns are intentionally left
blank unless you later enrich the CSV from historical candles.
"""
from __future__ import annotations

import argparse
import csv
import json
import sqlite3
from pathlib import Path
from typing import Any, Iterable

BASE = Path(__file__).resolve().parents[1]
DEFAULT_DB = BASE / "data" / "live_signals.db"
DEFAULT_OUT = BASE / "reports" / "lona" / "signals_dataset.csv"

COLUMNS = [
    "timestamp", "source", "symbol", "exchange", "side", "level", "score", "grade", "price",
    "quote_volume_24h", "price_change_24h", "volume_spike", "quote_volume_spike", "spread_pct", "depth_1pct_usd",
    "rsi_5m", "rsi_15m", "change_1m", "change_5m", "change_15m", "change_1h",
    "short_score", "long_score", "trap_score", "early_final_score", "early_move_score", "early_execution_score",
    "btc_bias", "btc_rsi", "btc_macd_histogram", "btc_volume_ratio", "btc_overbought_low_volume",
    "entry_low", "entry_high", "stop", "tp1", "tp2", "tp3",
    "failed_gates", "skip_reason", "label_ready", "result_after_5m", "result_after_15m", "result_after_1h", "result_r",
]


def _safe_float(value: Any, default: float | None = None) -> float | None:
    try:
        if value is None or value == "":
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def _json_loads(value: str | bytes | None) -> dict[str, Any]:
    if not value:
        return {}
    try:
        data = json.loads(value)
        return data if isinstance(data, dict) else {}
    except json.JSONDecodeError:
        return {}


def _flatten_payload(payload: dict[str, Any], source: str, skip_reason: str = "", failed_gates: str = "") -> dict[str, Any]:
    metrics = payload.get("metrics") if isinstance(payload.get("metrics"), dict) else payload
    early = metrics.get("early_warning") if isinstance(metrics.get("early_warning"), dict) else payload.get("early_warning", {})
    market = metrics.get("market_context") if isinstance(metrics.get("market_context"), dict) else {}
    plan = payload.get("plan") if isinstance(payload.get("plan"), dict) else {}
    entry = plan.get("entry_zone") if isinstance(plan.get("entry_zone"), list) else []
    side = payload.get("side") or metrics.get("early_direction") or ""
    if side == "PUMP":
        side = "LONG"
    elif side == "DUMP":
        side = "SHORT"
    row = {
        "timestamp": payload.get("ts") or metrics.get("ts") or "",
        "source": source,
        "symbol": payload.get("symbol") or metrics.get("symbol") or "",
        "exchange": payload.get("exchange") or metrics.get("exchange") or "",
        "side": side,
        "level": early.get("level") or ("SIGNAL" if source == "signals" else source.upper()),
        "score": _safe_float(payload.get("score") or metrics.get("score") or max(_safe_float(metrics.get("long_score"), 0) or 0, _safe_float(metrics.get("short_score"), 0) or 0)),
        "grade": payload.get("grade") or "",
        "price": _safe_float(payload.get("price") or metrics.get("price")),
        "quote_volume_24h": _safe_float(payload.get("quote_volume_24h") or metrics.get("quote_volume_24h")),
        "price_change_24h": _safe_float(payload.get("price_change_24h") or metrics.get("price_change_24h")),
        "volume_spike": _safe_float(payload.get("volume_spike") or metrics.get("volume_spike")),
        "quote_volume_spike": _safe_float(metrics.get("quote_volume_spike")),
        "spread_pct": _safe_float(payload.get("spread_pct") or metrics.get("spread_pct")),
        "depth_1pct_usd": _safe_float(metrics.get("depth_1pct_usd")),
        "rsi_5m": _safe_float(metrics.get("rsi_5m")),
        "rsi_15m": _safe_float(metrics.get("rsi_15m")),
        "change_1m": _safe_float(metrics.get("change_1m")),
        "change_5m": _safe_float(metrics.get("change_5m")),
        "change_15m": _safe_float(metrics.get("change_15m")),
        "change_1h": _safe_float(metrics.get("change_1h")),
        "short_score": _safe_float(metrics.get("short_score")),
        "long_score": _safe_float(metrics.get("long_score")),
        "trap_score": _safe_float(early.get("trap_score")),
        "early_final_score": _safe_float(early.get("final_score")),
        "early_move_score": _safe_float(early.get("move_score")),
        "early_execution_score": _safe_float(early.get("execution_score")),
        "btc_bias": market.get("bias", ""),
        "btc_rsi": _safe_float(market.get("btc_rsi")),
        "btc_macd_histogram": _safe_float(market.get("btc_macd_histogram")),
        "btc_volume_ratio": _safe_float(market.get("btc_volume_ratio")),
        "btc_overbought_low_volume": bool(market.get("btc_overbought_low_volume", False)),
        "entry_low": _safe_float(entry[0]) if len(entry) > 0 else None,
        "entry_high": _safe_float(entry[1]) if len(entry) > 1 else None,
        "stop": _safe_float(plan.get("stop")),
        "tp1": _safe_float(plan.get("tp1")),
        "tp2": _safe_float(plan.get("tp2")),
        "tp3": _safe_float(plan.get("tp3")),
        "failed_gates": failed_gates,
        "skip_reason": skip_reason,
        "label_ready": False,
        "result_after_5m": "",
        "result_after_15m": "",
        "result_after_1h": "",
        "result_r": "",
    }
    return row


def _read_db_rows(db_path: Path) -> list[dict[str, Any]]:
    if not db_path.exists():
        return []
    rows: list[dict[str, Any]] = []
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row
    try:
        for r in con.execute("SELECT payload_json FROM signals ORDER BY id ASC"):
            payload = _json_loads(r["payload_json"])
            rows.append(_flatten_payload(payload, "signals"))
        for r in con.execute("SELECT payload_json FROM snapshots ORDER BY ts ASC"):
            payload = _json_loads(r["payload_json"])
            rows.append(_flatten_payload(payload, "snapshots"))
        for r in con.execute("SELECT ts, symbol, reason, details_json FROM skipped ORDER BY id ASC"):
            details = _json_loads(r["details_json"])
            payload = {"ts": r["ts"], "symbol": r["symbol"], "metrics": details}
            failed = ",".join(details.get("failed_gates", [])) if isinstance(details.get("failed_gates"), list) else ""
            rows.append(_flatten_payload(payload, "skipped", str(r["reason"]), failed))
    finally:
        con.close()
    return rows


def _read_json_array(path: Path, source: str) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return []
    if isinstance(data, dict):
        data = data.get("rows") or data.get("items") or []
    if not isinstance(data, list):
        return []
    return [_flatten_payload(item, source) for item in data if isinstance(item, dict)]


def export_dataset(db_path: Path = DEFAULT_DB, out_path: Path = DEFAULT_OUT) -> Path:
    rows = _read_db_rows(db_path)
    rows.extend(_read_json_array(BASE / "signals" / "scan_results_master.json", "signals_json"))
    rows.extend(_read_json_array(BASE / "signals" / "watchlist_candidates.json", "watchlist_json"))
    rows.extend(_read_json_array(BASE / "signals" / "rejected_candidates.json", "rejected_json"))

    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=COLUMNS)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k, "") for k in COLUMNS})

    meta = {
        "output": str(out_path),
        "rows": len(rows),
        "label_ready": False,
        "note": "Forward result columns are blank until enriched from historical OHLCV candles. No synthetic performance labels were created.",
    }
    (out_path.with_suffix(".meta.json")).write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    return out_path


def main() -> None:
    parser = argparse.ArgumentParser(description="Export scanner research dataset for LONA/offline optimization.")
    parser.add_argument("--db", default=str(DEFAULT_DB))
    parser.add_argument("--out", default=str(DEFAULT_OUT))
    args = parser.parse_args()
    out = export_dataset(Path(args.db), Path(args.out))
    print(f"WROTE {out}")


if __name__ == "__main__":
    main()
