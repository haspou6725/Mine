"""Read-only Binance Futures microstructure snapshot exporter.

Creates a CSV with spread, depth proxy, funding, mark/index premium, OI delta and taker flow.
No API key and no order execution are used.
"""
from __future__ import annotations

import argparse
import asyncio
import csv
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parents[1]
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))

from merged_imports.scalper_meme_plus_backend.clients.binance import BinanceFuturesClient
from merged_imports.scalper_meme_plus_backend.config import load_settings
from merged_imports.scalper_meme_plus_backend.engine.binance_microstructure import derive_microstructure
from merged_imports.scalper_meme_plus_backend.engine.indicators import orderbook_metrics, pct_change, safe_float
from merged_imports.scalper_meme_plus_backend.timeutil import utc_now


async def collect(symbols: list[str]) -> list[dict]:
    settings = load_settings()
    client = BinanceFuturesClient()
    out: list[dict] = []
    try:
        tickers, premiums = await asyncio.gather(client.ticker_24h(), client.premium_index())
        ticker_map = {x.get('symbol'): x for x in tickers if x.get('symbol')}
        premium_map = {x.get('symbol'): x for x in premiums if x.get('symbol')}
        for symbol in symbols:
            symbol = symbol.upper().replace('/', '').replace('-', '')
            t = ticker_map.get(symbol)
            if not t:
                out.append({'symbol': symbol, 'ok': False, 'error': 'symbol_not_found'})
                continue
            depth, oi_hist, taker = await asyncio.gather(
                client.depth(symbol, settings.depth_limit),
                client.open_interest_hist(symbol, '5m', 12),
                client.taker_buy_sell_volume(symbol, '5m', 12),
                return_exceptions=True,
            )
            p = premium_map.get(symbol) or {}
            metrics = {
                'exchange': 'binance-futures',
                'symbol': symbol,
                'price': safe_float(t.get('lastPrice')),
                'quote_volume_24h': safe_float(t.get('quoteVolume')),
                'price_change_24h': safe_float(t.get('priceChangePercent')),
                'high_24h': safe_float(t.get('highPrice')),
                'low_24h': safe_float(t.get('lowPrice')),
                'funding_rate': safe_float(p.get('lastFundingRate')) if p else None,
                'mark_price': safe_float(p.get('markPrice')) if p else None,
                'index_price': safe_float(p.get('indexPrice')) if p else None,
                'min_quote_volume_gate': settings.min_quote_volume,
                'max_spread_pct_gate': settings.max_spread_pct,
                'min_depth_1pct_usd_gate': settings.min_depth_1pct_usd,
            }
            if not isinstance(depth, Exception):
                metrics.update(orderbook_metrics(depth))
            if not isinstance(oi_hist, Exception) and len(oi_hist) >= 2:
                first = safe_float(oi_hist[0].get('sumOpenInterestValue')) or safe_float(oi_hist[0].get('sumOpenInterest'))
                last = safe_float(oi_hist[-1].get('sumOpenInterestValue')) or safe_float(oi_hist[-1].get('sumOpenInterest'))
                metrics['oi_change_pct'] = pct_change(last, first)
            if not isinstance(taker, Exception) and taker:
                buy = sum(safe_float(x.get('buyVol')) for x in taker)
                sell = sum(safe_float(x.get('sellVol')) for x in taker)
                if buy + sell > 0:
                    metrics['taker_sell_pressure'] = sell / (buy + sell)
            micro = derive_microstructure(metrics, settings)
            out.append({'ok': True, 'fetched_at': utc_now(), **metrics, **{f'micro_{k}': json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v for k, v in micro.items()}})
    finally:
        await client.close()
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--symbols', nargs='*', default=['BTCUSDT', 'ETHUSDT', 'DOGEUSDT'])
    parser.add_argument('--out', default=str(BASE / 'reports' / 'binance_microstructure_snapshot.csv'))
    args = parser.parse_args()
    rows = asyncio.run(collect(args.symbols))
    path = Path(args.out)
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({k for row in rows for k in row.keys()})
    with path.open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    print('WROTE', path)


if __name__ == '__main__':
    main()
