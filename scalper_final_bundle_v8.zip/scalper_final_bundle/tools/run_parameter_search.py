"""
Parameter grid search tuner.
Runs backtest across top symbols and a grid of parameters, saves results to JSON and prints best configs.
"""
from __future__ import annotations
from pathlib import Path
import sys
BASE = Path(__file__).resolve().parents[1] if Path(__file__).resolve().parent.name == "tools" else Path(__file__).resolve().parent
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))

import json
import itertools
from statistics import mean
from app.data.binance_futures import get_klines
from app.features.indicators import klines_to_df, add_basic_features
from app.strategy.scalper import generate_signals
from app.backtest.simple_backtester import backtest

from project_paths import SCAN_RESULTS, TUNING_RESULTS

SCAN_PATH = str(SCAN_RESULTS)
OUT_PATH = str(TUNING_RESULTS)

with open(SCAN_PATH, 'r', encoding='utf-8') as f:
    matches = json.load(f)

symbols = [m['symbol'] for m in matches[:12]]  # limit for speed

param_grid = {
    'vol_z_threshold': [1.0, 1.5, 2.0],
    'profit_target': [0.01, 0.02],
    'stop_loss': [0.01, 0.02],
    'position_size_pct': [0.05, 0.1]
}

keys, values = zip(*param_grid.items())
combos = [dict(zip(keys, v)) for v in itertools.product(*values)]

results = []
for combo in combos:
    combo_summary = {'params': combo, 'per_symbol': []}
    for sym in symbols:
        try:
            kl = get_klines(sym, interval='1m', limit=500)
            df = klines_to_df(kl)
            df = add_basic_features(df)
            df = generate_signals(df, vol_z_threshold=combo['vol_z_threshold'], profit_target=combo['profit_target'], stop_loss=combo['stop_loss'])
            res = backtest(df, initial_capital=1000.0, leverage=1.0, commission=0.0004, slippage=0.0005, position_size_pct=combo['position_size_pct'], profit_target=combo['profit_target'], stop_loss=combo['stop_loss'])
            combo_summary['per_symbol'].append({'symbol': sym, 'final_equity': res['final_equity'], 'trades': len(res['trades'])})
        except Exception as e:
            combo_summary['per_symbol'].append({'symbol': sym, 'error': str(e)})
    equities = [p['final_equity'] for p in combo_summary['per_symbol'] if 'final_equity' in p]
    combo_summary['mean_final_equity'] = mean(equities) if equities else None
    combo_summary['total_trades'] = sum([p.get('trades',0) for p in combo_summary['per_symbol'] if 'trades' in p])
    results.append(combo_summary)

results_sorted = sorted(results, key=lambda x: (x['mean_final_equity'] is not None, x['mean_final_equity']), reverse=True)
with open(OUT_PATH, 'w', encoding='utf-8') as f:
    json.dump(results_sorted, f, ensure_ascii=False, indent=2)

print('WROTE tuning results to', OUT_PATH)
print('Top 3 configs:')
for r in results_sorted[:3]:
    print(r['params'], 'mean_eq=', r['mean_final_equity'], 'trades=', r['total_trades'])
