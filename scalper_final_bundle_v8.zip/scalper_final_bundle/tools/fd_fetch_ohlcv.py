from __future__ import annotations
import argparse
from pathlib import Path
import sys
BASE = Path(__file__).resolve().parents[1]
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))
from app.data.financial_datasets_client import FinancialDatasetsClient, to_fd_ticker, write_ohlcv_csv


def main() -> None:
    ap = argparse.ArgumentParser(description="Fetch Financial Datasets crypto OHLCV and write normalized CSV")
    ap.add_argument("--symbol", default="BTCUSDT", help="Binance-style symbol or FD ticker, e.g. BTCUSDT or BTC-USD")
    ap.add_argument("--interval", default="day", choices=["minute", "day", "week", "month", "year"])
    ap.add_argument("--start", required=True)
    ap.add_argument("--end", required=True)
    ap.add_argument("--limit", type=int, default=5000)
    ap.add_argument("--out", default=None)
    ap.add_argument("--force-refresh", action="store_true")
    args = ap.parse_args()
    ticker = to_fd_ticker(args.symbol)
    rows = FinancialDatasetsClient().get_crypto_prices(ticker=ticker, interval=args.interval, start_date=args.start, end_date=args.end, limit=args.limit, force_refresh=args.force_refresh)
    out = args.out or str(BASE / "data" / "financial_datasets" / f"{ticker}_{args.interval}_{args.start}_{args.end}.csv")
    path = write_ohlcv_csv(rows, out)
    print(f"WROTE {path} rows={len(rows)} ticker={ticker}")

if __name__ == "__main__":
    main()
