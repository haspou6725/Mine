from __future__ import annotations
import argparse
from pathlib import Path
import sys
import pandas as pd
BASE = Path(__file__).resolve().parents[1]
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))
from app.features.market_regime import add_market_regime_features


def build_dataset(ohlcv_csv: Path, out_csv: Path, symbol: str = "UNKNOWN", horizon_bars: int = 15) -> pd.DataFrame:
    df = pd.read_csv(ohlcv_csv)
    if "timestamp" not in df.columns:
        raise ValueError("OHLCV CSV must contain timestamp column")
    df = add_market_regime_features(df)
    df["symbol"] = symbol
    df["future_return"] = df["close"].shift(-horizon_bars) / df["close"] - 1.0
    df["label_win"] = (df["future_return"] > 0.006).astype(int)
    df["label_trap"] = (df["future_return"] < -0.006).astype(int)
    df["volume_spike"] = df["volume_ratio"]
    df["change_1h_proxy"] = df["close"].pct_change(60).fillna(0) * 100
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_csv, index=False)
    return df


def main() -> None:
    ap = argparse.ArgumentParser(description="Build ML/backtest feature dataset from Financial Datasets OHLCV CSV")
    ap.add_argument("--ohlcv", required=True)
    ap.add_argument("--symbol", default="UNKNOWN")
    ap.add_argument("--horizon-bars", type=int, default=15)
    ap.add_argument("--out", default=str(BASE / "data" / "financial_datasets" / "feature_dataset.csv"))
    args = ap.parse_args()
    df = build_dataset(Path(args.ohlcv), Path(args.out), args.symbol, args.horizon_bars)
    print(f"WROTE {args.out} rows={len(df)}")

if __name__ == "__main__":
    main()
