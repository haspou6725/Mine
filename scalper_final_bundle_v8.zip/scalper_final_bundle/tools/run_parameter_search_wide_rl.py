"""
Rate-limited, cache-aware parameter search/wide tuner.
Usage: python run_parameter_search_wide_rl.py [--symbols N] [--max_combos M] [--use_cache true|false]
This script is conservative by default: it samples combos if total combos exceed max_combos.
It caches klines per-symbol in files/.cache/klines/{symbol}.json to reduce repeated network calls.
"""
from __future__ import annotations
from pathlib import Path
import sys
BASE = Path(__file__).resolve().parents[1] if Path(__file__).resolve().parent.name == "tools" else Path(__file__).resolve().parent
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))

import json
import itertools
import random
import time
import argparse
from statistics import mean
from pathlib import Path

from app.data.binance_futures import get_klines
from app.features.indicators import klines_to_df, add_basic_features
from app.strategy.scalper import generate_signals
from app.backtest.simple_backtester import backtest

BASE = Path(__file__).resolve().parents[1]
SCAN_PATH = BASE / 'scan_results.json'
OUT_PATH = BASE / 'tuning_results_wide_rl.json'
CACHE_DIR = BASE / '.cache' / 'klines'
CACHE_DIR.mkdir(parents=True, exist_ok=True)

parser = argparse.ArgumentParser()
parser.add_argument('--symbols', type=int, default=100, help='Number of top symbols to include (from scan_results.json)')
parser.add_argument('--max_combos', type=int, default=500, help='Maximum number of parameter combos to evaluate')
parser.add_argument('--use_cache', type=bool, default=True, help='Whether to use cached klines when available')
parser.add_argument('--sleep', type=float, default=0.25, help='Seconds to sleep between network requests')
parser.add_argument('--seed', type=int, default=42, help='Random seed for sampling combos')
args = parser.parse_args()

random.seed(args.seed)

# read scan results (fallback to a small default list)
if SCAN_PATH.exists():
    try:
        with open(SCAN_PATH, 'r', encoding='utf-8') as f:
            matches = json.load(f)
    except Exception:
        matches = []
else:
    matches = []

symbols = [m['symbol'] for m in matches]
if not symbols:
    # fallback: common top coins
    symbols = ['BTCUSDT','ETHUSDT','BNBUSDT','SOLUSDT','ADAUSDT','XRPUSDT','DOGEUSDT','LTCUSDT','DOTUSDT','LINKUSDT']

symbols = symbols[:args.symbols]

param_grid = {
    'vol_z_threshold': [0.5, 1.0, 1.5, 2.0, 2.5],
    'profit_target': [0.005, 0.01, 0.02],
    'stop_loss': [0.005, 0.01, 0.02],
    'position_size_pct': [0.05, 0.1]
}

keys, values = zip(*param_grid.items())
combos = [dict(zip(keys, v)) for v in itertools.product(*values)]

# sample combos if too many
if len(combos) > args.max_combos:
    combos = random.sample(combos, args.max_combos)

results = []

def load_klines_cached(symbol: str, limit: int = 500):
    cache_file = CACHE_DIR / f'{symbol}.json'
    if args.use_cache and cache_file.exists():
        try:
            with open(cache_file, 'r', encoding='utf-8') as fh:
                return json.load(fh)
        except Exception:
            pass
    # fetch
    kl = get_klines(symbol, interval='1m', limit=limit)
    try:
        with open(cache_file, 'w', encoding='utf-8') as fh:
            json.dump(kl, fh)
    except Exception:
        pass
    return kl

# iterate combos and symbols, but outer loop combos to allow early stopping and progress
total = len(combos) * len(symbols)
count = 0
start_time = time.time()

for idx, combo in enumerate(combos, 1):
    combo_summary = {'params': combo, 'per_symbol': []}
    for sym in symbols:
        count += 1
        try:
            kl = load_klines_cached(sym, limit=500)
            df = klines_to_df(kl)
            df = add_basic_features(df)
            df = generate_signals(df, vol_z_threshold=combo['vol_z_threshold'], profit_target=combo['profit_target'], stop_loss=combo['stop_loss'])
            res = backtest(df, initial_capital=1000.0, leverage=1.0, commission=0.0004, slippage=0.0005, position_size_pct=combo['position_size_pct'], profit_target=combo['profit_target'], stop_loss=combo['stop_loss'])
            combo_summary['per_symbol'].append({'symbol': sym, 'final_equity': res['final_equity'], 'trades': len(res['trades'])})
        except Exception as e:
            combo_summary['per_symbol'].append({'symbol': sym, 'error': str(e)})
        # polite pause to reduce rate pressure
        time.sleep(args.sleep)
        if count % 50 == 0:
            elapsed = time.time() - start_time
            print(f'Processed {count}/{total} items. Elapsed: {elapsed:.1f}s')
    equities = [p['final_equity'] for p in combo_summary['per_symbol'] if 'final_equity' in p]
    combo_summary['mean_final_equity'] = mean(equities) if equities else None
    combo_summary['total_trades'] = sum([p.get('trades',0) for p in combo_summary['per_symbol'] if 'trades' in p])
    results.append(combo_summary)
    # periodically write partial results
    with open(OUT_PATH, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    if idx % 5 == 0:
        print(f'Completed {idx}/{len(combos)} combos; wrote partial results to {OUT_PATH}')

# final sort
results_sorted = sorted(results, key=lambda x: (x['mean_final_equity'] is not None, x['mean_final_equity']), reverse=True)
with open(OUT_PATH, 'w', encoding='utf-8') as f:
    json.dump(results_sorted, f, ensure_ascii=False, indent=2)

print('WROTE tuning results to', OUT_PATH)
print('Top 5 configs:')
for r in results_sorted[:5]:
    print(r['params'], 'mean_eq=', r['mean_final_equity'], 'trades=', r['total_trades'])
