from pathlib import Path
import sys
BASE = Path(__file__).resolve().parents[1] if Path(__file__).resolve().parent.name == "tools" else Path(__file__).resolve().parent
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))

import json
import os
from pathlib import Path
from app.data.binance_futures import get_klines
from app.features.indicators import klines_to_df, add_basic_features
from app.strategy.scalper import generate_signals
from app.backtest.simple_backtester import backtest

from project_paths import BACKTESTS_DIR, SCAN_RESULTS, BACKTESTS_DETAILED_SUMMARY

OUT_DIR = BACKTESTS_DIR
OUT_DIR.mkdir(parents=True, exist_ok=True)
scan_path = SCAN_RESULTS
with open(scan_path, 'r', encoding='utf-8') as f:
    matches = json.load(f)

summary = []
for m in matches[:50]:
    symbol = m['symbol']
    try:
        kl = get_klines(symbol, interval='1m', limit=800)
        df = klines_to_df(kl)
        df = add_basic_features(df)
        df = generate_signals(df, vol_z_threshold=1.5, profit_target=0.02, stop_loss=0.01)
        res = backtest(df, initial_capital=1000.0, position_size_pct=0.1, profit_target=0.02, stop_loss=0.01)
        # normalize timestamps in equity_curve and trades to integers (ms since epoch) for JSON serialization
        try:
            for e in res.get('equity_curve', []):
                ts = e.get('ts')
                if ts is None:
                    continue
                try:
                    import pandas as _pd
                    if isinstance(ts, _pd.Timestamp):
                        e['ts'] = int(ts.timestamp() * 1000)
                        continue
                except Exception:
                    pass
                try:
                    e['ts'] = int(float(ts))
                except Exception:
                    pass
            # normalize trades timestamps too
            for t in res.get('trades', []):
                ts = t.get('ts')
                if ts is None:
                    continue
                try:
                    import pandas as _pd
                    if isinstance(ts, _pd.Timestamp):
                        t['ts'] = int(ts.timestamp() * 1000)
                        continue
                except Exception:
                    pass
                try:
                    t['ts'] = int(float(ts))
                except Exception:
                    pass
        except Exception:
            pass
        outpath = OUT_DIR / f"{symbol}.json"
        with open(outpath, 'w', encoding='utf-8') as of:
            json.dump(res, of, ensure_ascii=False, indent=2)
        summary.append({'symbol': symbol, 'final_equity': res.get('final_equity'), 'trades': len(res.get('trades', [])), 'file': str(outpath)})
    except Exception as e:
        summary.append({'symbol': symbol, 'error': str(e)})

summary_path = BACKTESTS_DETAILED_SUMMARY
with open(summary_path, 'w', encoding='utf-8') as sf:
    json.dump(summary, sf, ensure_ascii=False, indent=2)
print('WROTE detailed backtests to', OUT_DIR)
