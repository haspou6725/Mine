from pathlib import Path
import sys
BASE = Path(__file__).resolve().parents[1] if Path(__file__).resolve().parent.name == "tools" else Path(__file__).resolve().parent
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))

import json
from app.data.binance_futures import get_klines
from app.features.indicators import klines_to_df, add_basic_features
from app.strategy.scalper import generate_signals
from app.backtest.simple_backtester import backtest

from project_paths import SCAN_RESULTS, BACKTEST_BESTPARAMS_TOP50

SCAN_PATH = str(SCAN_RESULTS)
OUT_PATH = str(BACKTEST_BESTPARAMS_TOP50)

with open(SCAN_PATH, 'r', encoding='utf-8') as f:
    matches = json.load(f)

symbols = [m['symbol'] for m in matches[:50]]
print('Running backtest on', len(symbols), 'symbols')
results = []
for symbol in symbols:
    try:
        kl = get_klines(symbol, interval='1m', limit=500)
        df = klines_to_df(kl)
        df = add_basic_features(df)
        df = generate_signals(df, vol_z_threshold=1.0, profit_target=0.01, stop_loss=0.01)
        res = backtest(df, initial_capital=1000.0, leverage=1.0, commission=0.0004, slippage=0.0005, position_size_pct=0.1, profit_target=0.01, stop_loss=0.01)
        results.append({'symbol':symbol,'final_equity':res['final_equity'],'trades':len(res['trades'])})
    except Exception as e:
        results.append({'symbol':symbol,'error':str(e)})

with open(OUT_PATH, 'w', encoding='utf-8') as f:
    json.dump(results, f, ensure_ascii=False, indent=2)

print('WROTE', OUT_PATH)
