from __future__ import annotations

from pathlib import Path
import sys
BASE = Path(__file__).resolve().parents[1]
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))

import json
from app.execution.executor import PortfolioSimulator
from project_paths import SIGNALS_MASTER, SCAN_RESULTS, REPORTS_DIR


def main() -> int:
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    signals = json.loads(SIGNALS_MASTER.read_text(encoding='utf-8')) if SIGNALS_MASTER.exists() else []
    scan_rows = json.loads(SCAN_RESULTS.read_text(encoding='utf-8')) if SCAN_RESULTS.exists() else []
    scan = {r['symbol']: r for r in scan_rows if isinstance(r, dict) and r.get('symbol')}

    sim = PortfolioSimulator(cash=1000.0)
    actions = []
    signals_sorted = sorted([s for s in signals if s.get('status', 'SIGNAL') == 'SIGNAL'], key=lambda s: s.get('score') or 0, reverse=True)
    for s in signals_sorted[:10]:
        sym = s['symbol']
        side = (s.get('side') or '').upper()
        price = float(s.get('price') or scan.get(sym, {}).get('lastPrice') or 0)
        if price <= 0:
            actions.append({'symbol': sym, 'status': 'skipped', 'reason': 'missing price'})
            continue
        if side != 'LONG':
            # Spot simulator cannot model true futures shorts; do not fake it.
            actions.append({'symbol': sym, 'side': side, 'status': 'skipped', 'reason': 'PortfolioSimulator supports spot LONG only'})
            continue
        notional = sim.cash * 0.1
        try:
            sim.place_market_order(sym, 'buy', notional=notional, price=price)
            actions.append({'symbol': sym, 'side': side, 'status': 'filled', 'notional': notional, 'price': price})
        except Exception as e:  # noqa: BLE001
            actions.append({'symbol': sym, 'side': side, 'status': 'failed', 'error': str(e)})

    positions = {k: {'qty': v, 'price': float(scan.get(k, {}).get('lastPrice') or 0), 'notional': v * float(scan.get(k, {}).get('lastPrice') or 0)} for k, v in sim.positions.items()}
    final = {'cash': sim.cash, 'positions': positions, 'actions': actions, 'history_len': len(sim.history)}
    (REPORTS_DIR / 'portfolio_simulation.json').write_text(json.dumps(final, ensure_ascii=False, indent=2), encoding='utf-8')
    print('WROTE portfolio_simulation.json')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
