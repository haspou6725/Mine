"""Export historical Binance Futures OHLCV plus microstructure-friendly features.

This is designed for LONA / walk-forward / Financial Datasets comparisons.
It is read-only and does not require API keys.
"""
from __future__ import annotations

import argparse
import asyncio
import csv
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parents[1]
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))

from merged_imports.scalper_meme_plus_backend.clients.binance import BinanceFuturesClient
from merged_imports.scalper_meme_plus_backend.engine.indicators import candle_change, quote_volume_spike, rsi, safe_float, volume_spike, vwap


async def export_symbol(symbol: str, interval: str, limit: int) -> list[dict]:
    client = BinanceFuturesClient()
    try:
        k = await client.klines(symbol, interval, limit)
    finally:
        await client.close()
    out = []
    closes = [safe_float(x.get('close')) for x in k]
    for i, row in enumerate(k):
        window = k[: i + 1]
        close_window = closes[: i + 1]
        out.append({
            'timestamp': row.get('open_time'),
            'symbol': symbol,
            'interval': interval,
            'open': row.get('open'),
            'high': row.get('high'),
            'low': row.get('low'),
            'close': row.get('close'),
            'volume': row.get('volume'),
            'quote_volume': row.get('quote_volume'),
            'trades': row.get('trades'),
            'rsi': rsi(close_window, 14),
            'vwap': vwap(window, min(60, len(window))),
            'volume_spike': volume_spike(window, min(50, len(window))),
            'quote_volume_spike': quote_volume_spike(window, min(50, len(window))),
            'change_15m_proxy': candle_change(window, 3),
            'change_1h_proxy': candle_change(window, 12),
        })
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--symbol', default='BTCUSDT')
    parser.add_argument('--interval', default='5m')
    parser.add_argument('--limit', type=int, default=500)
    parser.add_argument('--out', default=str(BASE / 'data' / 'binance_feature_dataset.csv'))
    args = parser.parse_args()
    rows = asyncio.run(export_symbol(args.symbol.upper(), args.interval, args.limit))
    path = Path(args.out)
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(rows[0].keys()) if rows else []
    with path.open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    print('WROTE', path, 'rows=', len(rows))


if __name__ == '__main__':
    main()
