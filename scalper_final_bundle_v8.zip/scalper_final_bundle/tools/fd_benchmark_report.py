from __future__ import annotations
import argparse, json
from pathlib import Path
import pandas as pd


def buy_hold_metrics(df: pd.DataFrame) -> dict:
    start = float(df["close"].iloc[0])
    end = float(df["close"].iloc[-1])
    ret = (end / start - 1.0) if start else 0.0
    equity = df["close"] / start if start else df["close"] * 0
    peak = equity.cummax()
    dd = ((peak - equity) / peak.replace(0, pd.NA)).fillna(0).max()
    return {"return_pct": ret * 100, "max_drawdown_pct": float(dd) * 100, "start_close": start, "end_close": end}


def signal_proxy_metrics(df: pd.DataFrame) -> dict:
    # Conservative proxy: long only when dataset says label_win after feature threshold.
    # This is not a real execution backtest; it is a benchmark sanity layer.
    if "label_win" not in df.columns or "future_return" not in df.columns:
        return {"note": "feature labels missing"}
    trades = df[(df.get("volume_ratio", 0) >= 1.45) & (df.get("rsi_14", 50) <= 74) & (df.get("overbought_low_volume", False) == False)].copy()
    if trades.empty:
        return {"trades": 0, "return_pct": 0.0, "win_rate": None, "avg_return_pct": None}
    returns = trades["future_return"].dropna()
    return {"trades": int(len(returns)), "return_pct": float(returns.sum() * 100), "win_rate": float((returns > 0).mean() * 100), "avg_return_pct": float(returns.mean() * 100)}


def main() -> None:
    ap = argparse.ArgumentParser(description="Compare feature-proxy signal results with buy-and-hold benchmark")
    ap.add_argument("--dataset", required=True)
    ap.add_argument("--out", default="reports/financial_datasets_benchmark_report.json")
    args = ap.parse_args()
    df = pd.read_csv(args.dataset)
    report = {"buy_and_hold": buy_hold_metrics(df), "signal_proxy": signal_proxy_metrics(df), "rows": int(len(df))}
    out = Path(args.out); out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"WROTE {out}")

if __name__ == "__main__":
    main()
