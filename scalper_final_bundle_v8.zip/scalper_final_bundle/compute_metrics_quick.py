from pathlib import Path
import sys
BASE = Path(__file__).resolve().parents[1] if Path(__file__).resolve().parent.name == "tools" else Path(__file__).resolve().parent
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))

import json, os, math
from statistics import mean, stdev
from project_paths import BACKTEST_BATCH, BACKTEST_METRICS_QUICK

p = str(BACKTEST_BATCH)
with open(p,'r',encoding='utf-8') as f:
    data = json.load(f)
# For each symbol, compute placeholder metrics: return, trades
out = []
for r in data:
    symbol = r.get('symbol')
    final = r.get('final_equity', None)
    trades = r.get('trades', 0)
    ret = None
    if final is not None:
        ret = (final - 1000.0)/1000.0
    out.append({'symbol':symbol,'final_equity':final,'trades':trades,'return_pct':ret})
# sort by final_equity desc
out_sorted = sorted([o for o in out if o['final_equity'] is not None], key=lambda x: x['final_equity'], reverse=True)
print('Top 10 by final_equity:')
for o in out_sorted[:10]:
    print(o)
# write to file
op = str(BACKTEST_METRICS_QUICK)
with open(op,'w',encoding='utf-8') as f:
    json.dump(out_sorted, f, ensure_ascii=False, indent=2)
print('WROTE',op)
