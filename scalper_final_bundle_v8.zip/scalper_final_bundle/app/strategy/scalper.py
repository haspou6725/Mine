"""
Conservative scalper signal rules.

This module intentionally avoids turning every volume spike into a LONG. A trade
signal needs trend, VWAP, volume, OBV, and anti-chase filters. It remains simple
enough to audit and to backtest without hidden ML state.
"""
from __future__ import annotations

import pandas as pd


REQUIRED_COLUMNS = {"close", "close_ema_9", "close_ema_21", "vol_z_20"}


def _ensure_optional_features(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    if "close_ema_50" not in out:
        out["close_ema_50"] = out["close"].ewm(span=50, adjust=False).mean()
    if "vwap_60" not in out:
        # Fallback for older feature files; add_basic_features now creates this.
        if {"high", "low", "volume"}.issubset(out.columns):
            typical = (out["high"] + out["low"] + out["close"]) / 3.0
            vol = out["volume"].replace(0, pd.NA)
            out["vwap_60"] = (typical * vol).rolling(60, min_periods=1).sum() / vol.rolling(60, min_periods=1).sum()
            out["vwap_60"] = out["vwap_60"].ffill().fillna(out["close"])
        else:
            out["vwap_60"] = out["close"]
    if "rsi_14" not in out:
        delta = out["close"].diff()
        gain = delta.clip(lower=0).ewm(alpha=1 / 14, adjust=False).mean()
        loss = (-delta.clip(upper=0)).ewm(alpha=1 / 14, adjust=False).mean()
        out["rsi_14"] = (100 - (100 / (1 + gain / loss.replace(0, pd.NA)))).fillna(50.0)
    if "ret_12" not in out:
        out["ret_12"] = out["close"].pct_change(12).fillna(0.0)
    if "obv" not in out and "volume" in out:
        out["obv"] = (out["close"].diff().fillna(0).apply(lambda x: 1 if x > 0 else (-1 if x < 0 else 0)) * out["volume"].fillna(0)).cumsum()
    if "obv_ema_10" not in out:
        out["obv_ema_10"] = out.get("obv", pd.Series(0, index=out.index)).ewm(span=10, adjust=False).mean()
    return out


def generate_signals(
    df: pd.DataFrame,
    vol_z_threshold: float = 2.0,
    profit_target: float = 0.01,
    stop_loss: float = 0.01,
    side: str = "BOTH",
    max_chase_1h_pct: float = 0.06,
    max_long_rsi: float = 72.0,
    min_short_rsi: float = 28.0,
) -> pd.DataFrame:
    """Generate audited LONG/SHORT signals.

    Parameters are kept backward compatible with the old function. ``profit_target``
    and ``stop_loss`` are not used here; the backtester/risk planner handles exits.
    """
    missing = REQUIRED_COLUMNS.difference(df.columns)
    if missing:
        raise ValueError(f"Required indicators missing: {sorted(missing)}. Run add_basic_features first.")

    side = side.upper().strip()
    if side not in {"LONG", "SHORT", "BOTH"}:
        raise ValueError("side must be LONG, SHORT, or BOTH")

    out = _ensure_optional_features(df)
    out["signal"] = 0
    out["signal_reason"] = ""

    ema_cross_up = (out["close_ema_9"] > out["close_ema_21"]) & (out["close_ema_9"].shift() <= out["close_ema_21"].shift())
    ema_cross_down = (out["close_ema_9"] < out["close_ema_21"]) & (out["close_ema_9"].shift() >= out["close_ema_21"].shift())
    vol_spike = out["vol_z_20"] >= float(vol_z_threshold)

    above_vwap = out["close"] > out["vwap_60"]
    below_vwap = out["close"] < out["vwap_60"]
    bullish_regime = (out["close"] > out["close_ema_20"]) & (out["close_ema_20"] > out["close_ema_50"])
    bearish_regime = (out["close"] < out["close_ema_20"]) & (out["close_ema_20"] < out["close_ema_50"])
    obv_up = out["obv"] > out["obv_ema_10"]
    obv_down = out["obv"] < out["obv_ema_10"]

    # Anti-chase filters: avoid entering after stretched pump/dump candles.
    long_not_chased = (out["ret_12"] <= float(max_chase_1h_pct)) & (out["rsi_14"] <= float(max_long_rsi))
    short_not_chased = (out["ret_12"] >= -float(max_chase_1h_pct)) & (out["rsi_14"] >= float(min_short_rsi))

    long_entries = ema_cross_up & vol_spike & above_vwap & bullish_regime & obv_up & long_not_chased
    short_entries = ema_cross_down & vol_spike & below_vwap & bearish_regime & obv_down & short_not_chased

    if side in {"LONG", "BOTH"}:
        out.loc[long_entries, "signal"] = 1
        out.loc[long_entries, "signal_reason"] = "ema_cross_up+volume+vwap+trend+obv+anti_chase"
    if side in {"SHORT", "BOTH"}:
        out.loc[short_entries, "signal"] = -1
        out.loc[short_entries, "signal_reason"] = "ema_cross_down+volume+vwap+trend+obv+anti_chase"

    return out
