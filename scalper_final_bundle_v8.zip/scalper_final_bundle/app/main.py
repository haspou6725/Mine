"""
FastAPI app exposing simple endpoints for scanning symbols, fetching klines, computing features and running backtests.
Run with: uvicorn app.main:app --reload --port 8000
"""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
from app.data.binance_futures import scan_symbols, get_klines
from app.features.indicators import klines_to_df, add_basic_features
from app.strategy.scalper import generate_signals
from app.backtest.simple_backtester import backtest

app = FastAPI(title="Meme-Scalper API")

class ScanParams(BaseModel):
    price_lt: float = 1.0
    vol24_gt: float = 100_000.0
    limit: int = 200

@app.post('/scan')
def api_scan(p: ScanParams = ScanParams()):
    try:
        matches = scan_symbols(price_lt=p.price_lt, vol24_gt=p.vol24_gt, limit=p.limit)
        return {'count': len(matches), 'matches': matches}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get('/klines/{symbol}')
def api_klines(symbol: str, interval: str = '1m', limit: int = 500):
    try:
        kl = get_klines(symbol.upper(), interval=interval, limit=limit)
        return {'symbol': symbol.upper(), 'klines': kl}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get('/features/{symbol}')
def api_features(symbol: str, interval: str = '1m', limit: int = 500):
    try:
        kl = get_klines(symbol.upper(), interval=interval, limit=limit)
        df = klines_to_df(kl)
        df2 = add_basic_features(df)
        # return last 50 rows as JSON table
        return {'symbol': symbol.upper(), 'features': df2.tail(50).to_dict(orient='records')}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post('/backtest/{symbol}')
def api_backtest(symbol: str):
    try:
        kl = get_klines(symbol.upper(), interval='1m', limit=1000)
        df = klines_to_df(kl)
        df = add_basic_features(df)
        df = generate_signals(df)
        res = backtest(df)
        return {'symbol': symbol.upper(), 'result': res}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
