"""LONA/Backtrader-compatible educational strategy adapter.

This file mirrors the live scanner's main guardrails in a Backtrader Strategy so
that parameter sets can be tested outside the live FastAPI scanner. It does not
perform any real trading and should only be used for historical simulation.

To upload to LONA, copy this file's code into LONA's strategy editor or use the
strategy id recorded in LONA_INTEGRATION_REPORT.md when available.
"""
from __future__ import annotations

try:  # Backtrader is optional for the main app runtime.
    import backtrader as bt
except Exception:  # pragma: no cover - lets normal project tests run without backtrader installed.
    bt = None  # type: ignore[assignment]


if bt is not None:

    class ScalperMemeSignalAdapter(bt.Strategy):
        """Backtrader approximation of the live signal model.

        Inputs expected by LONA/Backtrader are normal OHLCV candles. The live app
        has extra features such as spread, order book depth, funding, taker flow
        and BTC market context. In historical OHLCV-only backtests these are
        represented by conservative proxies: volume spike, ATR, RSI, trend and
        anti-chase rules.
        """

        params = (
            ("score_threshold", 72),
            ("early_threshold", 66),
            ("trap_threshold", 68),
            ("min_volume_spike", 1.45),
            ("max_long_rsi", 74),
            ("min_short_rsi", 26),
            ("max_long_chase_pct", 5.5),
            ("max_short_chase_pct", 8.5),
            ("hard_block_long_if_1h_move_above", 12.0),
            ("cooldown_bars", 20),
            ("risk_per_trade_pct", 0.005),
            ("stop_atr_mult", 1.6),
            ("tp1_r_mult", 1.2),
            ("tp2_r_mult", 2.0),
            ("use_long", True),
            ("use_short", False),
        )

        def __init__(self):
            self.rsi = bt.indicators.RSI(self.data.close, period=14)
            self.atr = bt.indicators.ATR(self.data, period=14)
            self.sma20 = bt.indicators.SMA(self.data.close, period=20)
            self.sma50 = bt.indicators.SMA(self.data.close, period=50)
            self.vol_sma20 = bt.indicators.SMA(self.data.volume, period=20)
            self.last_trade_bar = -10**9
            self.entry_price = None
            self.stop_price = None
            self.tp_price = None

        def _volume_spike(self) -> float:
            base = float(self.vol_sma20[0]) if self.vol_sma20[0] else 0.0
            return float(self.data.volume[0]) / base if base > 0 else 0.0

        def _change_lookback_pct(self, bars: int = 60) -> float:
            if len(self.data) <= bars:
                return 0.0
            old = float(self.data.close[-bars])
            return ((float(self.data.close[0]) - old) / old * 100.0) if old else 0.0

        def _long_score(self) -> float:
            trend = 25 if self.data.close[0] > self.sma20[0] > self.sma50[0] else 0
            momentum = max(0, min(20, 20 - abs(float(self.rsi[0]) - 58) * 1.2))
            vol = min(25, self._volume_spike() * 10)
            chase = self._change_lookback_pct(60)
            anti_chase_penalty = 0.0
            if chase > self.p.max_long_chase_pct:
                anti_chase_penalty += min(18, (chase - self.p.max_long_chase_pct) * 1.5)
            if chase > self.p.hard_block_long_if_1h_move_above:
                anti_chase_penalty += 30
            rsi_penalty = 12 if float(self.rsi[0]) > self.p.max_long_rsi else 0
            return trend + momentum + vol + 30 - anti_chase_penalty - rsi_penalty

        def _trap_score(self) -> float:
            trap = 0.0
            if float(self.rsi[0]) > self.p.max_long_rsi:
                trap += 18
            if self._change_lookback_pct(60) > self.p.max_long_chase_pct:
                trap += 20
            if self._volume_spike() < self.p.min_volume_spike:
                trap += 12
            if self.data.close[0] < self.sma20[0]:
                trap += 16
            return trap

        def next(self):
            if len(self.data) < 80:
                return

            if self.position:
                if self.position.size > 0 and (self.data.close[0] <= self.stop_price or self.data.close[0] >= self.tp_price):
                    self.close()
                return

            if len(self.data) - self.last_trade_bar < self.p.cooldown_bars:
                return

            vol_ok = self._volume_spike() >= self.p.min_volume_spike
            rsi_ok = float(self.rsi[0]) <= self.p.max_long_rsi
            trap_ok = self._trap_score() < self.p.trap_threshold
            score = self._long_score()

            if self.p.use_long and score >= self.p.score_threshold and vol_ok and rsi_ok and trap_ok:
                price = float(self.data.close[0])
                stop_dist = max(float(self.atr[0]) * self.p.stop_atr_mult, price * 0.006)
                cash_risk = self.broker.getvalue() * self.p.risk_per_trade_pct
                size = cash_risk / stop_dist if stop_dist > 0 else 0
                if size > 0:
                    self.entry_price = price
                    self.stop_price = price - stop_dist
                    self.tp_price = price + stop_dist * self.p.tp1_r_mult
                    self.buy(size=size)
                    self.last_trade_bar = len(self.data)
