"""
Candle-based linear futures backtester.

Key audit fixes:
- Entries execute on the next candle open to avoid look-ahead bias.
- Equity is cash + unrealized PnL, not cash + full position market value.
  The previous implementation added the whole position value and created fake
  profits even when price did not move.
- Supports LONG and SHORT signals.
- Simulates entry/exit commission and directional slippage.
"""
from __future__ import annotations

from typing import Any, Dict

import pandas as pd


SignalResult = Dict[str, Any]


def _max_drawdown(values: list[float]) -> float:
    peak = None
    max_dd = 0.0
    for value in values:
        if peak is None or value > peak:
            peak = value
        if peak and peak > 0:
            max_dd = max(max_dd, (peak - value) / peak)
    return float(max_dd)


def _fill_price(raw_price: float, side: str, action: str, slippage: float) -> float:
    """Return a conservative fill price for the requested side/action."""
    side = side.upper()
    action = action.upper()
    slip = abs(float(slippage))
    if side == "LONG":
        # Buy higher on entry, sell lower on exit.
        return raw_price * (1.0 + slip) if action == "ENTRY" else raw_price * (1.0 - slip)
    if side == "SHORT":
        # Sell lower on entry, buy higher on exit.
        return raw_price * (1.0 - slip) if action == "ENTRY" else raw_price * (1.0 + slip)
    raise ValueError(f"unsupported side: {side}")


def _unrealized_pnl(side: str, entry_price: float, mark_price: float, qty: float) -> float:
    if side == "LONG":
        return (mark_price - entry_price) * qty
    if side == "SHORT":
        return (entry_price - mark_price) * qty
    return 0.0


def backtest(
    df: pd.DataFrame,
    initial_capital: float = 1000.0,
    leverage: float = 1.0,
    commission: float = 0.0004,
    slippage: float = 0.0005,
    position_size_pct: float = 0.1,
    profit_target: float = 0.01,
    stop_loss: float = 0.01,
    allow_short: bool = True,
) -> SignalResult:
    """
    Backtest a signal column with realistic linear-perp accounting.

    Signal convention:
      1  -> long entry / short exit
     -1  -> short entry / long exit
      0  -> hold/no new signal

    ``position_size_pct`` is the fraction of current equity used as margin.
    Notional = equity * position_size_pct * leverage.
    """
    if df is None or len(df) == 0:
        return {
            "final_equity": float(initial_capital),
            "trades": [],
            "equity_curve": [],
            "metrics": {"num_entries": 0, "num_exits": 0, "total_fees": 0.0, "max_drawdown": 0.0},
        }

    work = df.copy().reset_index()
    cash = float(initial_capital)
    equity = float(initial_capital)
    position_side: str | None = None
    position_qty = 0.0
    entry_price = 0.0
    entry_notional = 0.0
    total_fees = 0.0

    trades: list[dict[str, Any]] = []
    equity_curve: list[dict[str, Any]] = []

    first_ts = work.loc[0].get("open_time") if "open_time" in work.columns else None
    equity_curve.append({"ts": first_ts, "equity": float(equity)})

    for i in range(len(work) - 1):
        row = work.loc[i]
        next_row = work.loc[i + 1]
        signal = int(row.get("signal", 0) or 0)
        raw_next_open = float(next_row["open"])
        ts = next_row.get("open_time") if "open_time" in work.columns else None

        # Exit first on opposite signal or risk rule.
        if position_side is not None:
            mark_price = raw_next_open
            unrealized = _unrealized_pnl(position_side, entry_price, mark_price, position_qty)
            pnl_pct = unrealized / entry_notional if entry_notional else 0.0

            exit_reason = None
            if pnl_pct >= abs(float(profit_target)):
                exit_reason = "take_profit"
            elif pnl_pct <= -abs(float(stop_loss)):
                exit_reason = "stop_loss"
            elif (position_side == "LONG" and signal == -1) or (position_side == "SHORT" and signal == 1):
                exit_reason = "opposite_signal"

            if exit_reason is not None:
                exit_price = _fill_price(raw_next_open, position_side, "EXIT", slippage)
                close_notional = exit_price * position_qty
                fee = abs(close_notional) * float(commission)
                realized_pnl = _unrealized_pnl(position_side, entry_price, exit_price, position_qty)
                cash += realized_pnl - fee
                total_fees += fee
                trades.append({
                    "side": position_side,
                    "action": "EXIT",
                    "price": float(exit_price),
                    "qty": float(position_qty),
                    "notional": float(close_notional),
                    "fee": float(fee),
                    "ts": ts,
                    "realized_pnl": float(realized_pnl),
                    "exit_reason": exit_reason,
                    "cash_after": float(cash),
                })
                position_side = None
                position_qty = 0.0
                entry_price = 0.0
                entry_notional = 0.0

        # Entry after exit handling. This avoids same-candle reverse overfitting.
        if position_side is None and signal in (1, -1):
            new_side = "LONG" if signal == 1 else "SHORT"
            if new_side == "SHORT" and not allow_short:
                new_side = ""
            if new_side:
                notional = max(0.0, equity * float(position_size_pct) * float(leverage))
                if notional > 0:
                    fill_price = _fill_price(raw_next_open, new_side, "ENTRY", slippage)
                    qty = notional / fill_price if fill_price > 0 else 0.0
                    fee = abs(notional) * float(commission)
                    cash -= fee
                    total_fees += fee
                    position_side = new_side
                    position_qty = qty
                    entry_price = fill_price
                    entry_notional = notional
                    trades.append({
                        "side": new_side,
                        "action": "ENTRY",
                        "price": float(fill_price),
                        "qty": float(qty),
                        "notional": float(notional),
                        "fee": float(fee),
                        "ts": ts,
                        "cash_after": float(cash),
                    })

        if position_side is not None:
            unrealized = _unrealized_pnl(position_side, entry_price, raw_next_open, position_qty)
            equity = cash + unrealized
        else:
            equity = cash
        equity_curve.append({"ts": ts, "equity": float(equity)})

    realized_exits = [t for t in trades if t.get("action") == "EXIT"]
    wins = [t for t in realized_exits if float(t.get("realized_pnl") or 0.0) > 0]
    equity_values = [float(x["equity"]) for x in equity_curve if x.get("equity") is not None]
    metrics = {
        "num_entries": int(sum(1 for t in trades if t.get("action") == "ENTRY")),
        "num_exits": int(len(realized_exits)),
        "win_rate": float(len(wins) / len(realized_exits)) if realized_exits else None,
        "total_fees": round(float(total_fees), 8),
        "max_drawdown": _max_drawdown(equity_values),
        "accounting_model": "linear_futures_cash_plus_unrealized_pnl",
        "open_position": None if position_side is None else {
            "side": position_side,
            "qty": float(position_qty),
            "entry_price": float(entry_price),
            "entry_notional": float(entry_notional),
        },
    }
    return {"final_equity": float(equity), "trades": trades, "equity_curve": equity_curve, "metrics": metrics}
