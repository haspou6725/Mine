"""Market-regime feature calculators for historical OHLCV datasets."""
from __future__ import annotations

from typing import Any
import pandas as pd

from app.features.indicators import rsi, ema, atr


def add_market_regime_features(df: pd.DataFrame, prefix: str = "") -> pd.DataFrame:
    d = df.copy()
    if "timestamp" in d.columns:
        d["timestamp"] = pd.to_datetime(d["timestamp"], errors="coerce")
        d = d.sort_values("timestamp")
    for col in ["open", "high", "low", "close", "volume"]:
        d[col] = pd.to_numeric(d[col], errors="coerce")
    p = f"{prefix}_" if prefix else ""
    d[f"{p}rsi_14"] = rsi(d["close"], 14)
    d[f"{p}ema_12"] = ema(d["close"], 12)
    d[f"{p}ema_26"] = ema(d["close"], 26)
    d[f"{p}macd"] = d[f"{p}ema_12"] - d[f"{p}ema_26"]
    d[f"{p}macd_signal"] = ema(d[f"{p}macd"], 9)
    d[f"{p}macd_hist"] = d[f"{p}macd"] - d[f"{p}macd_signal"]
    d[f"{p}atr_14"] = atr(d, 14)
    d[f"{p}atr_pct"] = (d[f"{p}atr_14"] / d["close"].replace(0, pd.NA)).fillna(0)
    vol_ma = d["volume"].rolling(20, min_periods=1).mean().replace(0, pd.NA)
    d[f"{p}volume_ratio"] = (d["volume"] / vol_ma).fillna(0)
    d[f"{p}trend_up"] = (d["close"] > ema(d["close"], 20)) & (ema(d["close"], 20) > ema(d["close"], 50))
    d[f"{p}overbought_low_volume"] = (d[f"{p}rsi_14"] >= 70) & (d[f"{p}volume_ratio"] < 0.8)
    d[f"{p}risk_off"] = (d[f"{p}macd_hist"] < 0) & (d[f"{p}rsi_14"] > 65)
    return d


def latest_regime_summary(df: pd.DataFrame, prefix: str = "") -> dict[str, Any]:
    enriched = add_market_regime_features(df, prefix=prefix)
    if enriched.empty:
        return {"ok": False, "error": "empty_regime_dataset"}
    row = enriched.iloc[-1]
    p = f"{prefix}_" if prefix else ""
    return {
        "ok": True,
        "rsi_14": float(row[f"{p}rsi_14"]),
        "macd_hist": float(row[f"{p}macd_hist"]),
        "volume_ratio": float(row[f"{p}volume_ratio"]),
        "atr_pct": float(row[f"{p}atr_pct"]),
        "trend_up": bool(row[f"{p}trend_up"]),
        "overbought_low_volume": bool(row[f"{p}overbought_low_volume"]),
        "risk_off": bool(row[f"{p}risk_off"]),
    }
