from __future__ import annotations

from statistics import median
from typing import Sequence

Number = float | int

def safe_float(value: object, default: float = 0.0) -> float:
    try:
        if value is None:
            return default
        return float(value)
    except (TypeError, ValueError):
        return default

def clamp(value: float, low: float = 0.0, high: float = 100.0) -> float:
    return max(low, min(high, value))

def pct_change(new: Number, old: Number) -> float:
    old_f = safe_float(old)
    new_f = safe_float(new)
    if old_f == 0:
        return 0.0
    return ((new_f - old_f) / abs(old_f)) * 100.0

def ema(values: Sequence[Number], period: int = 20) -> float:
    vals = [safe_float(v) for v in values if v is not None]
    if not vals:
        return 0.0
    if period <= 1:
        return vals[-1]
    k = 2.0 / (period + 1.0)
    out = vals[0]
    for v in vals[1:]:
        out = v * k + out * (1.0 - k)
    return out

def rsi(closes: Sequence[Number], period: int = 14) -> float:
    vals = [safe_float(x) for x in closes]
    if len(vals) < period + 1:
        return 50.0
    gains = 0.0
    losses = 0.0
    for i in range(len(vals) - period, len(vals)):
        diff = vals[i] - vals[i - 1]
        if diff >= 0:
            gains += diff
        else:
            losses += abs(diff)
    if losses == 0:
        return 100.0
    rs = gains / losses
    return 100.0 - (100.0 / (1.0 + rs))

def atr(klines: Sequence[dict], period: int = 14) -> float:
    if len(klines) < period + 1:
        return 0.0
    trs: list[float] = []
    for i in range(1, len(klines)):
        high = safe_float(klines[i].get("high"))
        low = safe_float(klines[i].get("low"))
        prev_close = safe_float(klines[i - 1].get("close"))
        trs.append(max(high - low, abs(high - prev_close), abs(low - prev_close)))
    recent = trs[-period:]
    return sum(recent) / len(recent) if recent else 0.0

def vwap(klines: Sequence[dict], lookback: int = 60) -> float:
    selected = klines[-lookback:] if len(klines) > lookback else klines
    pv = 0.0
    volume = 0.0
    for k in selected:
        high = safe_float(k.get("high"))
        low = safe_float(k.get("low"))
        close = safe_float(k.get("close"))
        vol = safe_float(k.get("volume"))
        typical = (high + low + close) / 3.0
        pv += typical * vol
        volume += vol
    return pv / volume if volume else 0.0

def median_ratio(current: float, history: Sequence[float]) -> float:
    clean = [safe_float(x) for x in history if safe_float(x) > 0]
    if not clean:
        return 1.0
    return safe_float(current) / (median(clean) or 1.0)

def volume_spike(klines: Sequence[dict], lookback: int = 50) -> float:
    if len(klines) < 5:
        return 1.0
    return median_ratio(safe_float(klines[-1].get("volume")), [safe_float(k.get("volume")) for k in klines[-lookback - 1:-1]])

def quote_volume_spike(klines: Sequence[dict], lookback: int = 50) -> float:
    if len(klines) < 5:
        return 1.0
    return median_ratio(safe_float(klines[-1].get("quote_volume")), [safe_float(k.get("quote_volume")) for k in klines[-lookback - 1:-1]])

def candle_change(klines: Sequence[dict], candles_back: int = 3) -> float:
    if len(klines) <= candles_back:
        return 0.0
    return pct_change(klines[-1].get("close"), klines[-1 - candles_back].get("close"))

def recent_low_break(klines: Sequence[dict], lookback: int = 20) -> bool:
    if len(klines) <= lookback + 1:
        return False
    last_close = safe_float(klines[-1].get("close"))
    prev_lows = [safe_float(k.get("low")) for k in klines[-lookback - 1:-1]]
    return bool(prev_lows) and last_close < min(prev_lows)

def recent_high_break(klines: Sequence[dict], lookback: int = 20) -> bool:
    if len(klines) <= lookback + 1:
        return False
    last_close = safe_float(klines[-1].get("close"))
    prev_highs = [safe_float(k.get("high")) for k in klines[-lookback - 1:-1]]
    return bool(prev_highs) and last_close > max(prev_highs)

def taker_sell_pressure_from_klines(klines: Sequence[dict], lookback: int = 12) -> float:
    selected = klines[-lookback:] if len(klines) > lookback else klines
    buy_quote = sum(safe_float(k.get("taker_buy_quote_volume")) for k in selected)
    total_quote = sum(safe_float(k.get("quote_volume")) for k in selected)
    if total_quote <= 0:
        return 0.5
    return max(0.0, total_quote - buy_quote) / total_quote

def cvd_proxy(klines: Sequence[dict], lookback: int = 60) -> float:
    selected = klines[-lookback:] if len(klines) > lookback else klines
    total_quote = 0.0
    delta = 0.0
    for k in selected:
        qv = safe_float(k.get("quote_volume"))
        buy = safe_float(k.get("taker_buy_quote_volume"))
        sell = max(0.0, qv - buy)
        delta += buy - sell
        total_quote += qv
    return delta / total_quote if total_quote else 0.0

def orderbook_metrics(depth: dict, levels: int = 50) -> dict:
    bids = depth.get("bids") or []
    asks = depth.get("asks") or []
    bid_qty = sum(safe_float(row[1]) for row in bids[:levels])
    ask_qty = sum(safe_float(row[1]) for row in asks[:levels])
    bid_notional = sum(safe_float(row[0]) * safe_float(row[1]) for row in bids[:levels])
    ask_notional = sum(safe_float(row[0]) * safe_float(row[1]) for row in asks[:levels])
    best_bid = safe_float(bids[0][0]) if bids else 0.0
    best_ask = safe_float(asks[0][0]) if asks else 0.0
    mid = (best_bid + best_ask) / 2.0 if best_bid and best_ask else 0.0
    spread_pct = ((best_ask - best_bid) / mid * 100.0) if mid else 999.0
    denom = bid_notional + ask_notional
    imbalance = ((ask_notional - bid_notional) / denom) if denom else 0.0
    depth_1pct_usd = 0.0
    if mid:
        low = mid * 0.99
        high = mid * 1.01
        depth_1pct_usd += sum(safe_float(p) * safe_float(q) for p, q in bids if safe_float(p) >= low)
        depth_1pct_usd += sum(safe_float(p) * safe_float(q) for p, q in asks if safe_float(p) <= high)
    return {
        "bid_qty": bid_qty,
        "ask_qty": ask_qty,
        "bid_notional": bid_notional,
        "ask_notional": ask_notional,
        "best_bid": best_bid,
        "best_ask": best_ask,
        "spread_pct": spread_pct,
        "ask_bid_imbalance": imbalance,
        "depth_1pct_usd": depth_1pct_usd,
        "last_update_id": depth.get("lastUpdateId"),
    }
