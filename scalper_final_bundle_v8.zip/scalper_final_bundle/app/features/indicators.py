"""
Feature engineering utilities for Binance klines.

The signal engine uses these columns as audit-friendly inputs: trend, volume,
VWAP, RSI, ATR, short-term returns, and OBV. They are intentionally simple and
fully reproducible from OHLCV data.
"""
from __future__ import annotations

from typing import Any, List

import numpy as np
import pandas as pd


NUMERIC_COLUMNS = [
    "open", "high", "low", "close", "volume", "quote_volume",
    "trade_count", "taker_base_vol", "taker_quote_vol",
]


def klines_to_df(klines: List[List[Any]]) -> pd.DataFrame:
    """Convert Binance kline arrays to a pandas DataFrame with useful columns.

    Binance kline format per row:
    [Open time, Open, High, Low, Close, Volume, Close time, Quote asset volume,
     Number of trades, Taker base vol, Taker quote vol, Ignore]
    """
    cols = [
        "open_time", "open", "high", "low", "close", "volume", "close_time",
        "quote_volume", "trade_count", "taker_base_vol", "taker_quote_vol", "ignore",
    ]
    df = pd.DataFrame(klines, columns=cols)
    for col in NUMERIC_COLUMNS:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df["open_time"] = pd.to_datetime(df["open_time"], unit="ms")
    df["close_time"] = pd.to_datetime(df["close_time"], unit="ms")
    df.set_index("open_time", inplace=True)
    return df


def sma(series: pd.Series, window: int) -> pd.Series:
    return series.rolling(window=window, min_periods=1).mean()


def ema(series: pd.Series, span: int) -> pd.Series:
    return series.ewm(span=span, adjust=False).mean()


def atr(df: pd.DataFrame, window: int = 14) -> pd.Series:
    high_low = df["high"] - df["low"]
    high_close = (df["high"] - df["close"].shift()).abs()
    low_close = (df["low"] - df["close"].shift()).abs()
    tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    return tr.rolling(window=window, min_periods=1).mean()


def momentum(series: pd.Series, window: int = 10) -> pd.Series:
    return series.pct_change(periods=window)


def volume_zscore(series: pd.Series, window: int = 20) -> pd.Series:
    mean = series.rolling(window=window, min_periods=1).mean()
    std = series.rolling(window=window, min_periods=1).std(ddof=0).fillna(0.0)
    z = (series - mean) / std.replace(0, np.nan)
    return z.fillna(0.0)


def rsi(series: pd.Series, period: int = 14) -> pd.Series:
    delta = series.diff()
    gain = delta.clip(lower=0).ewm(alpha=1 / period, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1 / period, adjust=False).mean()
    rs = gain / loss.replace(0, np.nan)
    return (100 - (100 / (1 + rs))).fillna(50.0).clip(0, 100)


def rolling_vwap(df: pd.DataFrame, window: int = 60) -> pd.Series:
    typical = (df["high"] + df["low"] + df["close"]) / 3.0
    vol = df["volume"].replace(0, np.nan)
    pv = (typical * vol).rolling(window=window, min_periods=1).sum()
    vv = vol.rolling(window=window, min_periods=1).sum()
    return (pv / vv).ffill().fillna(df["close"])


def obv(close: pd.Series, volume: pd.Series) -> pd.Series:
    direction = np.sign(close.diff()).fillna(0.0)
    return (direction * volume.fillna(0.0)).cumsum()


def add_basic_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["close_sma_20"] = sma(df["close"], 20)
    df["close_ema_9"] = ema(df["close"], 9)
    df["close_ema_20"] = ema(df["close"], 20)
    df["close_ema_21"] = ema(df["close"], 21)
    df["close_ema_50"] = ema(df["close"], 50)
    df["atr_14"] = atr(df, 14)
    df["atr_pct_14"] = (df["atr_14"] / df["close"].replace(0, np.nan)).fillna(0.0)
    df["mom_10"] = momentum(df["close"], 10)
    df["ret_3"] = df["close"].pct_change(3).fillna(0.0)
    df["ret_12"] = df["close"].pct_change(12).fillna(0.0)
    df["vol_z_20"] = volume_zscore(df["quote_volume"], 20)
    df["vwap_60"] = rolling_vwap(df, 60)
    df["rsi_14"] = rsi(df["close"], 14)
    df["obv"] = obv(df["close"], df["volume"])
    df["obv_ema_10"] = ema(df["obv"], 10)
    return df
