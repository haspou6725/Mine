"""Compatibility wrapper for the production multi-source confidence engine."""
from merged_imports.scalper_meme_plus_backend.engine.multisource_confidence import *  # noqa: F401,F403
