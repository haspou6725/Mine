from __future__ import annotations

import math
from typing import Any


def safe_float(value, default: float = 0.0) -> float:
    try:
        if value is None:
            return default
        return float(value)
    except (TypeError, ValueError):
        return default

def clamp(value: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, float(value)))


def _bool_setting(settings: Any, name: str, default: bool = False) -> bool:
    return bool(getattr(settings, name, default))


def dynamic_spread_gate(metrics: dict[str, Any], settings: Any) -> float:
    """Return venue-aware max spread percentage.

    The static UI value remains the absolute ceiling, while high-volume Binance Futures
    symbols are held to stricter execution thresholds. Low-volume symbols keep the user
    configured ceiling so the model does not silently exclude every micro-cap.
    """
    static_gate = safe_float(metrics.get("max_spread_pct_gate"), safe_float(getattr(settings, "max_spread_pct", 0.28)))
    if not _bool_setting(settings, "use_dynamic_spread_threshold", True):
        return static_gate
    qv = safe_float(metrics.get("quote_volume_24h"))
    if qv >= 100_000_000:
        return min(static_gate, 0.10)
    if qv >= 30_000_000:
        return min(static_gate, 0.14)
    if qv >= 10_000_000:
        return min(static_gate, 0.18)
    if qv >= 3_000_000:
        return min(static_gate, 0.22)
    return static_gate


def dynamic_depth_gate(metrics: dict[str, Any], settings: Any) -> float:
    """Return dynamic minimum ±1% book depth in USDT.

    Large/high-volume contracts must show deeper books. For thin but allowed meme symbols,
    the configured floor is preserved to avoid over-filtering.
    """
    static_gate = safe_float(metrics.get("min_depth_1pct_usd_gate"), safe_float(getattr(settings, "min_depth_1pct_usd", 45_000)))
    if not _bool_setting(settings, "use_dynamic_depth_threshold", True):
        return static_gate
    qv = safe_float(metrics.get("quote_volume_24h"))
    # Roughly 0.15% of 24h quote volume, capped so very active majors do not dominate.
    adaptive = min(250_000.0, max(static_gate, qv * 0.0015))
    return adaptive if qv >= 10_000_000 else static_gate


def market_volume_percentile_proxy(metrics: dict[str, Any]) -> float:
    qv = max(0.0, safe_float(metrics.get("quote_volume_24h")))
    # Smooth proxy; 1M≈30, 10M≈55, 100M≈80, 1B≈100.
    return clamp(5.0 + 25.0 * math.log10(max(1.0, qv) / 100_000.0 + 1.0))


def mark_index_premium_pct(metrics: dict[str, Any]) -> float | None:
    mark = metrics.get("mark_price")
    index = metrics.get("index_price")
    if mark is None or index is None:
        return None
    mark_f = safe_float(mark)
    index_f = safe_float(index)
    if mark_f <= 0 or index_f <= 0:
        return None
    return abs(mark_f - index_f) / index_f * 100.0


def taker_buy_ratio(metrics: dict[str, Any]) -> float | None:
    taker_sell = metrics.get("taker_sell_pressure")
    if taker_sell is None:
        return None
    return max(0.0, min(1.0, 1.0 - safe_float(taker_sell)))


def open_interest_context(metrics: dict[str, Any]) -> dict[str, Any]:
    oi_change = metrics.get("oi_change_pct")
    change_15m = safe_float(metrics.get("change_15m"))
    if oi_change is None:
        return {"available": False}
    oi = safe_float(oi_change)
    return {
        "available": True,
        "oi_change_pct": oi,
        "rising": oi >= 3.0,
        "falling": oi <= -3.0,
        "long_confirmation": oi >= 3.0 and change_15m > 0,
        "short_confirmation": oi >= 3.0 and change_15m < 0,
        "possible_long_trap": oi >= 3.0 and abs(change_15m) < 0.5,
    }


def funding_context(metrics: dict[str, Any], settings: Any) -> dict[str, Any]:
    funding = metrics.get("funding_rate")
    if funding is None:
        return {"available": False}
    f = safe_float(funding)
    hot = abs(f) >= safe_float(getattr(settings, "crowded_funding_abs_threshold", 0.00025))
    return {
        "available": True,
        "funding_rate": f,
        "hot_positive": f >= safe_float(getattr(settings, "crowded_funding_abs_threshold", 0.00025)),
        "hot_negative": f <= -safe_float(getattr(settings, "crowded_funding_abs_threshold", 0.00025)),
        "crowded": hot,
    }


def derive_microstructure(metrics: dict[str, Any], settings: Any) -> dict[str, Any]:
    spread_gate = dynamic_spread_gate(metrics, settings)
    depth_gate = dynamic_depth_gate(metrics, settings)
    premium_pct = mark_index_premium_pct(metrics)
    buy_ratio = taker_buy_ratio(metrics)
    funding = funding_context(metrics, settings)
    oi = open_interest_context(metrics)
    spread = safe_float(metrics.get("spread_pct"), 999)
    depth = safe_float(metrics.get("depth_1pct_usd"))
    max_premium = safe_float(getattr(settings, "max_mark_index_premium_pct", 0.12))
    return {
        "dynamic_spread_gate_pct": round(spread_gate, 6),
        "dynamic_depth_gate_usdt": round(depth_gate, 2),
        "spread_ok_dynamic": spread <= spread_gate,
        "depth_ok_dynamic": depth >= depth_gate,
        "quote_volume_percentile_proxy": round(market_volume_percentile_proxy(metrics), 2),
        "taker_buy_ratio": round(buy_ratio, 4) if buy_ratio is not None else None,
        "mark_index_premium_pct": round(premium_pct, 6) if premium_pct is not None else None,
        "mark_index_premium_ok": True if premium_pct is None else premium_pct <= max_premium,
        "funding": funding,
        "open_interest": oi,
        "execution_quality_ok": (spread <= spread_gate) and (depth >= depth_gate) and (True if premium_pct is None else premium_pct <= max_premium),
    }
