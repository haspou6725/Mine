"""
Simple Binance Futures (Perp) data module.
- Scans symbols via REST to find symbols with price < $1 and quoteVolume > threshold
- Provides kline snapshot (REST)
- Provides a combined websocket consumer for trade/kline streams (async)

Dependencies:
  pip install requests websockets

Usage:
  python binance_futures.py

Notes:
  - Uses public endpoints (no API key) for market data.
  - WebSocket connects to the futures (fstream) endpoint for perp markets.
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Callable, List, Dict, Any

import requests
import websockets

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("binance_futures")

BASE_REST = "https://fapi.binance.com"
BASE_WS = "wss://fstream.binance.com/stream"


def scan_symbols(price_lt: float = 1.0, vol24_gt: float = 100_000.0, limit: int = 500) -> List[Dict[str, Any]]:
    """Scan Binance Futures tickers and return symbols matching criteria.

    Args:
        price_lt: select symbols whose lastPrice < price_lt
        vol24_gt: select symbols whose quoteVolume (USDT) > vol24_gt
        limit: how many top symbols to return after filtering
    Returns:
        list of ticker dicts sorted by quoteVolume desc
    """
    url = f"{BASE_REST}/fapi/v1/ticker/24hr"
    logger.info("Fetching 24hr tickers from %s", url)
    resp = requests.get(url, timeout=15)
    resp.raise_for_status()
    data = resp.json()

    matches = []
    for t in data:
        try:
            sym = t.get("symbol")
            # focus on USDT perpetual pairs
            if not sym or not sym.endswith("USDT"):
                continue
            last = float(t.get("lastPrice", 0.0))
            quote_vol = float(t.get("quoteVolume", 0.0))
            if last < price_lt and quote_vol > vol24_gt:
                matches.append({
                    "symbol": sym,
                    "lastPrice": last,
                    "quoteVolume": quote_vol,
                    "raw": t,
                })
        except Exception:
            continue

    matches.sort(key=lambda x: x["quoteVolume"], reverse=True)
    return matches[:limit]


def get_klines(symbol: str, interval: str = "1m", limit: int = 500) -> List[List[Any]]:
    """Get recent klines from futures REST.

    Returns list of kline arrays as Binance returns.
    """
    url = f"{BASE_REST}/fapi/v1/klines"
    params = {"symbol": symbol, "interval": interval, "limit": limit}
    logger.info("Fetching klines for %s %s", symbol, interval)
    resp = requests.get(url, params=params, timeout=15)
    resp.raise_for_status()
    return resp.json()


class BinanceFuturesStreamer:
    """Simple combined-stream websocket client for futures (trade and kline).

    Provide callbacks to receive events. Runs until cancelled.
    """

    def __init__(self, symbols: List[str], on_event: Callable[[Dict[str, Any]], None]):
        # symbols e.g. ["PEPEUSDT", "DOGEUSDT"]
        self.symbols = symbols
        self.on_event = on_event
        # build stream names: lower(symbol)@trade and lower(symbol)@kline_1m
        self.streams = []
        for s in symbols:
            base = s.lower()
            self.streams.append(f"{base}@trade")
            self.streams.append(f"{base}@kline_1m")

        self.ws_url = f"{BASE_WS}?streams={"/".join(self.streams)}"

    async def run(self) -> None:
        logger.info("Connecting websocket to %s", self.ws_url)
        try:
            async with websockets.connect(self.ws_url, ping_interval=20, max_size=None) as ws:
                logger.info("WebSocket connected")
                async for raw in ws:
                    try:
                        msg = json.loads(raw)
                        # combined stream payload: {"stream": "btcusdt@trade", "data": {...}}
                        stream = msg.get("stream")
                        data = msg.get("data")
                        event = {"stream": stream, "data": data}
                        # call handler
                        self.on_event(event)
                    except Exception as e:
                        logger.exception("Failed to handle ws message: %s", e)
        except Exception as e:
            logger.exception("WebSocket connection failed: %s", e)


async def _example_stream(symbols: List[str]) -> None:
    def handle(ev: Dict[str, Any]):
        # lightweight handler: print a summary to stdout
        st = ev.get("stream")
        d = ev.get("data")
        if not d:
            return
        if "k" in d:  # kline
            k = d["k"]
            is_closed = k.get("x")
            if is_closed:
                logger.info("%s kline closed: %s O:%s C:%s H:%s L:%s", st, k.get('t'), k.get('o'), k.get('c'), k.get('h'), k.get('l'))
        elif d.get("e") == "trade":
            p = d.get("p")
            q = d.get("q")
            logger.debug("%s trade price=%s qty=%s", st, p, q)

    streamer = BinanceFuturesStreamer(symbols, handle)
    await streamer.run()


def main():
    logger.info("Running symbol scan (price<1, vol24>100k)")
    matches = scan_symbols(price_lt=1.0, vol24_gt=100_000.0, limit=200)
    if not matches:
        logger.warning("No matches found")
        return
    logger.info("Found %d matching symbols. Showing top 30:", len(matches))
    for m in matches[:30]:
        logger.info("%s price=%s vol=%s", m["symbol"], m["lastPrice"], m["quoteVolume"]) 

    # start websocket on top N symbols (non-blocking example)
    top_symbols = [m["symbol"] for m in matches[:10]]
    logger.info("Starting websocket for: %s", top_symbols)
    try:
        asyncio.run(_example_stream(top_symbols))
    except KeyboardInterrupt:
        logger.info("Interrupted, exiting")


if __name__ == "__main__":
    main()
