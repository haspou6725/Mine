"""
Financial Datasets integration layer.

This module is intentionally API-key optional and cache-first.  It lets the
project use Financial Datasets as a historical OHLCV / benchmark / market-regime
source without coupling live trading logic to a paid or unavailable endpoint.

Supported use cases:
- Fetch crypto OHLCV from Financial Datasets-compatible REST endpoints.
- Normalize rows into the internal timestamp/open/high/low/close/volume schema.
- Cache responses on disk for reproducible backtests and walk-forward tests.
- Fall back to an existing cached file or local CSV instead of fabricating data.

No order execution is implemented here.
"""
from __future__ import annotations

import csv
import json
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import urlencode
from urllib.request import Request, urlopen


DEFAULT_BASE_URL = "https://api.financialdatasets.ai"
DEFAULT_CACHE_DIR = Path("data/financial_datasets_cache")


@dataclass(frozen=True)
class FinancialDatasetsConfig:
    base_url: str = DEFAULT_BASE_URL
    api_key: str | None = None
    cache_dir: Path = DEFAULT_CACHE_DIR
    cache_ttl_sec: int = 3600
    timeout_sec: int = 20
    allow_network: bool = True

    @classmethod
    def from_env(cls) -> "FinancialDatasetsConfig":
        return cls(
            base_url=os.getenv("FINANCIAL_DATASETS_BASE_URL", DEFAULT_BASE_URL).rstrip("/"),
            api_key=os.getenv("FINANCIAL_DATASETS_API_KEY") or None,
            cache_dir=Path(os.getenv("FINANCIAL_DATASETS_CACHE_DIR", str(DEFAULT_CACHE_DIR))),
            cache_ttl_sec=int(os.getenv("FINANCIAL_DATASETS_CACHE_TTL_SEC", "3600")),
            timeout_sec=int(os.getenv("FINANCIAL_DATASETS_TIMEOUT_SEC", "20")),
            allow_network=os.getenv("FINANCIAL_DATASETS_ALLOW_NETWORK", "1") != "0",
        )


class FinancialDatasetsError(RuntimeError):
    pass


def to_fd_ticker(symbol: str) -> str:
    """Convert common Binance-style symbols to Financial Datasets crypto ticker form."""
    s = (symbol or "").upper().replace("/", "").replace("-", "")
    if s.endswith("USDT"):
        return f"{s[:-4]}-USD"
    if s.endswith("USD") and "-" not in symbol:
        return f"{s[:-3]}-USD"
    if "-" in symbol:
        return symbol.upper()
    return f"{s}-USD"


def normalize_ohlcv_rows(payload: Any) -> list[dict[str, Any]]:
    """Normalize Financial Datasets-style responses into OHLCV dictionaries.

    Accepts several common shapes to make tests and adapters robust:
    - {"prices": [...]}
    - {"data": [...]}
    - {"results": [...]}
    - a raw list of rows
    """
    if isinstance(payload, dict):
        rows = payload.get("prices") or payload.get("data") or payload.get("results") or payload.get("candles") or []
    else:
        rows = payload
    if not isinstance(rows, list):
        raise FinancialDatasetsError("financial_datasets_payload_has_no_rows")

    out: list[dict[str, Any]] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        ts = row.get("timestamp") or row.get("date") or row.get("time") or row.get("datetime")
        close = row.get("close") or row.get("price") or row.get("adj_close")
        if ts is None or close is None:
            continue
        open_ = row.get("open", close)
        high = row.get("high", max(open_, close) if _is_number(open_) and _is_number(close) else close)
        low = row.get("low", min(open_, close) if _is_number(open_) and _is_number(close) else close)
        out.append({
            "timestamp": ts,
            "open": _float_or_none(open_),
            "high": _float_or_none(high),
            "low": _float_or_none(low),
            "close": _float_or_none(close),
            "volume": _float_or_zero(row.get("volume", 0)),
            "source": "financial_datasets",
        })
    return out


def _is_number(value: Any) -> bool:
    try:
        float(value)
        return True
    except Exception:
        return False


def _float_or_none(value: Any) -> float | None:
    try:
        return float(value)
    except Exception:
        return None


def _float_or_zero(value: Any) -> float:
    try:
        return float(value)
    except Exception:
        return 0.0


class FinancialDatasetsClient:
    def __init__(self, config: FinancialDatasetsConfig | None = None):
        self.config = config or FinancialDatasetsConfig.from_env()
        self.config.cache_dir.mkdir(parents=True, exist_ok=True)

    def cache_path(self, ticker: str, interval: str, start_date: str, end_date: str) -> Path:
        safe = f"{ticker}_{interval}_{start_date}_{end_date}".replace("/", "_").replace(":", "_")
        return self.config.cache_dir / f"{safe}.json"

    def get_crypto_prices(
        self,
        ticker: str,
        interval: str = "day",
        start_date: str | None = None,
        end_date: str | None = None,
        limit: int = 5000,
        interval_multiplier: int = 1,
        force_refresh: bool = False,
    ) -> list[dict[str, Any]]:
        if not start_date or not end_date:
            raise ValueError("start_date and end_date are required for reproducible backtests")
        cache_file = self.cache_path(ticker, interval, start_date, end_date)
        if cache_file.exists() and not force_refresh:
            age = time.time() - cache_file.stat().st_mtime
            if age <= self.config.cache_ttl_sec or not self.config.allow_network:
                with cache_file.open("r", encoding="utf-8") as fh:
                    return normalize_ohlcv_rows(json.load(fh))

        if not self.config.allow_network:
            raise FinancialDatasetsError(f"network_disabled_and_cache_missing:{cache_file}")

        payload = self._request_crypto_prices(ticker, interval, start_date, end_date, limit, interval_multiplier)
        with cache_file.open("w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, indent=2)
        return normalize_ohlcv_rows(payload)

    def _request_crypto_prices(self, ticker: str, interval: str, start_date: str, end_date: str, limit: int, interval_multiplier: int) -> Any:
        """HTTP fallback for environments outside the ChatGPT tool runtime.

        Financial Datasets deployments may use slightly different route names.  The client tries
        a small set of compatible routes and returns the first successful JSON response.
        """
        params = {
            "ticker": ticker,
            "interval": interval,
            "start_date": start_date,
            "end_date": end_date,
            "limit": int(limit),
            "interval_multiplier": int(interval_multiplier),
        }
        headers = {"Accept": "application/json"}
        if self.config.api_key:
            headers["X-API-KEY"] = self.config.api_key
        routes = [
            "/crypto/prices",
            "/prices/crypto",
            "/crypto/prices/snapshot/history",
        ]
        errors: list[str] = []
        for route in routes:
            url = f"{self.config.base_url}{route}?{urlencode(params)}"
            try:
                req = Request(url, headers=headers)
                with urlopen(req, timeout=self.config.timeout_sec) as resp:
                    if resp.status < 200 or resp.status >= 300:
                        errors.append(f"{route}:http_{resp.status}")
                        continue
                    return json.loads(resp.read().decode("utf-8"))
            except Exception as exc:
                errors.append(f"{route}:{type(exc).__name__}:{exc}")
        raise FinancialDatasetsError("; ".join(errors) or "financial_datasets_request_failed")


def write_ohlcv_csv(rows: Iterable[dict[str, Any]], out_path: str | Path) -> Path:
    path = Path(out_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["timestamp", "open", "high", "low", "close", "volume", "source"]
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k) for k in fieldnames})
    return path
