from __future__ import annotations

from typing import Any
from .http import LiveHTTPClient, LiveDataError


class LBankContractClient:
    """Public LBank USDT perpetual market-data client.

    No API key, no order execution. This adapter deliberately never fabricates data:
    if a public endpoint is unavailable or has an unknown schema, the scanner skips
    that source/symbol and records the failure in Data Health / Skipped.
    """

    def __init__(self, product_group: str = "SwapU") -> None:
        self.product_group = product_group
        self.http = LiveHTTPClient("https://lbkperp.lbank.com", "lbank-contract")

    async def close(self) -> None:
        await self.http.close()

    def _unwrap(self, payload: Any) -> Any:
        if isinstance(payload, dict):
            if payload.get("success") is False or payload.get("error_code") not in (None, 0, "0"):
                raise LiveDataError(f"lbank-contract returned error: {payload}")
            if "data" in payload:
                return payload.get("data")
            if "result" in payload:
                return payload.get("result")
        return payload

    async def ping(self) -> dict[str, Any]:
        data = self._unwrap(await self.http.get_json("/cfd/openApi/v1/pub/getTime", cache_ttl=0))
        return {"serverTime": data}

    async def instruments(self) -> list[dict[str, Any]]:
        # The two path shapes below cover the public contract-doc variants seen in LBank mirrors.
        errors: list[str] = []
        for path in ("/cfd/openApi/v1/pub/instrument", "/cfd/openApi/v1/pub/getInstrument"):
            try:
                data = self._unwrap(await self.http.get_json(path, {"productGroup": self.product_group}, cache_ttl=900))
                if isinstance(data, list):
                    return [self._normalize_instrument(x) for x in data if isinstance(x, dict)]
            except Exception as exc:  # noqa: BLE001
                errors.append(f"{path}: {exc}")
        raise LiveDataError("lbank instruments failed; " + " | ".join(errors[:2]))

    async def market_data(self) -> list[dict[str, Any]]:
        errors: list[str] = []
        for path in ("/cfd/openApi/v1/pub/marketData", "/cfd/openApi/v1/pub/getMarketData"):
            try:
                data = self._unwrap(await self.http.get_json(path, {"productGroup": self.product_group}, cache_ttl=8))
                if isinstance(data, list):
                    return [self._normalize_market(x) for x in data if isinstance(x, dict)]
            except Exception as exc:  # noqa: BLE001
                errors.append(f"{path}: {exc}")
        raise LiveDataError("lbank marketData failed; " + " | ".join(errors[:2]))

    async def depth(self, symbol: str, depth: int = 50) -> dict[str, Any]:
        errors: list[str] = []
        candidates = [
            ("/cfd/openApi/v1/pub/marketOrder", {"symbol": symbol.upper(), "depth": depth}),
            ("/cfd/openApi/v1/pub/depth", {"symbol": symbol.upper(), "depth": depth}),
            ("/cfd/openApi/v1/pub/orderBook", {"symbol": symbol.upper(), "depth": depth}),
        ]
        for path, params in candidates:
            try:
                data = self._unwrap(await self.http.get_json(path, params, cache_ttl=3))
                if isinstance(data, dict):
                    return self._normalize_depth(data)
            except Exception as exc:  # noqa: BLE001
                errors.append(f"{path}: {exc}")
        raise LiveDataError(f"lbank depth failed for {symbol}; " + " | ".join(errors[:2]))

    async def klines(self, symbol: str, interval: str = "5m", limit: int = 160) -> list[dict[str, Any]]:
        period = self._period(interval)
        errors: list[str] = []
        candidates = [
            ("/cfd/openApi/v1/pub/kline", {"symbol": symbol.upper(), "period": period, "size": limit}),
            ("/cfd/openApi/v1/pub/kline", {"symbol": symbol.upper(), "type": period, "size": limit}),
            ("/cfd/openApi/v1/pub/getKline", {"symbol": symbol.upper(), "period": period, "size": limit}),
            ("/cfd/openApi/v1/pub/getKline", {"symbol": symbol.upper(), "type": period, "size": limit}),
        ]
        for path, params in candidates:
            try:
                data = self._unwrap(await self.http.get_json(path, params, cache_ttl=6))
                normalized = self._normalize_klines(data)
                if len(normalized) >= 30:
                    return normalized[-limit:]
            except Exception as exc:  # noqa: BLE001
                errors.append(f"{path}: {exc}")
        raise LiveDataError(f"lbank klines failed for {symbol}; " + " | ".join(errors[:2]))

    def _period(self, interval: str) -> str:
        mapping = {"1m": "1min", "3m": "3min", "5m": "5min", "15m": "15min", "30m": "30min", "1h": "1hour", "4h": "4hour", "1d": "1day"}
        return mapping.get(interval, interval)

    def _first(self, data: dict[str, Any], keys: list[str], default: Any = None) -> Any:
        for k in keys:
            if k in data and data.get(k) not in (None, ""):
                return data.get(k)
        return default

    def _to_float(self, x: Any, default: float = 0.0) -> float:
        try:
            if x is None or x == "":
                return default
            return float(x)
        except (TypeError, ValueError):
            return default

    def _normalize_instrument(self, x: dict[str, Any]) -> dict[str, Any]:
        symbol = str(self._first(x, ["symbol", "instrument", "contractCode", "contract_code"], "")).replace("_", "").upper()
        return {
            "symbol": symbol,
            "raw_symbol": self._first(x, ["symbol", "instrument", "contractCode", "contract_code"], symbol),
            "status": self._first(x, ["status", "state", "enable"], "TRADING"),
            "quote_asset": "USDT" if symbol.endswith("USDT") else self._first(x, ["quoteAsset", "quote", "quoteCurrency"], ""),
            "base_asset": self._first(x, ["baseAsset", "base", "baseCurrency"], symbol[:-4] if symbol.endswith("USDT") else symbol),
            "tag": self._first(x, ["tag", "area", "zone", "label"], None),
            "raw": x,
        }

    def _normalize_market(self, x: dict[str, Any]) -> dict[str, Any]:
        symbol = str(self._first(x, ["symbol", "instrument", "contractCode", "contract_code"], "")).replace("_", "").upper()
        price = self._to_float(self._first(x, ["lastPrice", "last", "price", "close", "last_price"]))
        mark = self._to_float(self._first(x, ["markPrice", "mark_price", "indexPrice", "index_price"]), price)
        high = self._to_float(self._first(x, ["highPrice", "high", "highestPrice", "h"]), price)
        low = self._to_float(self._first(x, ["lowPrice", "low", "lowestPrice", "l"]), price)
        base_vol = self._to_float(self._first(x, ["volume", "vol", "amount", "baseVolume"]))
        quote_vol = self._to_float(self._first(x, ["quoteVolume", "turnover", "amountVol", "usdtVolume", "quote_volume"]))
        if quote_vol <= 0 and base_vol > 0 and price > 0:
            quote_vol = base_vol * price
        change = self._to_float(self._first(x, ["priceChangePercent", "changeRate", "riseFallRate", "change", "rate"]))
        # Some APIs return 0.1534 instead of 15.34
        if -1.0 < change < 1.0 and change != 0:
            change *= 100.0
        return {
            "symbol": symbol,
            "raw_symbol": self._first(x, ["symbol", "instrument", "contractCode", "contract_code"], symbol),
            "lastPrice": price,
            "markPrice": mark,
            "highPrice": high,
            "lowPrice": low,
            "volume": base_vol,
            "quoteVolume": quote_vol,
            "priceChangePercent": change,
            "fundingRate": self._to_float(self._first(x, ["fundingRate", "funding_rate", "lastFundingRate"])),
            "openInterest": self._to_float(self._first(x, ["openInterest", "open_interest", "holdVol", "positionAmt"])),
            "tag": self._first(x, ["tag", "area", "zone", "label"], None),
            "raw": x,
        }

    def _normalize_depth(self, data: dict[str, Any]) -> dict[str, Any]:
        def row_to_pair(row: Any) -> list[str]:
            if isinstance(row, dict):
                return [str(self._first(row, ["price", "p"], 0)), str(self._first(row, ["volume", "qty", "q", "amount"], 0))]
            if isinstance(row, (list, tuple)) and len(row) >= 2:
                return [str(row[0]), str(row[1])]
            return ["0", "0"]
        bids = data.get("bids") or data.get("buy") or data.get("bid") or []
        asks = data.get("asks") or data.get("sell") or data.get("ask") or []
        return {"bids": [row_to_pair(x) for x in bids], "asks": [row_to_pair(x) for x in asks], "lastUpdateId": data.get("ts") or data.get("timestamp") or 0, "raw": data}

    def _normalize_klines(self, data: Any) -> list[dict[str, Any]]:
        if isinstance(data, dict):
            for key in ("list", "items", "klines", "candles", "rows"):
                if isinstance(data.get(key), list):
                    data = data.get(key)
                    break
        if not isinstance(data, list):
            return []
        rows: list[dict[str, Any]] = []
        for k in data:
            if isinstance(k, dict):
                t = self._to_float(self._first(k, ["time", "timestamp", "ts", "openTime", "id"]))
                o = self._to_float(self._first(k, ["open", "o"]))
                h = self._to_float(self._first(k, ["high", "h"]))
                l = self._to_float(self._first(k, ["low", "l"]))
                c = self._to_float(self._first(k, ["close", "c"]))
                v = self._to_float(self._first(k, ["volume", "vol", "amount", "v"]))
                qv = self._to_float(self._first(k, ["quoteVolume", "turnover", "quote_volume"])) or (v * c if v and c else 0.0)
            elif isinstance(k, (list, tuple)) and len(k) >= 6:
                # Accept both [time, open, high, low, close, volume] and [time, open, close, high, low, volume]
                t = self._to_float(k[0])
                nums = [self._to_float(x) for x in k[1:6]]
                o = nums[0]
                # Heuristic: choose high as max of middle price fields and low as min.
                c = nums[3] if len(nums) >= 4 else nums[-2]
                h = max(nums[:4])
                l = min(nums[:4])
                v = nums[4]
                qv = v * c if v and c else 0.0
            else:
                continue
            if c <= 0:
                continue
            # Normalize seconds to milliseconds when needed.
            open_time = int(t * 1000) if 0 < t < 10_000_000_000 else int(t)
            rows.append({"open_time": open_time, "open": o, "high": h, "low": l, "close": c, "volume": v, "quote_volume": qv, "close_time": open_time, "trades": 0, "taker_buy_base_volume": 0.0, "taker_buy_quote_volume": qv * 0.5})
        rows.sort(key=lambda x: x.get("open_time", 0))
        return rows
