from __future__ import annotations

"""
Gate.io USDT perpetual futures market-data client for the app layer.

This adapter mirrors the implementation in ``merged_imports.scalper_meme_plus_backend.clients.gate``
but exists under the ``app/data/clients`` namespace so that the Streamlit
dashboard and other high‑level helpers can access the same functionality.

Only a small subset of Gate.io's futures REST API is used: contracts
(instruments), tickers (market data), order books and candlesticks.  The
adapter never fabricates data; if a public endpoint fails or returns an
unexpected schema the scanner should treat that source as unavailable.
"""

from typing import Any

from .http import LiveHTTPClient, LiveDataError


class GateFuturesClient:
    def __init__(self, settle: str = "usdt") -> None:
        self.settle = settle.lower()
        self.http = LiveHTTPClient("https://fx-api.gateio.ws", "gate-futures")

    async def close(self) -> None:
        await self.http.close()

    async def ping(self) -> dict[str, Any]:
        try:
            data = await self.http.get_json(f"/api/v4/futures/{self.settle}/contracts", cache_ttl=60)
            return {"ok": True, "items": len(data) if isinstance(data, list) else 0}
        except Exception as exc:  # noqa: BLE001
            raise LiveDataError(str(exc))

    async def instruments(self) -> list[dict[str, Any]]:
        try:
            data = await self.http.get_json(f"/api/v4/futures/{self.settle}/contracts", cache_ttl=900)
        except Exception as exc:  # noqa: BLE001
            raise LiveDataError(f"gate contracts failed: {exc}")
        out: list[dict[str, Any]] = []
        if isinstance(data, list):
            for item in data:
                if isinstance(item, dict):
                    out.append(self._normalize_instrument(item))
        return out

    async def market_data(self) -> list[dict[str, Any]]:
        try:
            data = await self.http.get_json(f"/api/v4/futures/{self.settle}/tickers", cache_ttl=8)
        except Exception as exc:  # noqa: BLE001
            raise LiveDataError(f"gate tickers failed: {exc}")
        out: list[dict[str, Any]] = []
        if isinstance(data, list):
            for item in data:
                if isinstance(item, dict):
                    out.append(self._normalize_market(item))
        return out

    async def depth(self, symbol: str, limit: int = 50) -> dict[str, Any]:
        contract = symbol.upper()
        if "_" not in contract and len(contract) > 4:
            contract = f"{contract[:-4]}_{contract[-4:]}"
        try:
            data = await self.http.get_json(
                f"/api/v4/futures/{self.settle}/order_book",
                {"contract": contract, "limit": limit},
                cache_ttl=3,
            )
        except Exception as exc:  # noqa: BLE001
            raise LiveDataError(f"gate depth failed for {symbol}: {exc}")
        return self._normalize_depth(data)

    async def klines(self, symbol: str, interval: str = "5m", limit: int = 160) -> list[dict[str, Any]]:
        contract = symbol.upper()
        if "_" not in contract and len(contract) > 4:
            contract = f"{contract[:-4]}_{contract[-4:]}"
        try:
            raw = await self.http.get_json(
                f"/api/v4/futures/{self.settle}/candlesticks",
                {"contract": contract, "interval": interval, "limit": limit},
                cache_ttl=6,
            )
        except Exception as exc:  # noqa: BLE001
            raise LiveDataError(f"gate klines failed for {symbol}: {exc}")
        if not isinstance(raw, list):
            return []
        out: list[dict[str, Any]] = []
        for k in raw[-limit:]:
            if not isinstance(k, (list, tuple)) or len(k) < 6:
                continue
            t = self._to_int(k[0])
            volume = self._to_float(k[1])
            close = self._to_float(k[2])
            high = self._to_float(k[3])
            low = self._to_float(k[4])
            open_ = self._to_float(k[5])
            quote_volume = volume * close if volume and close else 0.0
            if t < 10_000_000_000:
                t *= 1000
            out.append(
                {
                    "open_time": t,
                    "open": open_,
                    "high": high,
                    "low": low,
                    "close": close,
                    "volume": volume,
                    "quote_volume": quote_volume,
                    "close_time": t,
                    "trades": 0,
                    "taker_buy_base_volume": 0.0,
                    "taker_buy_quote_volume": quote_volume * 0.5,
                }
            )
        return out

    # Helpers (copied from merged_imports version)

    def _first(self, data: dict[str, Any], keys: list[str], default: Any = None) -> Any:
        for k in keys:
            if k in data and data.get(k) not in (None, ""):
                return data.get(k)
        return default

    def _to_float(self, x: Any, default: float = 0.0) -> float:
        try:
            if x is None or x == "":
                return default
            return float(x)
        except (TypeError, ValueError):
            return default

    def _to_int(self, x: Any, default: int = 0) -> int:
        try:
            if x is None or x == "":
                return default
            return int(float(x))
        except (TypeError, ValueError):
            return default

    def _normalize_instrument(self, x: dict[str, Any]) -> dict[str, Any]:
        contract = str(self._first(x, ["name", "contract", "id", "symbol"], "")).upper()
        if not contract:
            return {}
        norm_symbol = contract.replace("_", "")
        base_asset = norm_symbol[:-4] if norm_symbol.endswith("USDT") else norm_symbol
        return {
            "symbol": norm_symbol,
            "raw_symbol": contract,
            "status": self._first(x, ["in_delisting", "status"], False) and "BREAK" or "TRADING",
            "quote_asset": "USDT",
            "base_asset": base_asset,
            "tag": None,
            "raw": x,
        }

    def _normalize_market(self, x: dict[str, Any]) -> dict[str, Any]:
        contract = str(self._first(x, ["contract", "name", "symbol"], "")).upper()
        if not contract:
            return {}
        symbol = contract.replace("_", "")
        price = self._to_float(self._first(x, ["last", "last_price", "close", "mark_price"], 0.0))
        mark = self._to_float(self._first(x, ["mark_price", "index_price"], price))
        high = self._to_float(self._first(x, ["high_24h", "high", "max_price"], price))
        low = self._to_float(self._first(x, ["low_24h", "low", "min_price"], price))
        vol_base = self._to_float(self._first(x, ["volume_24h", "volume", "turnover"], 0.0))
        vol_quote = self._to_float(self._first(x, ["volume_24h_quote", "quote_volume_24h", "quote_volume"], 0.0))
        if vol_quote <= 0 and vol_base > 0 and price > 0:
            vol_quote = vol_base * price
        change = self._to_float(self._first(x, ["change_percentage", "change_24h", "pct_change"], 0.0))
        if -1.0 < change < 1.0 and change != 0:
            change *= 100.0
        return {
            "symbol": symbol,
            "raw_symbol": contract,
            "lastPrice": price,
            "markPrice": mark,
            "highPrice": high,
            "lowPrice": low,
            "volume": vol_base,
            "quoteVolume": vol_quote,
            "priceChangePercent": change,
            "fundingRate": self._to_float(self._first(x, ["funding_rate", "funding_rate_indicative"], 0.0)),
            "openInterest": self._to_float(self._first(x, ["open_interest", "total_size"], 0.0)),
            "tag": None,
            "raw": x,
        }

    def _normalize_depth(self, data: dict[str, Any]) -> dict[str, Any]:
        def row_to_pair(row: Any) -> list[str]:
            if isinstance(row, (list, tuple)) and len(row) >= 2:
                return [str(row[0]), str(row[1])]
            if isinstance(row, dict):
                return [str(self._first(row, ["p", "price"], 0)), str(self._first(row, ["s", "size", "q", "amount"], 0))]
            return ["0", "0"]
        bids = data.get("bids") or data.get("buy") or []
        asks = data.get("asks") or data.get("sell") or []
        return {
            "bids": [row_to_pair(x) for x in bids],
            "asks": [row_to_pair(x) for x in asks],
            "lastUpdateId": self._to_int(data.get("t") or data.get("ts") or 0),
            "raw": data,
        }
