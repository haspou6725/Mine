from __future__ import annotations

import asyncio
import time
from typing import Any
import httpx

class LiveDataError(RuntimeError):
    pass

class LiveHTTPClient:
    def __init__(self, base_url: str, name: str, timeout: float = 8.0, user_agent: str = "CrashSignalStationLive/2.0") -> None:
        self.base_url = base_url.rstrip("/")
        self.name = name
        self.timeout = timeout
        self.user_agent = user_agent
        self._client: httpx.AsyncClient | None = None
        self._cache: dict[str, tuple[float, Any]] = {}

    async def start(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self.timeout, headers={"User-Agent": self.user_agent, "Accept": "application/json"})

    async def close(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def get_json(self, path: str, params: dict[str, Any] | None = None, cache_ttl: float = 0.0) -> Any:
        await self.start()
        assert self._client is not None
        clean_params = {k: v for k, v in (params or {}).items() if v is not None}
        key = f"{path}?{tuple(sorted(clean_params.items()))}"
        now = time.time()
        if cache_ttl > 0 and key in self._cache:
            ts, payload = self._cache[key]
            if now - ts < cache_ttl:
                return payload
        url = path if path.startswith("http") else self.base_url + path
        last_error: Exception | None = None
        for attempt in range(2):
            try:
                response = await self._client.get(url, params=clean_params)
                response.raise_for_status()
                payload = response.json()
                if cache_ttl > 0:
                    self._cache[key] = (time.time(), payload)
                return payload
            except Exception as exc:  # noqa: BLE001
                last_error = exc
                await asyncio.sleep(0.45 * (attempt + 1))
        err_text = repr(last_error) if last_error is not None else "unknown error"
        raise LiveDataError(f"{self.name} live request failed: {path} {clean_params} -> {err_text}")
