from __future__ import annotations
from typing import Any
from .http import LiveHTTPClient

class CoinGeckoClient:
    def __init__(self) -> None:
        self.http = LiveHTTPClient("https://api.coingecko.com/api/v3", "coingecko")

    async def close(self) -> None:
        await self.http.close()

    async def ping(self) -> dict[str, Any]:
        return await self.http.get_json("/ping", cache_ttl=15)

    async def trending(self) -> dict[str, Any]:
        return await self.http.get_json("/search/trending", cache_ttl=45)
