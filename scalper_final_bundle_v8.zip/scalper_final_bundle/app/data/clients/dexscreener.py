from __future__ import annotations
from typing import Any
from .http import LiveHTTPClient

class DexScreenerClient:
    def __init__(self) -> None:
        self.http = LiveHTTPClient("https://api.dexscreener.com", "dexscreener")

    async def close(self) -> None:
        await self.http.close()

    async def latest_profiles(self) -> list[dict[str, Any]]:
        data = await self.http.get_json("/token-profiles/latest/v1", cache_ttl=20)
        return data if isinstance(data, list) else []

    async def latest_boosts(self) -> list[dict[str, Any]]:
        data = await self.http.get_json("/token-boosts/latest/v1", cache_ttl=20)
        return data if isinstance(data, list) else []

    async def top_boosts(self) -> list[dict[str, Any]]:
        data = await self.http.get_json("/token-boosts/top/v1", cache_ttl=30)
        return data if isinstance(data, list) else []

    async def community_takeovers(self) -> list[dict[str, Any]]:
        data = await self.http.get_json("/community-takeovers/latest/v1", cache_ttl=60)
        return data if isinstance(data, list) else []

    async def token_pairs(self, chain_id: str, token_address: str) -> list[dict[str, Any]]:
        data = await self.http.get_json(f"/token-pairs/v1/{chain_id}/{token_address}", cache_ttl=30)
        return data if isinstance(data, list) else []
