from __future__ import annotations
from typing import Any
from app.data.clients.http import LiveHTTPClient

class BinanceFuturesClient:
    def __init__(self) -> None:
        self.http = LiveHTTPClient("https://fapi.binance.com", "binance-futures")

    async def close(self) -> None:
        await self.http.close()

    async def ping(self) -> dict[str, Any]:
        data = await self.http.get_json("/fapi/v1/time", cache_ttl=0)
        return {"serverTime": data.get("serverTime")}

    async def exchange_info(self) -> dict[str, Any]:
        return await self.http.get_json("/fapi/v1/exchangeInfo", cache_ttl=1800)

    async def ticker_24h(self) -> list[dict[str, Any]]:
        data = await self.http.get_json("/fapi/v1/ticker/24hr", cache_ttl=8)
        return data if isinstance(data, list) else [data]

    async def premium_index(self) -> list[dict[str, Any]]:
        data = await self.http.get_json("/fapi/v1/premiumIndex", cache_ttl=8)
        return data if isinstance(data, list) else [data]

    async def klines(self, symbol: str, interval: str, limit: int) -> list[dict[str, Any]]:
        raw = await self.http.get_json("/fapi/v1/klines", {"symbol": symbol, "interval": interval, "limit": limit}, cache_ttl=6)
        out: list[dict[str, Any]] = []
        for k in raw:
            out.append({
                "open_time": int(k[0]),
                "open": float(k[1]),
                "high": float(k[2]),
                "low": float(k[3]),
                "close": float(k[4]),
                "volume": float(k[5]),
                "close_time": int(k[6]),
                "quote_volume": float(k[7]),
                "trades": int(k[8]),
                "taker_buy_base_volume": float(k[9]),
                "taker_buy_quote_volume": float(k[10]),
            })
        return out

    async def depth(self, symbol: str, limit: int = 100) -> dict[str, Any]:
        return await self.http.get_json("/fapi/v1/depth", {"symbol": symbol, "limit": limit}, cache_ttl=3)

    async def open_interest_hist(self, symbol: str, period: str = "5m", limit: int = 12) -> list[dict[str, Any]]:
        data = await self.http.get_json("/futures/data/openInterestHist", {"symbol": symbol, "period": period, "limit": limit}, cache_ttl=25)
        return data if isinstance(data, list) else []

    async def taker_buy_sell_volume(self, symbol: str, period: str = "5m", limit: int = 12) -> list[dict[str, Any]]:
        data = await self.http.get_json("/futures/data/takerlongshortRatio", {"symbol": symbol, "period": period, "limit": limit}, cache_ttl=25)
        return data if isinstance(data, list) else []
