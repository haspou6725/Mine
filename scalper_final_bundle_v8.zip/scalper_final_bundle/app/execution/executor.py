"""
Execution module: PortfolioSimulator and LiveExecutor placeholder.
- PortfolioSimulator simulates market orders, applies slippage & commission, and tracks cash/positions.
- LiveExecutor is a placeholder that would call Binance API using provided keys (NOT enabling live orders here).
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Any, List

@dataclass
class Fill:
    side: str
    price: float
    qty: float
    notional: float
    fee: float
    time: Any = None


@dataclass
class PortfolioSimulator:
    cash: float = 1000.0
    positions: Dict[str, float] = field(default_factory=dict)  # symbol -> base qty
    commission: float = 0.0004
    slippage: float = 0.0005
    history: List[Dict[str, Any]] = field(default_factory=list)

    def deposit(self, amount: float):
        self.cash += amount

    def get_position_notional(self, symbol: str, price: float) -> float:
        qty = self.positions.get(symbol, 0.0)
        return qty * price

    def place_market_order(self, symbol: str, side: str, notional: float, price: float) -> Fill:
        """Place a market order simulated at given price with slippage and commission.
        side: 'buy' or 'sell'
        notional: USDT notional to trade (for buy) or notional to receive (for sell)
        price: market price used as base for slippage
        Returns a Fill object and updates portfolio state.
        """
        # apply slippage: buys get worse price, sells get worse price
        if side.lower() == 'buy':
            fill_price = price * (1 + self.slippage)
            qty = notional / fill_price
            fee = notional * self.commission
            # require cash
            total_cost = notional + fee
            if total_cost > self.cash + 1e-12:
                raise ValueError('Insufficient cash for buy')
            self.cash -= (notional + fee)
            self.positions[symbol] = self.positions.get(symbol, 0.0) + qty
        elif side.lower() == 'sell':
            fill_price = price * (1 - self.slippage)
            qty = notional / fill_price
            held = self.positions.get(symbol, 0.0)
            if qty > held + 1e-12:
                # if not enough base asset, sell what we have
                qty = held
                notional = qty * fill_price
            fee = notional * self.commission
            self.positions[symbol] = max(0.0, held - qty)
            self.cash += notional - fee
        else:
            raise ValueError('side must be buy or sell')

        fill = Fill(side=side, price=fill_price, qty=qty, notional=notional, fee=fee)
        self.history.append({'symbol': symbol, 'fill': fill})
        return fill


class LiveExecutor:
    """Disabled live-execution guard.

    The project is educational/analytical only. This class intentionally does
    not accept credentials, does not open signed exchange sessions and does not
    expose any real order route. Keep all trading experiments inside
    PortfolioSimulator/backtests.
    """
    enabled: bool = False

    def __init__(self, *args: object, **kwargs: object) -> None:
        if args or kwargs:
            raise RuntimeError(
                "Live execution is disabled. Do not pass credentials or exchange options; "
                "use PortfolioSimulator for simulation only."
            )

    def place_order(self, symbol: str, side: str, quantity: float, price: float = None):
        raise NotImplementedError('Live execution is disabled. Use PortfolioSimulator for simulation.')
