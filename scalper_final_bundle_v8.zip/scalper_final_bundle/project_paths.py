from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent

SIGNALS_DIR = PROJECT_ROOT / "signals"
REPORTS_DIR = PROJECT_ROOT / "reports"
BACKTESTS_DIR = PROJECT_ROOT / "backtests_detailed"

SCAN_RESULTS = PROJECT_ROOT / "scan_results.json"
SIGNALS_MASTER = SIGNALS_DIR / "scan_results_master.json"
RISK_SUMMARY = REPORTS_DIR / "risk_metrics_summary.json"
RISK_SUMMARY_INMEMORY = REPORTS_DIR / "risk_metrics_summary_inmemory.json"
PORTFOLIO_SNAPSHOT = REPORTS_DIR / "portfolio_simulation.json"

BACKTEST_BATCH = PROJECT_ROOT / "backtest_batch.json"
BACKTEST_RESULTS = PROJECT_ROOT / "backtest_results.json"
BACKTEST_METRICS_QUICK = PROJECT_ROOT / "backtest_metrics_quick.json"
BACKTEST_BESTPARAMS_TOP50 = PROJECT_ROOT / "backtest_bestparams_top50.json"
BACKTESTS_DETAILED_SUMMARY = PROJECT_ROOT / "backtests_detailed_summary.json"
FEATURE_HEAD = PROJECT_ROOT / "feature_head.json"
TUNING_RESULTS = PROJECT_ROOT / "tuning_results.json"
TUNING_RESULTS_WIDE = PROJECT_ROOT / "tuning_results_wide.json"
TUNING_RESULTS_QUICK_TOP10 = PROJECT_ROOT / "tuning_results_quick_top10.json"
