import pandas as pd

from app.backtest.simple_backtester import backtest


def test_flat_long_does_not_create_fake_equity():
    df = pd.DataFrame([
        {"open_time": 0, "open": 100.0, "signal": 1},
        {"open_time": 60, "open": 100.0, "signal": 0},
        {"open_time": 120, "open": 100.0, "signal": 0},
    ])
    res = backtest(df, initial_capital=1000.0, leverage=1.0, position_size_pct=0.1)
    assert res["final_equity"] < 1000.0
    assert res["final_equity"] > 999.0
    assert res["metrics"]["accounting_model"] == "linear_futures_cash_plus_unrealized_pnl"


def test_short_position_can_profit_when_price_falls():
    df = pd.DataFrame([
        {"open_time": 0, "open": 100.0, "signal": -1},
        {"open_time": 60, "open": 100.0, "signal": 0},
        {"open_time": 120, "open": 90.0, "signal": 0},
    ])
    res = backtest(df, initial_capital=1000.0, leverage=1.0, position_size_pct=0.1, profit_target=0.05)
    assert any(t.get("action") == "EXIT" and t.get("exit_reason") == "take_profit" for t in res["trades"])
    assert res["final_equity"] > 1000.0
