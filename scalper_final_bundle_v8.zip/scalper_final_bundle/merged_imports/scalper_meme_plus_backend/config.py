from __future__ import annotations

import json
from pathlib import Path
from pydantic import ValidationError
from .models import Settings

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = PROJECT_ROOT / "data"
CONFIG_PATH = DATA_DIR / "settings.json"
READY_CONFIG_PATH = DATA_DIR / "settings.ready.json"

def ensure_dirs() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)

def load_settings() -> Settings:
    ensure_dirs()
    if CONFIG_PATH.exists():
        try:
            return Settings(**json.loads(CONFIG_PATH.read_text(encoding="utf-8")))
        except (json.JSONDecodeError, ValidationError, OSError):
            pass

    if READY_CONFIG_PATH.exists():
        try:
            settings = Settings(**json.loads(READY_CONFIG_PATH.read_text(encoding="utf-8")))
            save_settings(settings)
            return settings
        except (json.JSONDecodeError, ValidationError, OSError):
            pass

    settings = Settings()
    save_settings(settings)
    return settings

def save_settings(settings: Settings) -> None:
    ensure_dirs()
    CONFIG_PATH.write_text(settings.model_dump_json(indent=2), encoding="utf-8")
