from __future__ import annotations

import asyncio
import json
import time
from typing import Any
import httpx

class LiveDataError(RuntimeError):
    pass

class LiveHTTPClient:
    def __init__(self, base_url: str, name: str, timeout: float = 8.0, user_agent: str = "CrashSignalStationLive/2.0", max_cache_items: int = 512) -> None:
        self.base_url = base_url.rstrip("/")
        self.name = name
        self.timeout = timeout
        self.user_agent = user_agent
        self.max_cache_items = max_cache_items
        self._client: httpx.AsyncClient | None = None
        self._cache: dict[str, tuple[float, Any]] = {}

    async def start(self) -> None:
        if self._client is None:
            limits = httpx.Limits(max_connections=60, max_keepalive_connections=20, keepalive_expiry=20.0)
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(self.timeout, connect=min(self.timeout, 5.0)),
                limits=limits,
                headers={"User-Agent": self.user_agent, "Accept": "application/json"},
                follow_redirects=False,
            )

    def _remember_cache(self, key: str, payload: Any) -> None:
        if len(self._cache) >= self.max_cache_items:
            oldest = min(self._cache.items(), key=lambda item: item[1][0])[0]
            self._cache.pop(oldest, None)
        self._cache[key] = (time.time(), payload)

    async def close(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def get_json(self, path: str, params: dict[str, Any] | None = None, cache_ttl: float = 0.0) -> Any:
        await self.start()
        assert self._client is not None
        clean_params = {k: v for k, v in (params or {}).items() if v is not None}
        key = f"{path}?{tuple(sorted(clean_params.items()))}"
        now = time.time()
        if cache_ttl > 0 and key in self._cache:
            ts, payload = self._cache[key]
            if now - ts < cache_ttl:
                return payload
        url = path if path.startswith("http") else self.base_url + path
        last_error: Exception | None = None
        for attempt in range(3):
            try:
                response = await self._client.get(url, params=clean_params)
                if response.status_code == 429:
                    retry_after = response.headers.get("Retry-After")
                    wait = float(retry_after) if retry_after and retry_after.replace(".", "", 1).isdigit() else 0.75 * (attempt + 1)
                    await asyncio.sleep(min(wait, 3.0))
                    response.raise_for_status()
                response.raise_for_status()
                try:
                    payload = response.json()
                except json.JSONDecodeError as exc:
                    raise LiveDataError(f"{self.name} returned non-JSON response for {path}") from exc
                if cache_ttl > 0:
                    self._remember_cache(key, payload)
                return payload
            except LiveDataError:
                raise
            except Exception as exc:  # noqa: BLE001
                last_error = exc
                await asyncio.sleep(0.45 * (attempt + 1))
        err_text = repr(last_error) if last_error is not None else "unknown error"
        raise LiveDataError(f"{self.name} live request failed: {path} {clean_params} -> {err_text}")
