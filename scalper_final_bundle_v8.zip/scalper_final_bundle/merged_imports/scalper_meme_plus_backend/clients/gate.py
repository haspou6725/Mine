from __future__ import annotations

"""
Gate.io USDT perpetual futures market-data client.

This client exposes only public endpoints and intentionally does not require an
API key or provide any order execution capabilities. It focuses on the small
subset of endpoints needed by the scanner (contract metadata, tickers, order
book snapshots and candlesticks).  If a request fails or the remote schema
changes, the caller should treat the data as missing rather than guessing.

The API endpoints are documented at:
  https://www.gate.io/docs/developers/apiv4/en/#futures

We avoid tight coupling to a specific response shape. Whenever possible we
inspect multiple candidate fields to extract the value we need. See the
normalization helpers below for details.
"""

from typing import Any

from .http import LiveHTTPClient, LiveDataError


class GateFuturesClient:
    """Public Gate.io futures client for USDT-settled perpetual contracts.

    Gate.io exposes a unified futures API under the ``fx-api.gateio.ws`` domain.
    Each endpoint takes the settlement currency (``usdt``) as a path segment
    followed by the resource name.  See the official docs for full details.
    This class only implements read‑only endpoints required for building the
    universe and computing metrics: contracts (metadata), tickers (24h market
    statistics), order books and candlesticks.  All methods return normalized
    Python dictionaries or lists.  No attempt is made to fabricate missing
    values; if a field is unavailable the default (e.g. ``None`` or ``0``) is
    used instead.  When a network or schema error occurs a ``LiveDataError``
    is raised so the scanner can mark the source as unhealthy.
    """

    def __init__(self, settle: str = "usdt") -> None:
        self.settle = settle.lower()
        # Use the futures domain rather than spot to access perpetual contracts.
        self.http = LiveHTTPClient("https://fx-api.gateio.ws", "gate-futures")

    async def close(self) -> None:
        await self.http.close()

    async def ping(self) -> dict[str, Any]:
        """Lightweight ping to verify that the API is reachable.

        Gate.io's futures API does not expose a dedicated ping endpoint.  We
        therefore call the ``contracts`` endpoint with a very short cache TTL.
        If the response is valid the request succeeded.  Only a summary is
        returned so the caller can display latency and OK/FAIL status.
        """
        try:
            data = await self.http.get_json(f"/api/v4/futures/{self.settle}/contracts", cache_ttl=60)
            # Return a truncated summary for diagnostics (number of items).
            return {"ok": True, "items": len(data) if isinstance(data, list) else 0}
        except Exception as exc:  # noqa: BLE001
            raise LiveDataError(str(exc))

    async def instruments(self) -> list[dict[str, Any]]:
        """Return metadata about all USDT perpetual contracts.

        Each item in the returned list includes a normalized symbol, the raw
        contract code, status and base/quote asset.  Only contracts that
        reference USDT as the settlement currency are returned.  Unknown or
        incomplete entries are silently skipped.
        """
        try:
            data = await self.http.get_json(f"/api/v4/futures/{self.settle}/contracts", cache_ttl=900)
        except Exception as exc:  # noqa: BLE001
            raise LiveDataError(f"gate contracts failed: {exc}")
        rows: list[dict[str, Any]] = []
        if not isinstance(data, list):
            return rows
        for item in data:
            if not isinstance(item, dict):
                continue
            rows.append(self._normalize_instrument(item))
        return rows

    async def market_data(self) -> list[dict[str, Any]]:
        """Return 24h ticker statistics for all USDT perpetual contracts.

        The endpoint provides last price, mark price, high/low over the last
        24 hours, volume and funding rate.  The returned list contains one
        entry per contract.  Unknown fields are defaulted to zero or None.
        """
        try:
            data = await self.http.get_json(f"/api/v4/futures/{self.settle}/tickers", cache_ttl=8)
        except Exception as exc:  # noqa: BLE001
            raise LiveDataError(f"gate tickers failed: {exc}")
        rows: list[dict[str, Any]] = []
        if not isinstance(data, list):
            return rows
        for item in data:
            if not isinstance(item, dict):
                continue
            rows.append(self._normalize_market(item))
        return rows

    async def depth(self, symbol: str, limit: int = 50) -> dict[str, Any]:
        """Return the current order book for a given contract.

        Gate.io requires the contract code rather than the normalized symbol.
        We therefore accept either a raw contract code (e.g. ``BTC_USDT``) or a
        Binance/LBank‑style symbol (e.g. ``BTCUSDT``) and convert it by
        inserting an underscore before the last four characters.  Only the top
        ``limit`` levels are returned.  The ``asks`` and ``bids`` lists contain
        price/quantity pairs as strings to preserve precision.  If the depth
        cannot be fetched a ``LiveDataError`` is raised.
        """
        contract = symbol.upper()
        # Gate uses underscore separators.  If none present, insert one before the last 4 chars.
        if "_" not in contract and len(contract) > 4:
            contract = f"{contract[:-4]}_{contract[-4:]}"
        try:
            data = await self.http.get_json(
                f"/api/v4/futures/{self.settle}/order_book",
                {"contract": contract, "limit": limit},
                cache_ttl=3,
            )
        except Exception as exc:  # noqa: BLE001
            raise LiveDataError(f"gate depth failed for {symbol}: {exc}")
        return self._normalize_depth(data)

    async def klines(self, symbol: str, interval: str = "5m", limit: int = 160) -> list[dict[str, Any]]:
        """Return recent candlesticks for a contract.

        The ``interval`` can be one of ``1m``, ``5m``, ``15m`` or ``1h``.  The
        request always sets ``limit`` to the desired number of rows.  Gate.io
        returns an array of lists: ``[timestamp, volume, close, high, low, open]``
        where the timestamp is in milliseconds.  We normalize these to the
        unified kline format used across the project.  If the endpoint fails
        or returns too few rows an empty list is returned.
        """
        contract = symbol.upper()
        if "_" not in contract and len(contract) > 4:
            contract = f"{contract[:-4]}_{contract[-4:]}"
        try:
            raw = await self.http.get_json(
                f"/api/v4/futures/{self.settle}/candlesticks",
                {"contract": contract, "interval": interval, "limit": limit},
                cache_ttl=6,
            )
        except Exception as exc:  # noqa: BLE001
            raise LiveDataError(f"gate klines failed for {symbol}: {exc}")
        # Gate returns a list of lists; each row should have at least 6 items.
        if not isinstance(raw, list):
            return []
        out: list[dict[str, Any]] = []
        for k in raw[-limit:]:
            if not isinstance(k, (list, tuple)) or len(k) < 6:
                continue
            # Format: [timestamp, volume, close, high, low, open]
            t = self._to_int(k[0])
            volume = self._to_float(k[1])
            close = self._to_float(k[2])
            high = self._to_float(k[3])
            low = self._to_float(k[4])
            open_ = self._to_float(k[5])
            quote_volume = volume * close if volume and close else 0.0
            # Gate uses milliseconds; if timestamp appears to be seconds scale convert to ms.
            if t < 10_000_000_000:
                t *= 1000
            out.append(
                {
                    "open_time": t,
                    "open": open_,
                    "high": high,
                    "low": low,
                    "close": close,
                    "volume": volume,
                    "quote_volume": quote_volume,
                    "close_time": t,
                    "trades": 0,
                    "taker_buy_base_volume": 0.0,
                    "taker_buy_quote_volume": quote_volume * 0.5,
                }
            )
        return out

    # Internal helpers -----------------------------------------------------

    def _first(self, data: dict[str, Any], keys: list[str], default: Any = None) -> Any:
        """Return the first non‑null value from ``data`` among ``keys``.
        """
        for k in keys:
            if k in data and data.get(k) not in (None, ""):
                return data.get(k)
        return default

    def _to_float(self, x: Any, default: float = 0.0) -> float:
        try:
            if x is None or x == "":
                return default
            return float(x)
        except (TypeError, ValueError):
            return default

    def _to_int(self, x: Any, default: int = 0) -> int:
        try:
            if x is None or x == "":
                return default
            return int(float(x))
        except (TypeError, ValueError):
            return default

    def _normalize_instrument(self, x: dict[str, Any]) -> dict[str, Any]:
        contract = str(self._first(x, ["name", "contract", "id", "symbol"], "")).upper()
        if not contract:
            return {}
        # Normalized symbol removes underscore; raw_symbol retains it.
        norm_symbol = contract.replace("_", "")
        base_asset = norm_symbol[:-4] if norm_symbol.endswith("USDT") else norm_symbol
        return {
            "symbol": norm_symbol,
            "raw_symbol": contract,
            "status": self._first(x, ["in_delisting", "status"], False) and "BREAK" or "TRADING",
            "quote_asset": "USDT",
            "base_asset": base_asset,
            "tag": None,
            "raw": x,
        }

    def _normalize_market(self, x: dict[str, Any]) -> dict[str, Any]:
        contract = str(self._first(x, ["contract", "name", "symbol"], "")).upper()
        if not contract:
            return {}
        symbol = contract.replace("_", "")
        price = self._to_float(self._first(x, ["last", "last_price", "close", "mark_price"], 0.0))
        mark = self._to_float(self._first(x, ["mark_price", "index_price"], price))
        high = self._to_float(self._first(x, ["high_24h", "high", "max_price"], price))
        low = self._to_float(self._first(x, ["low_24h", "low", "min_price"], price))
        vol_base = self._to_float(self._first(x, ["volume_24h", "volume", "turnover"], 0.0))
        vol_quote = self._to_float(self._first(x, ["volume_24h_quote", "quote_volume_24h", "quote_volume"], 0.0))
        if vol_quote <= 0 and vol_base > 0 and price > 0:
            vol_quote = vol_base * price
        change = self._to_float(self._first(x, ["change_percentage", "change_24h", "pct_change"], 0.0))
        # Gate returns percentages like "0.12" for 0.12%; convert to percent if < 1.
        if -1.0 < change < 1.0 and change != 0:
            change *= 100.0
        return {
            "symbol": symbol,
            "raw_symbol": contract,
            "lastPrice": price,
            "markPrice": mark,
            "highPrice": high,
            "lowPrice": low,
            "volume": vol_base,
            "quoteVolume": vol_quote,
            "priceChangePercent": change,
            "fundingRate": self._to_float(self._first(x, ["funding_rate", "funding_rate_indicative"], 0.0)),
            "openInterest": self._to_float(self._first(x, ["open_interest", "total_size"], 0.0)),
            "tag": None,
            "raw": x,
        }

    def _normalize_depth(self, data: dict[str, Any]) -> dict[str, Any]:
        def row_to_pair(row: Any) -> list[str]:
            # Depth entries are lists like [price, size].  Convert both to strings.
            if isinstance(row, (list, tuple)) and len(row) >= 2:
                return [str(row[0]), str(row[1])]
            if isinstance(row, dict):
                return [str(self._first(row, ["p", "price"], 0)), str(self._first(row, ["s", "size", "q", "amount"], 0))]
            return ["0", "0"]
        bids = data.get("bids") or data.get("buy") or []
        asks = data.get("asks") or data.get("sell") or []
        return {
            "bids": [row_to_pair(x) for x in bids],
            "asks": [row_to_pair(x) for x in asks],
            "lastUpdateId": self._to_int(data.get("t") or data.get("ts") or 0),
            "raw": data,
        }
