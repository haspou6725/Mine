from __future__ import annotations

from typing import Any, Literal
from pydantic import BaseModel, Field

Side = Literal["SHORT", "LONG", "BOTH"]

class Settings(BaseModel):
    # Universe filters
    max_price: float = Field(1.0, ge=0.00000001)
    min_quote_volume: float = Field(650_000.0, ge=0)
    max_symbols: int = Field(220, ge=5, le=500)
    min_abs_price_change_pct: float = Field(2.0, ge=0, le=100)
    min_24h_range_pct: float = Field(3.0, ge=0, le=300)
    rate_limit_safe_mode: bool = True
    target_request_weight_per_min: int = Field(1950, ge=500, le=2300)
    depth_limit: int = Field(20, ge=5, le=100)
    kline_limit_1m: int = Field(99, ge=40, le=99)
    kline_limit_5m: int = Field(99, ge=60, le=99)
    kline_limit_15m: int = Field(99, ge=60, le=99)
    kline_limit_1h: int = Field(80, ge=40, le=99)
    include_low_liquidity: bool = False
    include_binance_futures: bool = True
    include_lbank_contract: bool = False
    # Whether to include Gate.io USDT perpetual contracts as a fallback/augmentation
    include_gate_contract: bool = False
    lbank_min_quote_volume: float = Field(250_000.0, ge=0)
    lbank_max_spread_pct: float = Field(0.75, ge=0.01, le=10)
    # Gate.io specific universe filters.  These thresholds control the minimum
    # quote volume, maximum spread and minimum depth (USD) gate for Gate.io
    # contracts.  They behave identically to the LBank counterparts but are
    # separate to allow fine‑tuning per venue.
    gate_min_quote_volume: float = Field(250_000.0, ge=0)
    gate_max_spread_pct: float = Field(0.75, ge=0.01, le=10)
    gate_min_depth_1pct_usd: float = Field(12_000.0, ge=0)

    # Optional context and meme early-warning layer
    dex_context_enabled: bool = True
    coingecko_context_enabled: bool = True
    early_warning_enabled: bool = True
    meme_mode: bool = True
    early_watch_threshold: float = Field(50.0, ge=1, le=100)
    early_confirm_threshold: float = Field(66.0, ge=1, le=100)
    trap_threshold: float = Field(68.0, ge=1, le=100)
    early_volume_spike: float = Field(1.25, ge=0.5, le=20)
    early_confirmed_to_signals: bool = True

    # Scalper execution gates
    max_spread_pct: float = Field(0.28, ge=0.01, le=5)
    min_depth_1pct_usd: float = Field(45_000.0, ge=0)
    lbank_min_depth_1pct_usd: float = Field(12_000.0, ge=0)
    min_volume_spike_for_trigger: float = Field(1.45, ge=0.5, le=20)
    max_data_age_sec: int = Field(900, ge=60, le=7200)

    # Signal engine
    prefer_side: Side = "BOTH"
    score_threshold: float = Field(72.0, ge=1, le=100)
    max_long_chase_1h_pct: float = Field(5.5, ge=0.5, le=50)
    max_short_chase_1h_pct: float = Field(8.5, ge=0.5, le=50)
    max_long_rsi_5m: float = Field(74.0, ge=40, le=100)
    min_short_rsi_5m: float = Field(26.0, ge=0, le=60)
    max_stop_distance_pct: float = Field(6.0, ge=0.1, le=30)
    cooldown_minutes: int = Field(20, ge=0, le=360)
    scan_interval_sec: int = Field(25, ge=20, le=3600)
    concurrent_requests: int = Field(10, ge=1, le=12)
    market_regime_filter: bool = True


    # Binance microstructure layer
    binance_microstructure_enabled: bool = True
    use_usds_futures_universe: bool = True
    use_dynamic_spread_threshold: bool = True
    use_dynamic_depth_threshold: bool = True
    use_dynamic_volume_filter: bool = True
    use_percentile_thresholds: bool = True
    use_open_interest_score: bool = True
    use_open_interest_delta: bool = True
    use_funding_score: bool = True
    use_mark_index_premium: bool = True
    use_taker_flow_score: bool = True
    min_taker_buy_ratio_for_long: float = Field(0.55, ge=0.0, le=1.0)
    max_taker_buy_ratio_for_short: float = Field(0.45, ge=0.0, le=1.0)
    max_mark_index_premium_pct: float = Field(0.12, ge=0.0, le=5.0)
    crowded_funding_penalty_enabled: bool = True
    crowded_funding_abs_threshold: float = Field(0.00025, ge=0.0, le=0.01)
    binance_weight_budget_per_min: int = Field(1800, ge=500, le=2300)


    # Multi-source confidence/explainability layer (TickerSage/Kraken/RealOpen/Alpaca/Figma inspired)
    use_chart_confirmation: bool = True
    chart_confirmation_min_score: float = Field(55.0, ge=0, le=100)
    chart_min_volume_spike: float = Field(1.35, ge=0.5, le=20)
    chart_bollinger_overextension_rsi: float = Field(78.0, ge=50, le=100)
    chart_short_overextension_rsi: float = Field(22.0, ge=0, le=50)
    use_kraken_news_context: bool = True
    news_risk_penalty_enabled: bool = True
    positive_narrative_bonus: float = Field(4.0, ge=0, le=20)
    negative_news_penalty: float = Field(8.0, ge=0, le=30)
    security_issue_hard_block: bool = True
    listing_or_etf_bonus: float = Field(5.0, ge=0, le=20)
    use_liquidity_tier: bool = True
    major_asset_stability_bonus: float = Field(3.0, ge=0, le=20)
    unknown_microcap_risk_penalty: float = Field(6.0, ge=0, le=30)
    max_trade_vs_daily_volume_pct: float = Field(0.10, ge=0.001, le=5.0)
    use_alpaca_cross_feed_validation: bool = True
    max_cross_feed_price_deviation_pct: float = Field(0.20, ge=0.01, le=10.0)
    alpaca_spread_warning_pct: float = Field(0.25, ge=0.01, le=10.0)
    zero_volume_bar_warning: bool = True
    cross_feed_disagreement_penalty: float = Field(7.0, ge=0, le=30)
    ui_signal_explainability: bool = True
    ui_why_no_signal_panel: bool = True
    ui_risk_badges: bool = True
    ui_source_health_cards: bool = True
    ui_model_confidence_meter: bool = True

    # Financial Datasets historical/regime/backtest layer
    financial_datasets_enabled: bool = True
    financial_datasets_cache_enabled: bool = True
    financial_datasets_regime_enabled: bool = True
    financial_datasets_benchmark_enabled: bool = True
    financial_datasets_walk_forward_enabled: bool = True
    financial_datasets_out_of_sample_ratio: float = Field(0.30, ge=0.05, le=0.80)
    financial_datasets_min_backtest_trades: int = Field(30, ge=1, le=10000)
    financial_datasets_min_profit_factor: float = Field(1.20, ge=0.1, le=10)
    financial_datasets_max_allowed_drawdown_pct: float = Field(12.0, ge=0, le=100)

    # BTC/CryptoAudit-inspired market context guardrails
    btc_overbought_rsi: float = Field(70.0, ge=50, le=95)
    btc_overbought_long_penalty: float = Field(6.0, ge=0, le=30)
    btc_overbought_required_volume_spike: float = Field(1.70, ge=0.5, le=20)
    btc_low_volume_ratio_threshold: float = Field(0.80, ge=0.1, le=5)
    btc_macd_bearish_long_penalty: float = Field(4.0, ge=0, le=30)
    hard_block_long_if_1h_move_above: float = Field(12.0, ge=1, le=100)
    anti_chase_penalty: float = Field(8.0, ge=0, le=30)

    # Hard gates based on the research report
    strict_live_data: bool = True
    require_depth: bool = True
    require_open_interest: bool = False
    require_taker_flow: bool = False
    require_funding: bool = False
    allow_lbank_partial_derivatives: bool = True

    # Risk planner, no order execution
    capital_usdt: float = Field(1000.0, ge=1)
    risk_per_trade_pct: float = Field(0.5, ge=0.05, le=5)
    max_total_open_risk_pct: float = Field(2.5, ge=0.1, le=20)
    leverage: float = Field(3, ge=1, le=20)

class SourceStatus(BaseModel):
    source: str
    ok: bool
    latency_ms: int | None = None
    checked_at: str
    error: str | None = None
    details: dict[str, Any] = Field(default_factory=dict)

class ScanStatus(BaseModel):
    running: bool = False
    loop_enabled: bool = False
    started_at: str | None = None
    finished_at: str | None = None
    progress_done: int = 0
    progress_total: int = 0
    scanned: int = 0
    produced_signals: int = 0
    skipped_symbols: int = 0
    last_scan_seconds: float | None = None
    message: str = "idle"
    last_error: str | None = None

class Signal(BaseModel):
    id: int | None = None
    ts: str
    symbol: str
    exchange: str = "binance-futures"
    side: Literal["SHORT", "LONG"]
    score: float
    grade: str
    price: float
    quote_volume_24h: float
    price_change_24h: float
    funding_rate: float | None = None
    oi_change_pct: float | None = None
    taker_sell_pressure: float | None = None
    volume_spike: float | None = None
    spread_pct: float | None = None
    reasons: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    hard_gates: dict[str, bool] = Field(default_factory=dict)
    plan: dict[str, Any] = Field(default_factory=dict)
    metrics: dict[str, Any] = Field(default_factory=dict)
    sources: dict[str, Any] = Field(default_factory=dict)
    channel_text: str | None = None

class DexItem(BaseModel):
    source: str
    chain_id: str
    token_address: str
    name: str | None = None
    symbol: str | None = None
    url: str | None = None
    price_usd: float | None = None
    liquidity_usd: float | None = None
    volume_24h: float | None = None
    price_change_24h: float | None = None
    score: float = 0.0
    reason: str = ""
    live_fetched_at: str
