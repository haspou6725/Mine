from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from threading import RLock
from typing import Any
from ..config import DATA_DIR, ensure_dirs

class Storage:
    def __init__(self, path: Path | None = None) -> None:
        ensure_dirs()
        self.path = path or DATA_DIR / "live_signals.db"
        self.lock = RLock()
        self._init()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=15.0)
        conn.row_factory = sqlite3.Row
        return conn

    def _init(self) -> None:
        with self.lock, self._connect() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.execute("PRAGMA synchronous=NORMAL")
            db.execute("""
                CREATE TABLE IF NOT EXISTS signals(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    side TEXT NOT NULL,
                    score REAL NOT NULL,
                    grade TEXT NOT NULL,
                    price REAL NOT NULL,
                    quote_volume_24h REAL,
                    price_change_24h REAL,
                    funding_rate REAL,
                    oi_change_pct REAL,
                    taker_sell_pressure REAL,
                    volume_spike REAL,
                    spread_pct REAL,
                    payload_json TEXT NOT NULL
                )
            """)
            db.execute("""
                CREATE TABLE IF NOT EXISTS snapshots(
                    symbol TEXT PRIMARY KEY,
                    ts TEXT NOT NULL,
                    price REAL NOT NULL,
                    short_score REAL NOT NULL,
                    long_score REAL NOT NULL,
                    payload_json TEXT NOT NULL
                )
            """)
            db.execute("""
                CREATE TABLE IF NOT EXISTS skipped(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    details_json TEXT NOT NULL
                )
            """)
            db.execute("""
                CREATE TABLE IF NOT EXISTS runs(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    started_at TEXT NOT NULL,
                    finished_at TEXT NOT NULL,
                    scanned INTEGER NOT NULL,
                    alerts INTEGER NOT NULL,
                    skipped INTEGER NOT NULL,
                    seconds REAL NOT NULL,
                    status TEXT NOT NULL,
                    error TEXT
                )
            """)
            db.execute("CREATE INDEX IF NOT EXISTS idx_signals_ts ON signals(ts)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_signals_symbol_side ON signals(symbol, side)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_signals_score ON signals(score)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_skipped_ts ON skipped(ts)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_runs_started_at ON runs(started_at)")
            db.commit()

    def insert_signal(self, signal: dict[str, Any]) -> int:
        with self.lock, self._connect() as db:
            cur = db.execute("""
                INSERT INTO signals(ts, symbol, side, score, grade, price, quote_volume_24h, price_change_24h,
                    funding_rate, oi_change_pct, taker_sell_pressure, volume_spike, spread_pct, payload_json)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                signal["ts"], signal["symbol"], signal["side"], signal["score"], signal["grade"], signal["price"],
                signal.get("quote_volume_24h"), signal.get("price_change_24h"), signal.get("funding_rate"),
                signal.get("oi_change_pct"), signal.get("taker_sell_pressure"), signal.get("volume_spike"), signal.get("spread_pct"),
                json.dumps(signal, ensure_ascii=False),
            ))
            db.commit()
            return int(cur.lastrowid)

    def upsert_snapshot(self, symbol: str, ts: str, price: float, short_score: float, long_score: float, payload: dict[str, Any]) -> None:
        with self.lock, self._connect() as db:
            db.execute("""
                INSERT INTO snapshots(symbol, ts, price, short_score, long_score, payload_json)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(symbol) DO UPDATE SET ts=excluded.ts, price=excluded.price, short_score=excluded.short_score,
                long_score=excluded.long_score, payload_json=excluded.payload_json
            """, (symbol, ts, price, short_score, long_score, json.dumps(payload, ensure_ascii=False)))
            db.commit()

    def insert_skip(self, ts: str, symbol: str, reason: str, details: dict[str, Any]) -> None:
        with self.lock, self._connect() as db:
            db.execute("INSERT INTO skipped(ts, symbol, reason, details_json) VALUES (?, ?, ?, ?)", (ts, symbol, reason, json.dumps(details, ensure_ascii=False)))
            db.commit()

    def insert_run(self, started_at: str, finished_at: str, scanned: int, alerts: int, skipped: int, seconds: float, status: str, error: str | None = None) -> None:
        with self.lock, self._connect() as db:
            db.execute("INSERT INTO runs(started_at, finished_at, scanned, alerts, skipped, seconds, status, error) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", (started_at, finished_at, scanned, alerts, skipped, seconds, status, error))
            db.commit()

    def _deserialize_payloads(self, rows: list[sqlite3.Row], key: str = "payload_json") -> list[dict[str, Any]]:
        payloads: list[dict[str, Any]] = []
        for r in rows:
            try:
                value = json.loads(r[key])
                if isinstance(value, dict):
                    payloads.append(value)
            except (TypeError, json.JSONDecodeError):
                # Corrupted rows must not take down API endpoints. Keep the DB
                # row for audit/forensics and skip it in user-facing lists.
                continue
        return payloads

    def list_signals(self, limit: int = 100, min_score: float = 0, side: str | None = None) -> list[dict[str, Any]]:
        sql = "SELECT payload_json FROM signals WHERE score >= ?"
        params: list[Any] = [min_score]
        if side and side.upper() in {"LONG", "SHORT"}:
            sql += " AND side = ?"
            params.append(side.upper())
        sql += " ORDER BY id DESC LIMIT ?"
        params.append(limit)
        with self.lock, self._connect() as db:
            rows = db.execute(sql, params).fetchall()
        return self._deserialize_payloads(rows)

    def latest_snapshots(self, limit: int = 250) -> list[dict[str, Any]]:
        with self.lock, self._connect() as db:
            rows = db.execute(
                "SELECT payload_json FROM snapshots ORDER BY CASE WHEN short_score >= long_score THEN short_score ELSE long_score END DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return self._deserialize_payloads(rows)

    def latest_skips(self, limit: int = 100) -> list[dict[str, Any]]:
        with self.lock, self._connect() as db:
            rows = db.execute("SELECT * FROM skipped ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        out: list[dict[str, Any]] = []
        for r in rows:
            try:
                details = json.loads(r["details_json"])
            except (TypeError, json.JSONDecodeError):
                details = {"corrupt_payload": True}
            out.append({"id": r["id"], "ts": r["ts"], "symbol": r["symbol"], "reason": r["reason"], "details": details})
        return out

    def latest_runs(self, limit: int = 20) -> list[dict[str, Any]]:
        with self.lock, self._connect() as db:
            rows = db.execute("SELECT * FROM runs ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]
