from __future__ import annotations

import asyncio
import time
from collections import deque
from typing import Any

from ..clients.binance import BinanceFuturesClient
from ..clients.lbank import LBankContractClient
from ..clients.gate import GateFuturesClient
from ..clients.dexscreener import DexScreenerClient
from ..clients.coingecko import CoinGeckoClient
from ..clients.http import LiveDataError
from ..config import load_settings, save_settings
from ..engine.indicators import (
    atr, candle_change, cvd_proxy, ema, orderbook_metrics, pct_change, quote_volume_spike, clamp,
    recent_high_break, recent_low_break, rsi, safe_float, taker_sell_pressure_from_klines,
    volume_spike, vwap,
)
from ..engine.scoring import build_signal, publish_gates_ok, score_long, score_short
from ..engine.binance_microstructure import derive_microstructure, dynamic_depth_gate, dynamic_spread_gate
from ..engine.multisource_confidence import (
    derive_chart_confirmation,
    derive_cross_feed_validation,
    derive_liquidity_tier,
    derive_model_confidence,
    derive_news_risk,
)
from ..engine.early import compute_early_warning
from ..models import DexItem, ScanStatus, Settings, SourceStatus
from ..timeutil import utc_now
from .storage import Storage


class ScannerService:
    def __init__(self, storage: Storage) -> None:
        self.storage = storage
        self.settings: Settings = load_settings()
        self.status = ScanStatus()
        self.logs: deque[str] = deque(maxlen=220)
        self.scan_requested = False
        self._scan_lock = asyncio.Lock()
        self._loop_task: asyncio.Task | None = None
        self._binance = BinanceFuturesClient()
        self._lbank = LBankContractClient()
        self._gate = GateFuturesClient()
        self._dex = DexScreenerClient()
        self._cg = CoinGeckoClient()
        self._last_alert_ts: dict[tuple[str, str, str], float] = {}
        self._market_context: dict[str, Any] = {}
        # Keep diagnostics responsive even when a live provider is slow/blocked.
        # These endpoints are read-only UI probes; they must not freeze the page.
        self._source_probe_timeout_sec = 7.0
        self._microstructure_timeout_sec = 6.0

    async def close(self) -> None:
        await self.stop_loop()
        await self._binance.close()
        await self._lbank.close()
        await self._gate.close()
        await self._dex.close()
        await self._cg.close()

    def log(self, message: str) -> None:
        self.logs.appendleft(f"[{utc_now()}] {message}")

    def update_settings(self, partial: dict[str, Any]) -> Settings:
        data = self.settings.model_dump()
        data.update({k: v for k, v in partial.items() if v is not None})
        self.settings = Settings(**data)
        save_settings(self.settings)
        self.log("تنظیمات ذخیره شد.")
        return self.settings

    async def data_health(self) -> list[dict[str, Any]]:
        async def probe(name: str, func) -> SourceStatus:
            started = time.perf_counter()
            checked_at = utc_now()
            try:
                data = await asyncio.wait_for(func(), timeout=self._source_probe_timeout_sec)
                if isinstance(data, dict) and data.get("ok") is False:
                    raise LiveDataError(str(data.get("error") or data))
                latency_ms = int((time.perf_counter() - started) * 1000)
                details: dict[str, Any] = {}
                if isinstance(data, dict):
                    details = {k: data.get(k) for k in list(data.keys())[:6]}
                elif isinstance(data, list):
                    details = {"items": len(data)}
                return SourceStatus(source=name, ok=True, latency_ms=latency_ms, checked_at=checked_at, details=details)
            except asyncio.TimeoutError:
                latency_ms = int((time.perf_counter() - started) * 1000)
                return SourceStatus(
                    source=name,
                    ok=False,
                    latency_ms=latency_ms,
                    checked_at=checked_at,
                    error=f"source probe timed out after {self._source_probe_timeout_sec:.1f}s",
                )
            except Exception as exc:  # noqa: BLE001
                latency_ms = int((time.perf_counter() - started) * 1000)
                return SourceStatus(source=name, ok=False, latency_ms=latency_ms, checked_at=checked_at, error=str(exc))

        async def disabled_source() -> dict[str, Any]:
            return {"ok": True, "disabled": True}

        checks = await asyncio.gather(
            probe("Binance Futures /time", self._binance.ping),
            probe("Binance Futures exchangeInfo", self._binance.exchange_info),
            probe("Binance Futures 24hr ticker", self._binance.ticker_24h),
            probe("Binance Futures premiumIndex", self._binance.premium_index),
            probe("LBank Perp time", self._lbank.ping) if self.settings.include_lbank_contract else probe("LBank Perp disabled", disabled_source),
            probe("LBank Perp instruments", self._lbank.instruments) if self.settings.include_lbank_contract else probe("LBank instruments disabled", disabled_source),
            probe("LBank Perp marketData", self._lbank.market_data) if self.settings.include_lbank_contract else probe("LBank marketData disabled", disabled_source),
            probe("Gate Futures ping", self._gate.ping) if self.settings.include_gate_contract else probe("Gate Futures disabled", disabled_source),
            probe("Gate Futures instruments", self._gate.instruments) if self.settings.include_gate_contract else probe("Gate instruments disabled", disabled_source),
            probe("Gate Futures marketData", self._gate.market_data) if self.settings.include_gate_contract else probe("Gate marketData disabled", disabled_source),
            probe("DEX Screener latest profiles", self._dex.latest_profiles) if self.settings.dex_context_enabled else probe("DEX Screener disabled", disabled_source),
            probe("CoinGecko ping", self._cg.ping) if self.settings.coingecko_context_enabled else probe("CoinGecko disabled", disabled_source),
            probe("Market Regime BTC/ETH", self.market_context),
            probe("Binance Microstructure BTCUSDT", lambda: self.binance_microstructure_context("BTCUSDT")) if self.settings.binance_microstructure_enabled else probe("Binance Microstructure disabled", disabled_source),
        )
        return [c.model_dump() for c in checks]

    async def start_loop(self) -> None:
        if self._loop_task and not self._loop_task.done():
            self.status.loop_enabled = True
            return
        self.status.loop_enabled = True
        self._loop_task = asyncio.create_task(self._loop())
        self.log("لوپ زنده روشن شد.")

    async def stop_loop(self) -> None:
        self.status.loop_enabled = False
        if self._loop_task and not self._loop_task.done():
            self._loop_task.cancel()
            try:
                await self._loop_task
            except asyncio.CancelledError:
                pass
        self.log("لوپ زنده خاموش شد.")

    async def _loop(self) -> None:
        while self.status.loop_enabled:
            await self.run_scan()
            await asyncio.sleep(self.settings.scan_interval_sec)

    async def build_universe(self) -> list[dict[str, Any]]:
        jobs = []
        if self.settings.include_binance_futures:
            jobs.append(self._build_binance_universe())
        if self.settings.include_lbank_contract:
            jobs.append(self._build_lbank_universe())
        if getattr(self.settings, "include_gate_contract", False):
            jobs.append(self._build_gate_universe())
        if not jobs:
            return []
        results = await asyncio.gather(*jobs, return_exceptions=True)
        rows: list[dict[str, Any]] = []
        for res in results:
            if isinstance(res, Exception):
                self.log(f"Universe source failed: {res}")
            else:
                rows.extend(res)
        # Drop duplicate exchange:symbol pairs by keeping the first (highest score) occurrence.
        unique: dict[tuple[str, str], dict[str, Any]] = {}
        # Sort descending by pre_score so highest scores win dedup resolution.
        for row in sorted(rows, key=lambda x: x.get("pre_score", 0), reverse=True):
            key = (row.get("exchange"), row.get("symbol"))
            if key not in unique:
                unique[key] = row
        rows = list(unique.values())
        rows.sort(key=lambda x: x.get("pre_score", 0), reverse=True)
        capped_rows = rows[: self._safe_universe_limit(len(rows))]
        self.log(
            f"Universe filter: candidates={len(rows)}, selected={len(capped_rows)}, "
            f"max_symbols={self.settings.max_symbols}, estimated_weight={self._estimate_scan_weight(len(capped_rows))}, "
            f"target_weight={self.settings.target_request_weight_per_min}"
        )
        return capped_rows

    def _safe_universe_limit(self, available: int) -> int:
        requested = min(int(self.settings.max_symbols), available)
        if not self.settings.rate_limit_safe_mode:
            return requested
        budget = min(int(self.settings.target_request_weight_per_min), int(getattr(self.settings, "binance_weight_budget_per_min", self.settings.target_request_weight_per_min)))
        global_weight = 1 + 40 + 5  # exchangeInfo + all 24h tickers + small market context cushion
        per_symbol_weight = 4 + 2  # 4 light kline calls + depth limit 20
        if self.settings.require_open_interest or getattr(self.settings, "use_open_interest_score", True) or getattr(self.settings, "use_open_interest_delta", True):
            per_symbol_weight += 1
        if self.settings.require_taker_flow or getattr(self.settings, "use_taker_flow_score", True):
            per_symbol_weight += 1
        safe = max(5, int((budget - global_weight) // max(1, per_symbol_weight)))
        return max(5, min(requested, safe))

    def _estimate_scan_weight(self, symbols: int) -> int:
        per_symbol_weight = 4 + 2
        if self.settings.require_open_interest or getattr(self.settings, "use_open_interest_score", True) or getattr(self.settings, "use_open_interest_delta", True):
            per_symbol_weight += 1
        if self.settings.require_taker_flow or getattr(self.settings, "use_taker_flow_score", True):
            per_symbol_weight += 1
        return 46 + symbols * per_symbol_weight

    async def _build_binance_universe(self) -> list[dict[str, Any]]:
        fetched_at = utc_now()
        info, tickers = await asyncio.gather(self._binance.exchange_info(), self._binance.ticker_24h())
        symbol_meta = {
            s.get("symbol"): s for s in info.get("symbols", [])
            if s.get("status") == "TRADING" and s.get("quoteAsset") == "USDT" and s.get("contractType") == "PERPETUAL"
        }
        rows: list[dict[str, Any]] = []
        for t in tickers:
            symbol = t.get("symbol")
            if symbol not in symbol_meta:
                continue
            price = safe_float(t.get("lastPrice"))
            quote_volume = safe_float(t.get("quoteVolume"))
            if price <= 0 or price > self.settings.max_price:
                continue
            if quote_volume < self.settings.min_quote_volume and not self.settings.include_low_liquidity:
                continue
            change = safe_float(t.get("priceChangePercent"))
            high = safe_float(t.get("highPrice"))
            low = safe_float(t.get("lowPrice"))
            range_pct = pct_change(high, low) if high > 0 and low > 0 and high > low else 0.0
            if abs(change) < self.settings.min_abs_price_change_pct and range_pct < self.settings.min_24h_range_pct:
                continue
            drawdown = pct_change(high, price) if high > price else 0.0
            meta = symbol_meta[symbol]
            subtype = meta.get("underlyingSubType", []) or []
            meme_boost = 12 if any(str(x).upper() in {"MEME", "DOGECOIN", "FAN_TOKEN"} for x in subtype) else 0
            low_price_boost = 8 if price <= 0.25 else (4 if price <= 0.5 else 0)
            range_boost = min(18, range_pct * 0.55)
            trade_count = safe_float(t.get("count"))
            activity_boost = min(10, trade_count / 30_000)
            pre_score = (
                abs(change) * 1.45
                + min(38, quote_volume / 1_000_000)
                + min(20, drawdown * 0.45)
                + range_boost
                + activity_boost
                + low_price_boost
                + meme_boost
                + (8 if change < 0 else 0)
            )
            rows.append({
                "exchange": "binance-futures",
                "symbol": symbol,
                "price": price,
                "mark_price": None,
                "quote_volume_24h": quote_volume,
                "base_volume_24h": safe_float(t.get("volume")),
                "price_change_24h": change,
                "high_24h": high,
                "low_24h": low,
                "range_24h_pct": range_pct,
                "funding_rate": None,
                "open_interest": None,
                "underlying_type": meta.get("underlyingType"),
                "underlying_subtype": meta.get("underlyingSubType", []),
                "venue_tag": "",
                "onboard_date": meta.get("onboardDate"),
                "pre_score": round(pre_score, 3),
                "min_quote_volume_gate": self.settings.min_quote_volume,
                "max_spread_pct_gate": self.settings.max_spread_pct,
                "min_depth_1pct_usd_gate": self.settings.min_depth_1pct_usd,
                "sources": {
                    "exchange_info": {"source": "binance-futures", "endpoint": "/fapi/v1/exchangeInfo", "fetched_at": fetched_at},
                    "ticker_24h": {"source": "binance-futures", "endpoint": "/fapi/v1/ticker/24hr", "fetched_at": fetched_at},
                },
            })
        if getattr(self.settings, "binance_microstructure_enabled", True):
            for r in rows:
                r["max_spread_pct_gate"] = dynamic_spread_gate(r, self.settings)
                r["min_depth_1pct_usd_gate"] = dynamic_depth_gate(r, self.settings)
                r.setdefault("binance_microstructure_universe", {})["dynamic_thresholds"] = True
        return rows

    async def _build_lbank_universe(self) -> list[dict[str, Any]]:
        fetched_at = utc_now()
        instruments, markets = await asyncio.gather(self._lbank.instruments(), self._lbank.market_data())
        meta = {m.get("symbol"): m for m in instruments if m.get("symbol")}
        rows: list[dict[str, Any]] = []
        for t in markets:
            symbol = t.get("symbol")
            if not symbol or not symbol.endswith("USDT"):
                continue
            price = safe_float(t.get("lastPrice"))
            quote_volume = safe_float(t.get("quoteVolume"))
            high = safe_float(t.get("highPrice"))
            low = safe_float(t.get("lowPrice"))
            if price <= 0 or price > self.settings.max_price:
                continue
            if quote_volume < self.settings.lbank_min_quote_volume and not self.settings.include_low_liquidity:
                continue
            change = safe_float(t.get("priceChangePercent"))
            drawdown = pct_change(high, price) if high > price else 0.0
            range_pct = pct_change(high, low) if high > 0 and low > 0 and high > low else 0.0
            if abs(change) < self.settings.min_abs_price_change_pct and range_pct < self.settings.min_24h_range_pct:
                continue
            near_low_pct = ((price - low) / (high - low) * 100.0) if high > low and price >= low else 999.0
            m = meta.get(symbol, {})
            tag = t.get("tag") or m.get("tag") or ""
            pre_score = abs(change) * 1.7 + min(32, quote_volume / 70_000) + (10 if change < 0 else 0) + min(20, drawdown * 0.5)
            if tag:
                pre_score += 3
            rows.append({
                "exchange": "lbank-contract",
                "symbol": symbol,
                "raw_symbol": t.get("raw_symbol") or symbol,
                "price": price,
                "mark_price": safe_float(t.get("markPrice"), price),
                "quote_volume_24h": quote_volume,
                "base_volume_24h": safe_float(t.get("volume")),
                "price_change_24h": change,
                "high_24h": high,
                "low_24h": low,
                "range_24h_pct": range_pct,
                "funding_rate": safe_float(t.get("fundingRate")) if t.get("fundingRate") is not None else None,
                "open_interest": safe_float(t.get("openInterest")) if t.get("openInterest") is not None else None,
                "underlying_type": "LBank Perp",
                "underlying_subtype": [tag] if tag else [],
                "venue_tag": tag,
                "onboard_date": None,
                "pre_score": round(pre_score, 3),
                "near_24h_low_pct": near_low_pct,
                "drawdown_from_24h_high_pct": drawdown,
                "min_quote_volume_gate": self.settings.lbank_min_quote_volume,
                "max_spread_pct_gate": self.settings.lbank_max_spread_pct,
                "min_depth_1pct_usd_gate": self.settings.lbank_min_depth_1pct_usd,
                "sources": {
                    "instrument": {"source": "lbank-contract", "endpoint": "/cfd/openApi/v1/pub/instrument", "fetched_at": fetched_at},
                    "market_data": {"source": "lbank-contract", "endpoint": "/cfd/openApi/v1/pub/marketData", "fetched_at": fetched_at},
                },
            })
        return rows

    async def _build_gate_universe(self) -> list[dict[str, Any]]:
        """Build the Gate.io universe for USDT perpetual contracts.

        This method mirrors ``_build_lbank_universe`` but uses the Gate.io client
        to fetch instruments and 24h market data.  Only symbols ending with
        ``USDT`` are considered.  Pre‑scores are computed using similar heuristics:
        larger absolute price changes and quote volumes lift the score, while
        drawdowns from the 24h high contribute a modest boost.  Symbols with
        very small ranges or low liquidity are discarded unless
        ``include_low_liquidity`` is true.
        """
        fetched_at = utc_now()
        try:
            instruments, markets = await asyncio.gather(self._gate.instruments(), self._gate.market_data())
        except Exception as exc:  # noqa: BLE001
            self.log(f"Gate universe fetch failed: {exc}")
            return []
        meta = {m.get("symbol"): m for m in instruments if m.get("symbol")}
        rows: list[dict[str, Any]] = []
        for t in markets:
            symbol = t.get("symbol")
            if not symbol or not symbol.endswith("USDT"):
                continue
            price = safe_float(t.get("lastPrice"))
            quote_volume = safe_float(t.get("quoteVolume"))
            high = safe_float(t.get("highPrice"))
            low = safe_float(t.get("lowPrice"))
            if price <= 0 or price > self.settings.max_price:
                continue
            # Minimum liquidity filter
            if quote_volume < getattr(self.settings, "gate_min_quote_volume", self.settings.min_quote_volume) and not self.settings.include_low_liquidity:
                continue
            change = safe_float(t.get("priceChangePercent"))
            drawdown = pct_change(high, price) if high > price else 0.0
            range_pct = pct_change(high, low) if high > 0 and low > 0 and high > low else 0.0
            if abs(change) < self.settings.min_abs_price_change_pct and range_pct < self.settings.min_24h_range_pct:
                continue
            near_low_pct = ((price - low) / (high - low) * 100.0) if high > low and price >= low else 999.0
            m = meta.get(symbol, {})
            tag = t.get("tag") or m.get("tag") or ""
            # Compute pre_score similarly to LBank: price change, volume and drawdown
            pre_score = abs(change) * 1.7 + min(32, quote_volume / 70_000) + (10 if change < 0 else 0) + min(20, drawdown * 0.5)
            if tag:
                pre_score += 3
            settle = self._gate.settle
            rows.append({
                "exchange": "gate-futures",
                "symbol": symbol,
                "raw_symbol": t.get("raw_symbol") or symbol,
                "price": price,
                "mark_price": safe_float(t.get("markPrice"), price),
                "quote_volume_24h": quote_volume,
                "base_volume_24h": safe_float(t.get("volume")),
                "price_change_24h": change,
                "high_24h": high,
                "low_24h": low,
                "range_24h_pct": range_pct,
                "funding_rate": safe_float(t.get("fundingRate")) if t.get("fundingRate") is not None else None,
                "open_interest": safe_float(t.get("openInterest")) if t.get("openInterest") is not None else None,
                "underlying_type": "Gate Futures",
                "underlying_subtype": [tag] if tag else [],
                "venue_tag": tag,
                "onboard_date": None,
                "pre_score": round(pre_score, 3),
                "near_24h_low_pct": near_low_pct,
                "drawdown_from_24h_high_pct": drawdown,
                "min_quote_volume_gate": getattr(self.settings, "gate_min_quote_volume", self.settings.min_quote_volume),
                "max_spread_pct_gate": getattr(self.settings, "gate_max_spread_pct", self.settings.max_spread_pct),
                "min_depth_1pct_usd_gate": getattr(self.settings, "gate_min_depth_1pct_usd", self.settings.min_depth_1pct_usd),
                "sources": {
                    "instrument": {"source": "gate-futures", "endpoint": f"/api/v4/futures/{settle}/contracts", "fetched_at": fetched_at},
                    "market_data": {"source": "gate-futures", "endpoint": f"/api/v4/futures/{settle}/tickers", "fetched_at": fetched_at},
                },
            })
        return rows

    async def run_scan(self) -> dict[str, Any]:
        if self._scan_lock.locked():
            self.log("اسکن قبلی هنوز فعال است؛ درخواست جدید رد شد.")
            return {"ok": False, "message": "scan already running"}
        async with self._scan_lock:
            start = time.perf_counter()
            started_at = utc_now()
            self.status = self.status.model_copy(update={
                "running": True,
                "started_at": started_at,
                "finished_at": None,
                "progress_done": 0,
                "progress_total": 0,
                "scanned": 0,
                "produced_signals": 0,
                "skipped_symbols": 0,
                "message": "در حال ساخت Universe زنده چندمنبعی",
                "last_error": None,
            })
            alerts: list[dict[str, Any]] = []
            skipped = 0
            scanned = 0
            try:
                universe = await self.build_universe()
                if not universe:
                    seconds = round(time.perf_counter() - start, 2)
                    finished_at = utc_now()
                    reason = "Universe is empty. Live source failed or filters are too strict. Run Data Health / RUN_DIAGNOSTIC and check Binance connectivity."
                    self.status.running = False
                    self.status.finished_at = finished_at
                    self.status.last_scan_seconds = seconds
                    self.status.last_error = reason
                    self.status.message = "خطا/هشدار: Universe خالی است؛ اتصال Binance یا فیلترها را چک کن"
                    self.storage.insert_run(started_at, finished_at, 0, 0, 0, seconds, "no_universe", reason)
                    self.log(reason)
                    return {"ok": False, "scanned": 0, "alerts": 0, "skipped": 0, "seconds": seconds, "error": reason}
                premiums = {}
                if self.settings.include_binance_futures:
                    try:
                        premiums = {p.get("symbol"): p for p in await self._binance.premium_index() if p.get("symbol")}
                    except Exception as exc:  # noqa: BLE001
                        self.log(f"premiumIndex optional source failed: {exc}")
                self._market_context = await self.market_context() if self.settings.market_regime_filter else {"bias":"disabled"}
                self.status.progress_total = len(universe)
                self.log(f"Universe زنده آماده شد: {len(universe)} نماد")
                sem = asyncio.Semaphore(self.settings.concurrent_requests)

                async def worker(row: dict[str, Any]) -> tuple[list[dict[str, Any]], int]:
                    async with sem:
                        exchange = row.get("exchange")
                        if exchange == "lbank-contract":
                            return await self.analyze_lbank_symbol(row)
                        if exchange == "gate-futures":
                            return await self.analyze_gate_symbol(row)
                        return await self.analyze_binance_symbol(row, premiums.get(row["symbol"]))

                tasks = [asyncio.create_task(worker(row)) for row in universe]
                for task in asyncio.as_completed(tasks):
                    try:
                        found, skipped_one = await task
                        alerts.extend(found)
                        skipped += skipped_one
                    except Exception as exc:  # noqa: BLE001
                        skipped += 1
                        self.log(f"خطای تحلیل نماد: {exc}")
                    scanned += 1
                    self.status.progress_done = scanned
                    self.status.scanned = scanned
                    self.status.produced_signals = len(alerts)
                    self.status.skipped_symbols = skipped
                    self.status.message = f"اسکن زنده {scanned}/{len(universe)}"
                seconds = round(time.perf_counter() - start, 2)
                finished_at = utc_now()
                self.status.running = False
                self.status.finished_at = finished_at
                self.status.last_scan_seconds = seconds
                self.status.message = f"اتمام: {len(alerts)} هشدار، {skipped} ردشده"
                self.storage.insert_run(started_at, finished_at, scanned, len(alerts), skipped, seconds, "ok")
                self.log(f"اسکن تمام شد: scanned={scanned}, signals={len(alerts)}, skipped={skipped}, seconds={seconds}")
                return {"ok": True, "scanned": scanned, "alerts": len(alerts), "skipped": skipped, "seconds": seconds}
            except Exception as exc:  # noqa: BLE001
                seconds = round(time.perf_counter() - start, 2)
                finished_at = utc_now()
                self.status.running = False
                self.status.finished_at = finished_at
                self.status.last_error = str(exc)
                self.status.message = "خطا در اسکن زنده"
                self.storage.insert_run(started_at, finished_at, scanned, len(alerts), skipped, seconds, "error", str(exc))
                self.log(f"خطای اسکن: {exc}")
                return {"ok": False, "error": str(exc)}

    async def analyze_binance_symbol(self, base_row: dict[str, Any], premium: dict[str, Any] | None) -> tuple[list[dict[str, Any]], int]:
        symbol = base_row["symbol"]
        ts = utc_now()
        missing: list[str] = []
        if premium is None and self.settings.require_funding:
            missing.append("premiumIndex/funding")
        try:
            results = await asyncio.gather(
                self._binance.klines(symbol, "1m", self.settings.kline_limit_1m),
                self._binance.klines(symbol, "5m", self.settings.kline_limit_5m),
                self._binance.klines(symbol, "15m", self.settings.kline_limit_15m),
                self._binance.klines(symbol, "1h", self.settings.kline_limit_1h),
                self._binance.depth(symbol, self.settings.depth_limit),
                self._binance.open_interest_hist(symbol, "5m", 12) if (self.settings.require_open_interest or getattr(self.settings, "use_open_interest_score", True) or getattr(self.settings, "use_open_interest_delta", True)) else asyncio.sleep(0, result=[]),
                self._binance.taker_buy_sell_volume(symbol, "5m", 12) if (self.settings.require_taker_flow or getattr(self.settings, "use_taker_flow_score", True)) else asyncio.sleep(0, result=[]),
                return_exceptions=True,
            )
            k1m, k5, k15, k1h, depth, oi_hist, taker_ratio = results
            if isinstance(k1m, Exception):
                k1m = []
            if isinstance(k5, Exception): missing.append("klines_5m")
            if isinstance(k15, Exception): missing.append("klines_15m")
            if isinstance(k1h, Exception): missing.append("klines_1h")
            if isinstance(depth, Exception) and self.settings.require_depth: missing.append("order_book_depth")
            if isinstance(oi_hist, Exception) and self.settings.require_open_interest: missing.append("open_interest_hist")
            if isinstance(taker_ratio, Exception) and self.settings.require_taker_flow: missing.append("taker_buy_sell_volume")
            if missing and self.settings.strict_live_data:
                self.storage.insert_skip(ts, f"binance-futures:{symbol}", "required live source missing", {"missing": missing})
                return [], 1
            if isinstance(k5, Exception) or isinstance(k15, Exception) or isinstance(k1h, Exception):
                raise LiveDataError(f"core kline source failed for {symbol}: {missing}")
            depth_data = {} if isinstance(depth, Exception) else depth
            oi_data = [] if isinstance(oi_hist, Exception) else oi_hist
            taker_data = [] if isinstance(taker_ratio, Exception) else taker_ratio
        except Exception as exc:  # noqa: BLE001
            self.storage.insert_skip(ts, f"binance-futures:{symbol}", "analysis request failure", {"error": str(exc)})
            return [], 1

        return self._score_from_klines("binance-futures", base_row, ts, k5, k15, k1h, depth_data, premium, oi_data, taker_data, missing, k1m=k1m)

    async def analyze_lbank_symbol(self, base_row: dict[str, Any]) -> tuple[list[dict[str, Any]], int]:
        symbol = base_row["symbol"]
        ts = utc_now()
        missing: list[str] = []
        try:
            results = await asyncio.gather(
                self._lbank.klines(symbol, "5m", 160),
                self._lbank.klines(symbol, "15m", 120),
                self._lbank.klines(symbol, "1h", 90),
                self._lbank.depth(symbol, 100),
                return_exceptions=True,
            )
            k5, k15, k1h, depth = results
            if isinstance(k5, Exception): missing.append("lbank_klines_5m")
            if isinstance(k15, Exception): missing.append("lbank_klines_15m")
            if isinstance(k1h, Exception): missing.append("lbank_klines_1h")
            if isinstance(depth, Exception) and self.settings.require_depth: missing.append("lbank_order_book_depth")
            if missing and self.settings.strict_live_data:
                self.storage.insert_skip(ts, f"lbank-contract:{symbol}", "required LBank live source missing", {"missing": missing})
                return [], 1
            if isinstance(k5, Exception) or isinstance(k15, Exception) or isinstance(k1h, Exception):
                raise LiveDataError(f"core LBank kline source failed for {symbol}: {missing}")
            depth_data = {} if isinstance(depth, Exception) else depth
        except Exception as exc:  # noqa: BLE001
            self.storage.insert_skip(ts, f"lbank-contract:{symbol}", "LBank analysis request failure", {"error": str(exc)})
            return [], 1

        if not self.settings.allow_lbank_partial_derivatives:
            if self.settings.require_open_interest and base_row.get("open_interest") is None:
                missing.append("lbank_open_interest_unavailable")
            if self.settings.require_funding and base_row.get("funding_rate") is None:
                missing.append("lbank_funding_unavailable")
            if self.settings.require_taker_flow:
                missing.append("lbank_taker_flow_unavailable")
            if missing and self.settings.strict_live_data:
                self.storage.insert_skip(ts, f"lbank-contract:{symbol}", "required LBank derivatives source missing", {"missing": missing})
                return [], 1

        premium = {"lastFundingRate": base_row.get("funding_rate"), "markPrice": base_row.get("mark_price")}
        return self._score_from_klines("lbank-contract", base_row, ts, k5, k15, k1h, depth_data, premium, [], [], missing, is_lbank=True)

    async def analyze_gate_symbol(self, base_row: dict[str, Any]) -> tuple[list[dict[str, Any]], int]:
        """Analyze a single Gate.io symbol and compute trading signals.

        Similar to ``analyze_lbank_symbol`` but using the Gate client.  Only
        5m/15m/1h klines and depth are fetched.  Because Gate.io's API does not
        expose open interest history or taker flow via the public endpoints
        used here, those fields remain unavailable and are treated as missing
        when required by the settings.  Funding and mark/index prices are
        derived from the base row if provided.
        """
        symbol = base_row["symbol"]
        ts = utc_now()
        missing: list[str] = []
        try:
            results = await asyncio.gather(
                self._gate.klines(symbol, "5m", 160),
                self._gate.klines(symbol, "15m", 120),
                self._gate.klines(symbol, "1h", 90),
                self._gate.depth(symbol, 100),
                return_exceptions=True,
            )
            k5, k15, k1h, depth = results
            if isinstance(k5, Exception): missing.append("gate_klines_5m")
            if isinstance(k15, Exception): missing.append("gate_klines_15m")
            if isinstance(k1h, Exception): missing.append("gate_klines_1h")
            if isinstance(depth, Exception) and self.settings.require_depth: missing.append("gate_order_book_depth")
            if missing and self.settings.strict_live_data:
                self.storage.insert_skip(ts, f"gate-futures:{symbol}", "required Gate live source missing", {"missing": missing})
                return [], 1
            if isinstance(k5, Exception) or isinstance(k15, Exception) or isinstance(k1h, Exception):
                raise LiveDataError(f"core Gate kline source failed for {symbol}: {missing}")
            depth_data = {} if isinstance(depth, Exception) else depth
        except Exception as exc:  # noqa: BLE001
            self.storage.insert_skip(ts, f"gate-futures:{symbol}", "Gate analysis request failure", {"error": str(exc)})
            return [], 1

        # Gate does not provide open interest history or taker flow via these endpoints
        if self.settings.require_open_interest and base_row.get("open_interest") is None:
            missing.append("gate_open_interest_unavailable")
        if self.settings.require_funding and base_row.get("funding_rate") is None:
            missing.append("gate_funding_unavailable")
        if self.settings.require_taker_flow:
            missing.append("gate_taker_flow_unavailable")
        if missing and self.settings.strict_live_data:
            self.storage.insert_skip(ts, f"gate-futures:{symbol}", "required Gate derivatives source missing", {"missing": missing})
            return [], 1
        premium = {"lastFundingRate": base_row.get("funding_rate"), "markPrice": base_row.get("mark_price")}
        return self._score_from_klines("gate-futures", base_row, ts, k5, k15, k1h, depth_data, premium, [], [], missing, is_lbank=False)

    def _score_from_klines(self, exchange: str, base_row: dict[str, Any], ts: str, k5: list[dict[str, Any]], k15: list[dict[str, Any]], k1h: list[dict[str, Any]], depth_data: dict[str, Any], premium: dict[str, Any] | None, oi_data: list[dict[str, Any]], taker_data: list[dict[str, Any]], missing: list[str], is_lbank: bool = False, k1m: list[dict[str, Any]] | None = None) -> tuple[list[dict[str, Any]], int]:
        symbol = base_row["symbol"]
        closes5 = [safe_float(k.get("close")) for k in k5]
        closes15 = [safe_float(k.get("close")) for k in k15]
        closes1h = [safe_float(k.get("close")) for k in k1h]
        price = closes5[-1] if closes5 else safe_float(base_row.get("price"))
        ema20_15 = ema(closes15, 20)
        ema50_15 = ema(closes15, 50)
        ema20_1h = ema(closes1h, 20)
        ema50_1h = ema(closes1h, 50)
        vwap5 = vwap(k5, 60)
        ob = orderbook_metrics(depth_data) if depth_data else {"spread_pct": 999, "ask_bid_imbalance": 0, "depth_1pct_usd": 0}
        high_24h = safe_float(base_row.get("high_24h"))
        low_24h = safe_float(base_row.get("low_24h"))
        near_low_pct = ((price - low_24h) / (high_24h - low_24h) * 100.0) if high_24h > low_24h and price >= low_24h else 999.0
        drawdown = pct_change(high_24h, price) if high_24h > price else 0.0

        oi_change = None
        if len(oi_data) >= 2:
            last = safe_float(oi_data[-1].get("sumOpenInterestValue")) or safe_float(oi_data[-1].get("sumOpenInterest"))
            first = safe_float(oi_data[0].get("sumOpenInterestValue")) or safe_float(oi_data[0].get("sumOpenInterest"))
            oi_change = pct_change(last, first)
        elif base_row.get("open_interest") is not None:
            oi_change = None

        taker_sell = None if is_lbank else taker_sell_pressure_from_klines(k5, 12)
        if taker_data:
            buy = sum(safe_float(x.get("buyVol")) for x in taker_data)
            sell = sum(safe_float(x.get("sellVol")) for x in taker_data)
            if buy + sell > 0:
                taker_sell = sell / (buy + sell)

        k1m = k1m or []
        data_fresh = self._kline_fresh(k5, 5) and self._kline_fresh(k15, 15) and self._kline_fresh(k1h, 60)
        if k1m:
            data_fresh = data_fresh and self._kline_fresh(k1m, 1)
        if not data_fresh:
            missing.append("stale_klines")

        source_coverage = {
            "klines_1m": bool(k1m),
            "klines_5m": bool(k5),
            "klines_15m": bool(k15),
            "klines_1h": bool(k1h),
            "depth": bool(depth_data),
            "open_interest": bool(oi_data) or base_row.get("open_interest") is not None,
            "taker_flow": (not is_lbank and taker_sell is not None),
            "funding": premium is not None and (premium or {}).get("lastFundingRate") is not None,
            "mark_index_premium": premium is not None and (premium or {}).get("markPrice") is not None and (premium or {}).get("indexPrice") is not None,
            "venue_allows_partial_derivatives": bool(is_lbank and self.settings.allow_lbank_partial_derivatives),
        }

        mark_price = safe_float((premium or {}).get("markPrice"), price) if premium is not None else None
        index_price = safe_float((premium or {}).get("indexPrice"), 0.0) if premium is not None else None

        metrics: dict[str, Any] = {
            "exchange": exchange,
            "symbol": symbol,
            "price": price,
            "mark_price": mark_price,
            "index_price": index_price,
            "quote_volume_24h": safe_float(base_row.get("quote_volume_24h")),
            "base_volume_24h": safe_float(base_row.get("base_volume_24h")),
            "price_change_24h": safe_float(base_row.get("price_change_24h")),
            "high_24h": high_24h,
            "low_24h": low_24h,
                "range_24h_pct": safe_float(base_row.get("range_24h_pct")),
            "near_24h_low_pct": near_low_pct,
            "drawdown_from_24h_high_pct": drawdown,
            "underlying_type": base_row.get("underlying_type"),
            "underlying_subtype": base_row.get("underlying_subtype", []),
            "venue_tag": base_row.get("venue_tag"),
            "onboard_date": base_row.get("onboard_date"),
            "rsi_5m": rsi(closes5, 14),
            "rsi_15m": rsi(closes15, 14),
            "atr_5m": atr(k5, 14),
            "vwap_5m": vwap5,
            "ema20_15m": ema20_15,
            "ema50_15m": ema50_15,
            "ema20_1h": ema20_1h,
            "ema50_1h": ema50_1h,
            "trend_bearish_15m": bool(price < ema20_15 < ema50_15) if ema50_15 else False,
            "trend_bullish_15m": bool(price > ema20_15 > ema50_15) if ema50_15 else False,
            "trend_bearish_1h": bool(price < ema20_1h < ema50_1h) if ema50_1h else False,
            "trend_bullish_1h": bool(price > ema20_1h > ema50_1h) if ema50_1h else False,
            "below_vwap_5m": bool(price < vwap5) if vwap5 else False,
            "above_vwap_5m": bool(price > vwap5) if vwap5 else False,
            "low_break_5m": recent_low_break(k5, 20),
            "high_break_5m": recent_high_break(k5, 20),
            "volume_spike": volume_spike(k5, 50),
            "quote_volume_spike": quote_volume_spike(k5, 50),
            "change_15m": candle_change(k5, 3),
            "change_1h": candle_change(k5, 12),
            "cvd_proxy": None if is_lbank else cvd_proxy(k5, 60),
            "taker_sell_pressure": taker_sell,
            "funding_rate": safe_float((premium or {}).get("lastFundingRate")) if premium else None,
            "next_funding_time": (premium or {}).get("nextFundingTime") if premium else None,
            "oi_change_pct": oi_change,
            "min_quote_volume_gate": base_row.get("min_quote_volume_gate", self.settings.min_quote_volume),
            "max_spread_pct_gate": base_row.get("max_spread_pct_gate", self.settings.max_spread_pct),
            "required_sources_ok": not missing,
            "data_fresh_ok": data_fresh,
            "source_coverage": source_coverage,
            "market_context": self._market_context,
            "min_depth_1pct_usd_gate": base_row.get("min_depth_1pct_usd_gate", self.settings.min_depth_1pct_usd),
            "sources": {
                **base_row.get("sources", {}),
                "klines_1m": {"source": exchange, "endpoint": "klines", "interval": "1m", "fetched_at": ts, "latest_close_time": k1m[-1].get("close_time") if k1m else None},
                "klines_5m": {"source": exchange, "endpoint": "klines", "interval": "5m", "fetched_at": ts, "latest_close_time": k5[-1].get("close_time") if k5 else None},
                "klines_15m": {"source": exchange, "endpoint": "klines", "interval": "15m", "fetched_at": ts, "latest_close_time": k15[-1].get("close_time") if k15 else None},
                "klines_1h": {"source": exchange, "endpoint": "klines", "interval": "1h", "fetched_at": ts, "latest_close_time": k1h[-1].get("close_time") if k1h else None},
                "order_book": {"source": exchange, "endpoint": "depth", "fetched_at": ts, "last_update_id": ob.get("last_update_id")},
            },
            **ob,
        }
        if is_lbank:
            metrics["warnings_data"] = ["LBank uses only real public data. Missing OI/taker-flow is shown as unavailable, not guessed."]
        else:
            metrics["sources"].update({
                "open_interest_hist": {"source": "binance-futures", "endpoint": "/futures/data/openInterestHist", "fetched_at": ts, "points": len(oi_data)},
                "taker_buy_sell": {"source": "binance-futures", "endpoint": "/futures/data/takerlongshortRatio", "fetched_at": ts, "points": len(taker_data)},
                "premium_index": {"source": "binance-futures", "endpoint": "/fapi/v1/premiumIndex", "fetched_at": ts},
            })

        if getattr(self.settings, "binance_microstructure_enabled", True) and not is_lbank:
            micro = derive_microstructure(metrics, self.settings)
            metrics["binance_microstructure"] = micro
            metrics["max_spread_pct_gate"] = micro.get("dynamic_spread_gate_pct", metrics.get("max_spread_pct_gate"))
            metrics["min_depth_1pct_usd_gate"] = micro.get("dynamic_depth_gate_usdt", metrics.get("min_depth_1pct_usd_gate"))
            metrics["mark_index_premium_pct"] = micro.get("mark_index_premium_pct")
            metrics["taker_buy_ratio"] = micro.get("taker_buy_ratio")
        elif is_lbank:
            metrics["binance_microstructure"] = {"enabled": False, "reason": "non-binance venue"}

        if getattr(self.settings, "use_chart_confirmation", True):
            metrics["chart_confirmation"] = derive_chart_confirmation(metrics, self.settings)
        if getattr(self.settings, "use_liquidity_tier", True):
            metrics["liquidity_tier"] = derive_liquidity_tier(metrics, self.settings)
        if getattr(self.settings, "use_kraken_news_context", True):
            metrics["news_risk"] = derive_news_risk(metrics, self.settings)
        if getattr(self.settings, "use_alpaca_cross_feed_validation", True):
            metrics["cross_feed_validation"] = derive_cross_feed_validation(metrics, self.settings)
        metrics["model_confidence"] = derive_model_confidence(metrics, self.settings)

        early = compute_early_warning(metrics, k1m, k5, self.settings) if self.settings.early_warning_enabled else {"enabled": False, "level": "INFO", "final_score": 0}
        metrics["early_warning"] = early
        metrics["early_level"] = early.get("level")
        metrics["early_direction"] = early.get("direction")
        metrics["early_move_score"] = early.get("move_score")
        metrics["early_trap_score"] = early.get("trap_score")
        metrics["early_execution_score"] = early.get("execution_score")
        metrics["early_final_score"] = early.get("final_score")

        short_score, short_reasons, short_warnings, short_gates = score_short(metrics, self.settings)
        long_score, long_reasons, long_warnings, long_gates = score_long(metrics, self.settings)
        if is_lbank:
            short_warnings.append("Venue: LBank Perp/Inno style؛ نقدشوندگی پایین‌تر از Binance ممکن است باعث اسلیپیج شود.")
            long_warnings.append("Venue: LBank Perp/Inno style؛ نقدشوندگی پایین‌تر از Binance ممکن است باعث اسلیپیج شود.")
        metrics["short_score"] = round(short_score, 2)
        metrics["long_score"] = round(long_score, 2)
        metrics["short_gates"] = short_gates
        metrics["long_gates"] = long_gates
        metrics["short_reasons"] = short_reasons[:10]
        metrics["long_reasons"] = long_reasons[:10]
        self.storage.upsert_snapshot(f"{exchange}:{symbol}", ts, price, short_score, long_score, metrics)

        signals: list[dict[str, Any]] = []
        if self.settings.prefer_side in ("SHORT", "BOTH") and short_score >= self.settings.score_threshold and publish_gates_ok(short_gates):
            sig = build_signal(ts, symbol, "SHORT", short_score, short_reasons, short_warnings, short_gates, metrics, self.settings)
            if self._allow_alert(sig):
                sig["id"] = self.storage.insert_signal(sig)
                signals.append(sig)
        elif self.settings.prefer_side in ("SHORT", "BOTH") and short_score >= self.settings.score_threshold:
            self.storage.insert_skip(ts, f"{exchange}:{symbol}", "short score passed but critical gates failed", {"score": round(short_score, 2), "failed_gates": [k for k, v in short_gates.items() if not v], "gates": short_gates})

        if self.settings.prefer_side in ("LONG", "BOTH") and long_score >= self.settings.score_threshold and publish_gates_ok(long_gates):
            sig = build_signal(ts, symbol, "LONG", long_score, long_reasons, long_warnings, long_gates, metrics, self.settings)
            if self._allow_alert(sig):
                sig["id"] = self.storage.insert_signal(sig)
                signals.append(sig)
        elif self.settings.prefer_side in ("LONG", "BOTH") and long_score >= self.settings.score_threshold:
            self.storage.insert_skip(ts, f"{exchange}:{symbol}", "long score passed but critical gates failed", {"score": round(long_score, 2), "failed_gates": [k for k, v in long_gates.items() if not v], "gates": long_gates})

        if self.settings.early_confirmed_to_signals and early.get("level") == "CONFIRMED":
            early_side = "LONG" if early.get("direction") == "PUMP" else "SHORT"
            early_score = safe_float(early.get("final_score"))
            early_gates = {
                "early_move_ok": safe_float(early.get("move_score")) >= self.settings.early_confirm_threshold,
                "trap_filter_ok": safe_float(early.get("trap_score"), 100) < self.settings.trap_threshold,
                "execution_ok": safe_float(early.get("execution_score")) >= 55,
                "data_fresh_ok": metrics.get("data_fresh_ok", False),
                "early_score_ok": early_score >= self.settings.early_confirm_threshold,
            }
            if all(early_gates.values()):
                sig = build_signal(
                    ts, symbol, early_side, early_score,
                    [f"Early {early.get('direction')} CONFIRMED"] + list(early.get("reasons") or []),
                    list(early.get("warnings") or []) + ["Early-to-signal override enabled by user", f"TrapScore={early.get('trap_score')}"],
                    early_gates, metrics, self.settings,
                )
                sig["early_warning"] = early
                sig["channel_text"] = self._early_channel_text(symbol, early_side, early, sig)
                if self._allow_alert(sig):
                    sig["id"] = self.storage.insert_signal(sig)
                    signals.append(sig)
            else:
                self.storage.insert_skip(ts, f"{exchange}:{symbol}", "early warning kept as watchlist, not trade signal", {"early_gates": early_gates, "early_score": early_score})
        return signals, 0

    def _early_channel_text(self, symbol: str, side: str, early: dict[str, Any], signal: dict[str, Any]) -> str:
        base = symbol.replace("USDT", "")
        direction_fa = "پامپ" if side == "LONG" else "دامپ/ریزش"
        position = "لانگ" if side == "LONG" else "شورت"
        emoji = "🟢" if side == "LONG" else "🔴"
        lev = signal.get("plan", {}).get("leverage_cap", self.settings.leverage)
        return (
            f"هشدار زودهنگام #{base} برای {direction_fa} تأیید شد\n"
            f"Trap Score: {early.get('trap_score')} | Move Score: {early.get('move_score')} | Execution: {early.get('execution_score')}\n"
            f"با اهرم حداکثر {lev}X و رعایت مدیریت سرمایه، پوزیشن {position} قابل بررسی است\n"
            f"#{side}{emoji}"
        )

    def _allow_alert(self, signal: dict[str, Any]) -> bool:
        key = (signal.get("exchange", ""), signal["symbol"], signal["side"])
        now = time.time()
        last = self._last_alert_ts.get(key, 0)
        if now - last < self.settings.cooldown_minutes * 60:
            return False
        self._last_alert_ts[key] = now
        return True

    def _kline_fresh(self, klines: list[dict[str, Any]], interval_minutes: int) -> bool:
        if not klines:
            return False
        last = klines[-1]
        t = safe_float(last.get("open_time") or last.get("close_time"))
        if t <= 0:
            return False
        if t < 10_000_000_000:
            t *= 1000
        now_ms = time.time() * 1000
        max_age_ms = max(self.settings.max_data_age_sec * 1000, interval_minutes * 60 * 1000 * 3)
        # current forming candle may have close_time in the near future; open_time should not be stale or absurdly future.
        return (now_ms - t) <= max_age_ms and (t - now_ms) <= interval_minutes * 60 * 1000

    async def market_context(self) -> dict[str, Any]:
        ts = utc_now()
        try:
            btc5, btc15, eth15 = await asyncio.gather(
                self._binance.klines("BTCUSDT", "5m", 80),
                self._binance.klines("BTCUSDT", "15m", 80),
                self._binance.klines("ETHUSDT", "15m", 80),
            )
            btc5_close = [safe_float(x.get("close")) for x in btc5]
            btc15_close = [safe_float(x.get("close")) for x in btc15]
            eth15_close = [safe_float(x.get("close")) for x in eth15]
            btc_change_15m = candle_change(btc5, 3)
            btc_change_1h = candle_change(btc5, 12)
            eth_change_1h = candle_change(eth15, 4)
            btc_vwap = vwap(btc5, 60)
            btc_price = btc5_close[-1] if btc5_close else 0.0
            btc_ema20 = ema(btc15_close, 20)
            btc_ema50 = ema(btc15_close, 50)
            btc_rsi = rsi(btc5_close, 14) if btc5_close else 50.0

            # CryptoAudit-inspired market regime context: BTC RSI, MACD and volume ratio.
            # This keeps the project self-contained and live-data-only: values come from Binance candles,
            # not from mocked or manually injected sentiment.
            btc_volumes = [safe_float(x.get("quote_volume") or x.get("volume")) for x in btc5]
            recent_vol = btc_volumes[-1] if btc_volumes else 0.0
            avg_vol = sum(btc_volumes[-50:]) / max(len(btc_volumes[-50:]), 1) if btc_volumes else 0.0
            btc_volume_ratio = recent_vol / avg_vol if avg_vol > 0 else 1.0

            def _macd_hist(values: list[float]) -> float:
                if len(values) < 35:
                    return 0.0
                macd_series: list[float] = []
                for i in range(26, len(values) + 1):
                    chunk = values[:i]
                    macd_series.append(ema(chunk, 12) - ema(chunk, 26))
                signal = ema(macd_series, 9) if macd_series else 0.0
                return (macd_series[-1] - signal) if macd_series else 0.0

            btc_macd_histogram = _macd_hist(btc15_close)
            btc_trend = "bullish" if btc_price > btc_vwap and btc_ema20 > btc_ema50 else ("bearish" if btc_price < btc_vwap and btc_ema20 < btc_ema50 else "mixed")
            overbought_low_volume = btc_rsi >= safe_float(getattr(self.settings, "btc_overbought_rsi", 70.0)) and btc_volume_ratio < safe_float(getattr(self.settings, "btc_low_volume_ratio_threshold", 0.8))
            macd_bearish = btc_macd_histogram < 0

            risk_off = (btc_price < btc_vwap and btc_ema20 < btc_ema50) or (btc_change_1h <= -0.8 and eth_change_1h <= -1.0)
            risk_on = (btc_price > btc_vwap and btc_ema20 > btc_ema50) or (btc_change_1h >= 0.8 and eth_change_1h >= 1.0)
            bias = "risk_off" if risk_off else ("risk_on" if risk_on else "neutral")
            return {
                "ok": True,
                "source": "binance-futures",
                "fetched_at": ts,
                "bias": bias,
                "btc_trend": btc_trend,
                "btc_price": btc_price,
                "btc_change_15m": round(btc_change_15m, 4),
                "btc_change_1h": round(btc_change_1h, 4),
                "eth_change_1h": round(eth_change_1h, 4),
                "btc_rsi_5m": round(btc_rsi, 2),
                "btc_macd_histogram_15m": round(btc_macd_histogram, 6),
                "btc_macd_bearish": bool(macd_bearish),
                "btc_volume_ratio_5m": round(btc_volume_ratio, 4),
                "btc_overbought_low_volume": bool(overbought_low_volume),
                "btc_below_vwap": btc_price < btc_vwap if btc_vwap else False,
            }
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "source": "binance-futures", "fetched_at": ts, "bias": "unknown", "error": str(exc)}

    def _microstructure_snapshot_fallback(self, symbol: str, ts: str, reason: str, error: str | None = None) -> dict[str, Any]:
        """Return a fast cached microstructure view when the live probe is unavailable.

        The endpoint is used for UI diagnostics, so it should stay responsive even if Binance
        is blocked, throttled, or slow.  Cached snapshots are clearly marked as fallback and
        never treated as live execution data.
        """
        for item in self.storage.latest_snapshots(300):
            item_symbol = str(item.get("symbol", "")).upper()
            item_key = f"{item.get('exchange')}:{item_symbol}"
            if item_symbol != symbol and item_key != f"binance-futures:{symbol}":
                continue
            metrics = dict(item.get("metrics") or {})
            if not metrics:
                continue
            metrics.setdefault("symbol", symbol)
            micro = metrics.get("binance_microstructure") or derive_microstructure(metrics, self.settings)
            return {
                "ok": True,
                "source": "latest_snapshot_fallback",
                "live_ok": False,
                "fallback": True,
                "fallback_reason": reason,
                "error": error,
                "symbol": symbol,
                "fetched_at": ts,
                "snapshot_ts": item.get("ts"),
                "metrics": metrics,
                "microstructure": micro,
            }
        return {
            "ok": False,
            "source": "binance-futures",
            "live_ok": False,
            "fallback": False,
            "fallback_reason": reason,
            "symbol": symbol,
            "fetched_at": ts,
            "error": error or reason,
        }

    async def binance_microstructure_context(self, symbol: str = "BTCUSDT") -> dict[str, Any]:
        """Small live Binance microstructure diagnostic endpoint.

        This does not execute orders. It is a read-only data-quality/market-quality probe
        used by the UI and deployment checks.  It has a short timeout and a cached fallback
        so the frontend never hangs on a slow external provider.
        """
        ts = utc_now()
        symbol = symbol.upper().replace("/", "").replace("-", "")
        try:
            live_probe = asyncio.gather(
                self._binance.ticker_24h(),
                self._binance.premium_index(),
                self._binance.klines(symbol, "5m", 80),
                self._binance.depth(symbol, self.settings.depth_limit),
                self._binance.open_interest_hist(symbol, "5m", 12) if getattr(self.settings, "use_open_interest_score", True) else asyncio.sleep(0, result=[]),
                self._binance.taker_buy_sell_volume(symbol, "5m", 12) if getattr(self.settings, "use_taker_flow_score", True) else asyncio.sleep(0, result=[]),
                return_exceptions=True,
            )
            ticker_rows, premiums, k5, depth, oi_hist, taker = await asyncio.wait_for(live_probe, timeout=self._microstructure_timeout_sec)
            if isinstance(ticker_rows, Exception):
                raise ticker_rows
            t = next((x for x in ticker_rows if x.get("symbol") == symbol), None)
            if not t:
                return self._microstructure_snapshot_fallback(symbol, ts, "symbol_not_found", "symbol_not_found")
            premium = None if isinstance(premiums, Exception) else next((x for x in premiums if x.get("symbol") == symbol), None)
            fake_base = {
                "exchange": "binance-futures",
                "symbol": symbol,
                "price": safe_float(t.get("lastPrice")),
                "quote_volume_24h": safe_float(t.get("quoteVolume")),
                "base_volume_24h": safe_float(t.get("volume")),
                "price_change_24h": safe_float(t.get("priceChangePercent")),
                "high_24h": safe_float(t.get("highPrice")),
                "low_24h": safe_float(t.get("lowPrice")),
                "range_24h_pct": pct_change(safe_float(t.get("highPrice")), safe_float(t.get("lowPrice"))) if safe_float(t.get("highPrice")) > safe_float(t.get("lowPrice")) else 0.0,
                "min_quote_volume_gate": self.settings.min_quote_volume,
                "max_spread_pct_gate": self.settings.max_spread_pct,
                "min_depth_1pct_usd_gate": self.settings.min_depth_1pct_usd,
            }
            metrics = dict(fake_base)
            metrics.update(orderbook_metrics({} if isinstance(depth, Exception) else depth))
            if not isinstance(k5, Exception) and k5:
                metrics["volume_spike"] = volume_spike(k5, 50)
                metrics["quote_volume_spike"] = quote_volume_spike(k5, 50)
                metrics["change_15m"] = candle_change(k5, 3)
            if premium:
                metrics["funding_rate"] = safe_float(premium.get("lastFundingRate"))
                metrics["mark_price"] = safe_float(premium.get("markPrice"), metrics["price"])
                metrics["index_price"] = safe_float(premium.get("indexPrice"))
            if not isinstance(oi_hist, Exception) and len(oi_hist) >= 2:
                first = safe_float(oi_hist[0].get("sumOpenInterestValue")) or safe_float(oi_hist[0].get("sumOpenInterest"))
                last = safe_float(oi_hist[-1].get("sumOpenInterestValue")) or safe_float(oi_hist[-1].get("sumOpenInterest"))
                metrics["oi_change_pct"] = pct_change(last, first)
            if not isinstance(taker, Exception) and taker:
                buy = sum(safe_float(x.get("buyVol")) for x in taker)
                sell = sum(safe_float(x.get("sellVol")) for x in taker)
                if buy + sell > 0:
                    metrics["taker_sell_pressure"] = sell / (buy + sell)
            micro = derive_microstructure(metrics, self.settings)
            return {"ok": True, "source": "binance-futures", "live_ok": True, "symbol": symbol, "fetched_at": ts, "metrics": metrics, "microstructure": micro}
        except asyncio.TimeoutError:
            return self._microstructure_snapshot_fallback(symbol, ts, "live_probe_timeout", f"Binance microstructure probe exceeded {self._microstructure_timeout_sec}s")
        except Exception as exc:  # noqa: BLE001
            return self._microstructure_snapshot_fallback(symbol, ts, "live_probe_error", str(exc))

    async def multisource_confidence_context(self, symbol: str = "BTCUSDT") -> dict[str, Any]:
        """Read-only model confidence diagnostic using the latest stored snapshot when available."""
        key_candidates = [f"binance-futures:{symbol.upper()}", symbol.upper()]
        snapshots = self.storage.latest_snapshots(300)
        row = None
        for item in snapshots:
            if item.get("symbol", "").upper() == symbol.upper() or f"{item.get('exchange')}:{item.get('symbol')}" in key_candidates:
                row = item
                break
        metrics = (row or {}).get("metrics") or {"symbol": symbol.upper(), "price": 0.0, "data_fresh_ok": False, "required_sources_ok": False}
        metrics.setdefault("symbol", symbol.upper())
        metrics.setdefault("exchange", (row or {}).get("exchange", "diagnostic"))
        metrics["chart_confirmation"] = derive_chart_confirmation(metrics, self.settings)
        metrics["liquidity_tier"] = derive_liquidity_tier(metrics, self.settings)
        metrics["news_risk"] = derive_news_risk(metrics, self.settings)
        metrics["cross_feed_validation"] = derive_cross_feed_validation(metrics, self.settings)
        metrics["model_confidence"] = derive_model_confidence(metrics, self.settings)
        return {"ok": True, "symbol": symbol.upper(), "source": "latest_snapshot_or_diagnostic", "has_snapshot": row is not None, "fetched_at": utc_now(), "model_confidence": metrics["model_confidence"], "metrics": metrics}

    async def analyze_manual_symbol(self, exchange: str, symbol: str) -> dict[str, Any]:
        symbol = symbol.upper().replace("/", "").replace("-", "")
        exchange = exchange.lower().strip()
        self._market_context = await self.market_context() if self.settings.market_regime_filter else {"bias":"disabled"}
        if exchange in {"lbank", "lbank-contract", "lbank_perp"}:
            instruments, markets = await asyncio.gather(self._lbank.instruments(), self._lbank.market_data())
            meta = {m.get("symbol"): m for m in instruments if m.get("symbol")}
            base = None
            for t in markets:
                if t.get("symbol") == symbol:
                    price = safe_float(t.get("lastPrice"))
                    high = safe_float(t.get("highPrice"))
                    low = safe_float(t.get("lowPrice"))
                    m = meta.get(symbol, {})
                    tag = t.get("tag") or m.get("tag") or ""
                    base = {
                        "exchange": "lbank-contract", "symbol": symbol, "raw_symbol": t.get("raw_symbol") or symbol,
                        "price": price, "mark_price": safe_float(t.get("markPrice"), price),
                        "quote_volume_24h": safe_float(t.get("quoteVolume")), "base_volume_24h": safe_float(t.get("volume")),
                        "price_change_24h": safe_float(t.get("priceChangePercent")),
                        "high_24h": high, "low_24h": low,
                        "funding_rate": safe_float(t.get("fundingRate")) if t.get("fundingRate") is not None else None,
                        "open_interest": safe_float(t.get("openInterest")) if t.get("openInterest") is not None else None,
                        "underlying_type": "LBank Perp", "underlying_subtype": [tag] if tag else [], "venue_tag": tag,
                        "min_quote_volume_gate": self.settings.lbank_min_quote_volume,
                        "max_spread_pct_gate": self.settings.lbank_max_spread_pct,
                        "min_depth_1pct_usd_gate": self.settings.lbank_min_depth_1pct_usd,
                        "sources": {"manual_probe": {"source":"lbank-contract", "fetched_at": utc_now()}},
                    }
                    break
            if not base:
                return {"ok": False, "error": f"{symbol} not found in live LBank market data"}
            found, skipped = await self.analyze_lbank_symbol(base)
            return {"ok": True, "exchange": "lbank-contract", "symbol": symbol, "signals": found, "skipped": skipped}

        if exchange in {"gate", "gate-futures", "gate_perp"}:
            # Manual probe for Gate.  Build a base row from the latest market data and meta.
            instruments, markets = await asyncio.gather(self._gate.instruments(), self._gate.market_data())
            meta = {m.get("symbol"): m for m in instruments if m.get("symbol")}
            base = None
            for t in markets:
                if t.get("symbol") == symbol:
                    price = safe_float(t.get("lastPrice"))
                    high = safe_float(t.get("highPrice"))
                    low = safe_float(t.get("lowPrice"))
                    m = meta.get(symbol, {})
                    tag = t.get("tag") or m.get("tag") or ""
                    base = {
                        "exchange": "gate-futures",
                        "symbol": symbol,
                        "raw_symbol": t.get("raw_symbol") or symbol,
                        "price": price,
                        "mark_price": safe_float(t.get("markPrice"), price),
                        "quote_volume_24h": safe_float(t.get("quoteVolume")),
                        "base_volume_24h": safe_float(t.get("volume")),
                        "price_change_24h": safe_float(t.get("priceChangePercent")),
                        "high_24h": high,
                        "low_24h": low,
                        "funding_rate": safe_float(t.get("fundingRate")) if t.get("fundingRate") is not None else None,
                        "open_interest": safe_float(t.get("openInterest")) if t.get("openInterest") is not None else None,
                        "underlying_type": "Gate Futures",
                        "underlying_subtype": [tag] if tag else [],
                        "venue_tag": tag,
                        "min_quote_volume_gate": getattr(self.settings, "gate_min_quote_volume", self.settings.min_quote_volume),
                        "max_spread_pct_gate": getattr(self.settings, "gate_max_spread_pct", self.settings.max_spread_pct),
                        "min_depth_1pct_usd_gate": getattr(self.settings, "gate_min_depth_1pct_usd", self.settings.min_depth_1pct_usd),
                        "sources": {"manual_probe": {"source": "gate-futures", "fetched_at": utc_now()}},
                    }
                    break
            if not base:
                return {"ok": False, "error": f"{symbol} not found in live Gate market data"}
            found, skipped = await self.analyze_gate_symbol(base)
            return {"ok": True, "exchange": "gate-futures", "symbol": symbol, "signals": found, "skipped": skipped}

        info, tickers, premiums = await asyncio.gather(self._binance.exchange_info(), self._binance.ticker_24h(), self._binance.premium_index())
        meta = {s.get("symbol"): s for s in info.get("symbols", [])}
        t = next((x for x in tickers if x.get("symbol") == symbol), None)
        if not t or symbol not in meta:
            return {"ok": False, "error": f"{symbol} not found in live Binance Futures data"}
        m = meta[symbol]
        base = {
            "exchange": "binance-futures", "symbol": symbol, "price": safe_float(t.get("lastPrice")),
            "quote_volume_24h": safe_float(t.get("quoteVolume")), "base_volume_24h": safe_float(t.get("volume")),
            "price_change_24h": safe_float(t.get("priceChangePercent")), "high_24h": safe_float(t.get("highPrice")), "low_24h": safe_float(t.get("lowPrice")),
            "underlying_type": m.get("underlyingType"), "underlying_subtype": m.get("underlyingSubType", []), "venue_tag": "", "onboard_date": m.get("onboardDate"),
            "min_quote_volume_gate": self.settings.min_quote_volume, "max_spread_pct_gate": self.settings.max_spread_pct, "min_depth_1pct_usd_gate": self.settings.min_depth_1pct_usd,
            "sources": {"manual_probe": {"source":"binance-futures", "fetched_at": utc_now()}},
        }
        premium = next((x for x in premiums if x.get("symbol") == symbol), None)
        found, skipped = await self.analyze_binance_symbol(base, premium)
        return {"ok": True, "exchange": "binance-futures", "symbol": symbol, "signals": found, "skipped": skipped}

    async def dex_radar(self) -> list[dict[str, Any]]:
        ts = utc_now()
        profiles, latest_boosts, top_boosts, cto = await asyncio.gather(
            self._dex.latest_profiles(), self._dex.latest_boosts(), self._dex.top_boosts(), self._dex.community_takeovers(), return_exceptions=True
        )
        raw: list[dict[str, Any]] = []
        for source, data in (("profiles", profiles), ("latest_boosts", latest_boosts), ("top_boosts", top_boosts), ("community_takeovers", cto)):
            if isinstance(data, Exception):
                self.log(f"DEX source failed: {source}: {data}")
                continue
            for item in data[:35]:
                x = dict(item)
                x["_source"] = source
                raw.append(x)
        seen: set[tuple[str, str]] = set()
        enriched: list[dict[str, Any]] = []
        sem = asyncio.Semaphore(5)

        async def enrich(item: dict[str, Any]) -> None:
            chain = item.get("chainId")
            addr = item.get("tokenAddress")
            if not chain or not addr or (chain, addr) in seen:
                return
            seen.add((chain, addr))
            async with sem:
                try:
                    pairs = await self._dex.token_pairs(chain, addr)
                except Exception:
                    return
            best = max(pairs, key=lambda p: safe_float((p.get("liquidity") or {}).get("usd")), default={})
            if not best:
                return
            liq = safe_float((best.get("liquidity") or {}).get("usd"))
            vol = safe_float((best.get("volume") or {}).get("h24"))
            chg = safe_float((best.get("priceChange") or {}).get("h24"))
            amount = safe_float(item.get("amount")) + safe_float(item.get("totalAmount")) * 0.1
            score = min(100.0, amount + min(35, vol / 100_000) + min(25, liq / 50_000) + max(0, chg) * 0.15)
            token = best.get("baseToken") or {}
            enriched.append(DexItem(
                source=item.get("_source") or "dex",
                chain_id=chain,
                token_address=addr,
                name=token.get("name") or item.get("description"),
                symbol=token.get("symbol"),
                url=best.get("url") or item.get("url"),
                price_usd=safe_float(best.get("priceUsd")) if best.get("priceUsd") is not None else None,
                liquidity_usd=liq,
                volume_24h=vol,
                price_change_24h=chg,
                score=round(score, 2),
                reason="Live DEX profile/boost/CTO + live pair liquidity/volume/change",
                live_fetched_at=ts,
            ).model_dump())
        await asyncio.gather(*(enrich(i) for i in raw[:90]))
        enriched.sort(key=lambda x: x.get("score", 0), reverse=True)
        return enriched[:60]

    async def coingecko_trending(self) -> dict[str, Any]:
        if not self.settings.coingecko_context_enabled:
            return {"fetched_at": utc_now(), "source": "coingecko", "disabled": True, "data": {"coins": []}}
        data = await self._cg.trending()
        return {"fetched_at": utc_now(), "source": "coingecko", "data": data}

    async def quick_backtest(self, symbol: str, threshold: float, side: str = "SHORT") -> dict[str, Any]:
        symbol = symbol.upper()
        k5 = await self._binance.klines(symbol, "5m", 500)
        rows: list[dict[str, Any]] = []
        hits = 0
        if len(k5) < 100:
            return {"symbol": symbol, "exchange": "binance-futures", "candles": len(k5), "threshold": threshold, "side": side.upper(), "hits": 0, "rows": [], "note": "کندل واقعی کافی از Binance دریافت نشد."}
        for idx in range(90, len(k5) - 8, 6):
            window = k5[:idx]
            closes = [safe_float(x.get("close")) for x in window]
            price = closes[-1]
            vw = vwap(window, 60)
            vspike = max(volume_spike(window, 50), quote_volume_spike(window, 50))
            change15 = candle_change(window, 3)
            change1h = candle_change(window, 12)
            ema20 = ema(closes[-60:], 20)
            ema50 = ema(closes[-90:], 50)
            cvd = cvd_proxy(window, 60)
            taker_sell = taker_sell_pressure_from_klines(window, 12)
            if side.upper() == "LONG":
                score = 0.0
                reasons = []
                if price > ema20 > ema50: score += 18; reasons.append("EMA regime bullish")
                if price > vw: score += 12; reasons.append("above VWAP")
                if recent_high_break(window, 20): score += 18; reasons.append("20-candle high break")
                if change15 >= 2: score += 10; reasons.append("15m momentum")
                if change1h >= 3.5: score += 8; reasons.append("1h momentum")
                if vspike >= 1.8: score += 12; reasons.append("volume spike")
                if cvd >= 0.10: score += 10; reasons.append("positive CVD proxy")
                if taker_sell <= 0.44: score += 8; reasons.append("taker buy pressure")
                future_return = pct_change(k5[idx + 8]["close"], price)
                success = future_return > 0.8
            else:
                score = 0.0
                reasons = []
                if price < ema20 < ema50: score += 18; reasons.append("EMA regime bearish")
                if price < vw: score += 12; reasons.append("below VWAP")
                if recent_low_break(window, 20): score += 18; reasons.append("20-candle low break")
                if change15 <= -2: score += 10; reasons.append("15m sell momentum")
                if change1h <= -4: score += 8; reasons.append("1h sell pressure")
                if vspike >= 1.8: score += 12; reasons.append("volume spike")
                if cvd <= -0.10: score += 10; reasons.append("negative CVD proxy")
                if taker_sell >= 0.56: score += 8; reasons.append("taker sell pressure")
                future_return = pct_change(k5[idx + 8]["close"], price)
                success = future_return < -0.8
            score = clamp(score)
            if score >= threshold:
                hits += 1
                rows.append({"time": k5[idx].get("open_time"), "price": price, "score": round(score, 2), "future_40m_pct": round(future_return, 2), "success": success, "reasons": reasons[:6]})
        return {"symbol": symbol, "exchange": "binance-futures", "candles": len(k5), "threshold": threshold, "side": side.upper(), "hits": hits, "rows": rows[-100:], "note": "این بک‌تست فقط از کندل‌های واقعی Binance در زمان اجرا استفاده می‌کند و هیچ دیتای فرضی، تستی یا ماک وارد نتیجه نمی‌شود."}
