from __future__ import annotations

import csv
import io
import json
import os
import re
from pathlib import Path
from typing import Any

from fastapi import BackgroundTasks, FastAPI, HTTPException, Query, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, ValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

from .clients.http import LiveDataError
from .services.scanner import ScannerService
from .services.storage import Storage

PROJECT_ROOT = Path(__file__).resolve().parents[2]
FRONTEND_DIR = next(
    (p for p in (PROJECT_ROOT / "merged_frontend", PROJECT_ROOT / "frontend") if p.is_dir()),
    PROJECT_ROOT / "merged_frontend",
)

APP_VERSION = "6.6.1-deep-debugged"
REAL_ORDER_EXECUTION_ENABLED = False
SAFE_MODE = os.getenv("SCALPER_SAFE_MODE", "1") != "0"

from contextlib import asynccontextmanager


@asynccontextmanager
async def lifespan(app: FastAPI):
    yield
    await scanner.close()


app = FastAPI(title="Crash Signal Station Meme Early Warning", version=APP_VERSION, lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:8787", "http://localhost:8787"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "no-referrer")
    response.headers.setdefault("Cache-Control", "no-store")
    return response

storage = Storage()
scanner = ScannerService(storage)

SYMBOL_RE = re.compile(r"^[A-Z0-9]{2,30}$")


def _default_visible_signal_score() -> float:
    """Lowest score that should be visible in the default Signals view.

    Normal strategy signals are inserted only after ``score_threshold`` passes.  Early-warning
    confirmed signals can be intentionally promoted from ``early_confirm_threshold``.  The UI
    previously filtered the Signals list by ``score_threshold`` only, which could hide valid
    early-confirmed signals between the two thresholds and make the user think no signal was
    produced.  Keep the default view aligned with the active publication rules.
    """
    default_score = float(scanner.settings.score_threshold)
    if scanner.settings.early_warning_enabled and scanner.settings.early_confirmed_to_signals:
        default_score = min(default_score, float(scanner.settings.early_confirm_threshold))
    return default_score

def _normalize_symbol(symbol: str) -> str:
    value = (symbol or "").upper().replace("/", "").replace("-", "").strip()
    if not SYMBOL_RE.fullmatch(value):
        raise HTTPException(status_code=400, detail={"ok": False, "error": "invalid_symbol", "hint": "Use exchange symbol form like BTCUSDT."})
    return value

class SettingsPatch(BaseModel):
    model_config = ConfigDict(extra="forbid")

    max_price: float | None = None
    min_quote_volume: float | None = None
    max_symbols: int | None = None
    min_abs_price_change_pct: float | None = None
    min_24h_range_pct: float | None = None
    rate_limit_safe_mode: bool | None = None
    target_request_weight_per_min: int | None = None
    depth_limit: int | None = None
    kline_limit_1m: int | None = None
    kline_limit_5m: int | None = None
    kline_limit_15m: int | None = None
    kline_limit_1h: int | None = None
    include_low_liquidity: bool | None = None
    include_binance_futures: bool | None = None
    include_lbank_contract: bool | None = None
    lbank_min_quote_volume: float | None = None
    lbank_max_spread_pct: float | None = None
    min_depth_1pct_usd: float | None = None
    lbank_min_depth_1pct_usd: float | None = None
    max_data_age_sec: int | None = None
    market_regime_filter: bool | None = None
    binance_microstructure_enabled: bool | None = None
    use_usds_futures_universe: bool | None = None
    use_dynamic_spread_threshold: bool | None = None
    use_dynamic_depth_threshold: bool | None = None
    use_dynamic_volume_filter: bool | None = None
    use_percentile_thresholds: bool | None = None
    use_open_interest_score: bool | None = None
    use_open_interest_delta: bool | None = None
    use_funding_score: bool | None = None
    use_mark_index_premium: bool | None = None
    use_taker_flow_score: bool | None = None
    min_taker_buy_ratio_for_long: float | None = None
    max_taker_buy_ratio_for_short: float | None = None
    max_mark_index_premium_pct: float | None = None
    crowded_funding_penalty_enabled: bool | None = None
    crowded_funding_abs_threshold: float | None = None
    binance_weight_budget_per_min: int | None = None
    use_chart_confirmation: bool | None = None
    chart_confirmation_min_score: float | None = None
    chart_min_volume_spike: float | None = None
    chart_bollinger_overextension_rsi: float | None = None
    chart_short_overextension_rsi: float | None = None
    use_kraken_news_context: bool | None = None
    news_risk_penalty_enabled: bool | None = None
    positive_narrative_bonus: float | None = None
    negative_news_penalty: float | None = None
    security_issue_hard_block: bool | None = None
    listing_or_etf_bonus: float | None = None
    use_liquidity_tier: bool | None = None
    major_asset_stability_bonus: float | None = None
    unknown_microcap_risk_penalty: float | None = None
    max_trade_vs_daily_volume_pct: float | None = None
    use_alpaca_cross_feed_validation: bool | None = None
    max_cross_feed_price_deviation_pct: float | None = None
    alpaca_spread_warning_pct: float | None = None
    zero_volume_bar_warning: bool | None = None
    cross_feed_disagreement_penalty: float | None = None
    ui_signal_explainability: bool | None = None
    ui_why_no_signal_panel: bool | None = None
    ui_risk_badges: bool | None = None
    ui_source_health_cards: bool | None = None
    ui_model_confidence_meter: bool | None = None
    financial_datasets_enabled: bool | None = None
    financial_datasets_cache_enabled: bool | None = None
    financial_datasets_regime_enabled: bool | None = None
    financial_datasets_benchmark_enabled: bool | None = None
    financial_datasets_walk_forward_enabled: bool | None = None
    financial_datasets_out_of_sample_ratio: float | None = None
    financial_datasets_min_backtest_trades: int | None = None
    financial_datasets_min_profit_factor: float | None = None
    financial_datasets_max_allowed_drawdown_pct: float | None = None
    btc_overbought_rsi: float | None = None
    btc_overbought_long_penalty: float | None = None
    btc_overbought_required_volume_spike: float | None = None
    btc_low_volume_ratio_threshold: float | None = None
    btc_macd_bearish_long_penalty: float | None = None
    hard_block_long_if_1h_move_above: float | None = None
    anti_chase_penalty: float | None = None
    allow_lbank_partial_derivatives: bool | None = None
    dex_context_enabled: bool | None = None
    coingecko_context_enabled: bool | None = None
    early_warning_enabled: bool | None = None
    meme_mode: bool | None = None
    early_watch_threshold: float | None = None
    early_confirm_threshold: float | None = None
    trap_threshold: float | None = None
    early_volume_spike: float | None = None
    early_confirmed_to_signals: bool | None = None
    prefer_side: str | None = None
    score_threshold: float | None = None
    max_long_chase_1h_pct: float | None = None
    max_short_chase_1h_pct: float | None = None
    max_long_rsi_5m: float | None = None
    min_short_rsi_5m: float | None = None
    max_stop_distance_pct: float | None = None
    cooldown_minutes: int | None = None
    scan_interval_sec: int | None = None
    concurrent_requests: int | None = None
    strict_live_data: bool | None = None
    max_spread_pct: float | None = None
    min_volume_spike_for_trigger: float | None = None
    require_depth: bool | None = None
    require_open_interest: bool | None = None
    require_taker_flow: bool | None = None
    require_funding: bool | None = None
    capital_usdt: float | None = None
    risk_per_trade_pct: float | None = None
    max_total_open_risk_pct: float | None = None
    leverage: float | None = None


@app.exception_handler(StarletteHTTPException)
async def http_error_handler(request: Request, exc: StarletteHTTPException) -> JSONResponse:
    detail = exc.detail
    if isinstance(detail, dict):
        content = {"ok": False, **detail}
    else:
        content = {"ok": False, "error": detail or "http_error"}
    return JSONResponse(status_code=exc.status_code, content=content)


@app.exception_handler(RequestValidationError)
async def request_validation_error_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    return JSONResponse(status_code=422, content={"ok": False, "error": "validation_error", "details": exc.errors()})


@app.exception_handler(LiveDataError)
async def live_data_error_handler(request: Request, exc: LiveDataError) -> JSONResponse:
    return JSONResponse(status_code=503, content={"ok": False, "error": str(exc), "type": "live_data_unavailable"})


@app.exception_handler(ValidationError)
async def validation_error_handler(request: Request, exc: ValidationError) -> JSONResponse:
    return JSONResponse(status_code=422, content={"ok": False, "error": "validation_error", "details": exc.errors()})


@app.exception_handler(Exception)
async def unhandled_error_handler(request: Request, exc: Exception) -> JSONResponse:
    # Do not leak stack traces or internal object reprs to the frontend.
    return JSONResponse(status_code=500, content={"ok": False, "error": "internal_server_error"})

@app.get("/api/health")
async def health() -> dict[str, Any]:
    return {
        "ok": True,
        "app": "Crash Signal Station Meme Early Warning",
        "version": APP_VERSION,
        "runtime": "ready",
        "safe_mode": SAFE_MODE,
        "real_order_execution_enabled": REAL_ORDER_EXECUTION_ENABLED,
        "note": "Runtime check only. Use /api/data-health for live source checks. This app never sends real exchange orders.",
        "settings": scanner.settings.model_dump(),
    }

@app.get("/api/safety")
async def safety() -> dict[str, Any]:
    return {
        "ok": True,
        "safe_mode": SAFE_MODE,
        "real_order_execution_enabled": REAL_ORDER_EXECUTION_ENABLED,
        "execution_endpoints": [],
        "order_routes": "absent",
        "storage": "local SQLite only",
        "message": "Educational analytics and simulation only; no credentialed exchange-order client is wired into the active backend.",
        "risk_planner_note": "Position size, leverage and TP/SL fields are planning outputs, not executable orders.",
    }

@app.get("/api/version")
async def version() -> dict[str, Any]:
    return {"ok": True, "version": APP_VERSION, "backend": "merged_imports.scalper_meme_plus_backend.main:app"}

@app.get("/api/data-health")
async def data_health() -> dict[str, Any]:
    return {"sources": await scanner.data_health()}

@app.get("/api/market-context")
async def market_context() -> dict[str, Any]:
    return await scanner.market_context()

@app.get("/api/binance/microstructure")
async def binance_microstructure(symbol: str = Query("BTCUSDT", min_length=3, max_length=30)) -> dict[str, Any]:
    normalized = _normalize_symbol(symbol)
    return await scanner.binance_microstructure_context(normalized)

@app.get("/api/multisource/confidence")
async def multisource_confidence(symbol: str = Query("BTCUSDT", min_length=3, max_length=30)) -> dict[str, Any]:
    normalized = _normalize_symbol(symbol)
    return await scanner.multisource_confidence_context(normalized)

@app.get("/api/design/system")
async def design_system() -> dict[str, Any]:
    return {
        "ok": True,
        "source": "figma-ready-ui-contract",
        "figma_access_note": "Connected account is currently view-only; this JSON documents the UI contract for implementation or later Figma import.",
        "cards": ["Signal", "WhyNoSignal", "SourceHealth", "ModelConfidence", "Microstructure"],
        "badges": ["WATCH", "EARLY", "CONFIRMED", "TRAP_WARNING", "LOW_CONFIDENCE"],
        "sections": ["Binance Microstructure", "Chart Confirmation", "News Risk", "Liquidity Tier", "Cross-Feed Validation", "Backtest Confidence"],
    }

@app.get("/api/settings")
async def get_settings() -> dict[str, Any]:
    return scanner.settings.model_dump()

@app.patch("/api/settings")
async def patch_settings(patch: SettingsPatch) -> dict[str, Any]:
    try:
        return scanner.update_settings(patch.model_dump(exclude_none=True)).model_dump()
    except ValidationError as exc:
        raise HTTPException(status_code=422, detail={"error": "validation_error", "details": exc.errors()}) from exc


@app.post("/api/settings")
async def post_settings(patch: SettingsPatch) -> dict[str, Any]:
    # POST alias kept for UI/test compatibility. It performs a partial update like PATCH.
    return await patch_settings(patch)

@app.post("/api/scan")
async def scan_now(background: BackgroundTasks) -> dict[str, Any]:
    if scanner.status.running or scanner.scan_requested:
        return {"ok": False, "message": "scan already running"}
    scanner.scan_requested = True

    async def run_background_scan() -> None:
        try:
            await scanner.run_scan()
        finally:
            scanner.scan_requested = False

    background.add_task(run_background_scan)
    return {"ok": True, "message": "live scan started"}

@app.post("/api/scan/wait")
async def scan_wait() -> dict[str, Any]:
    return await scanner.run_scan()

@app.get("/api/analyze/{exchange}/{symbol}")
async def analyze_symbol(exchange: str, symbol: str) -> dict[str, Any]:
    allowed = {"binance", "binance-futures", "binance_futures", "lbank", "lbank-contract", "lbank_perp"}
    if exchange.lower().strip() not in allowed:
        raise HTTPException(status_code=400, detail={"ok": False, "error": "invalid_exchange", "allowed": sorted(allowed)})
    symbol_clean = _normalize_symbol(symbol)
    try:
        result = await scanner.analyze_manual_symbol(exchange=exchange, symbol=symbol_clean)
        result.setdefault("ok", False)
        result.setdefault("signals", [])
        result.setdefault("skipped", 0)
        return result
    except LiveDataError as exc:
        return {"ok": False, "exchange": exchange, "symbol": symbol_clean, "signals": [], "skipped": 0, "error": str(exc)}
    except Exception as exc:  # noqa: BLE001
        scanner.log(f"manual analyze failed: {exchange}:{symbol_clean}: {exc}")
        return {"ok": False, "exchange": exchange, "symbol": symbol_clean, "signals": [], "skipped": 0, "error": "manual analysis failed"}

@app.get("/api/scan/status")
async def scan_status() -> dict[str, Any]:
    return {
        "status": scanner.status.model_dump(),
        "logs": list(scanner.logs)[:150],
        "runs": storage.latest_runs(12),
    }

@app.post("/api/loop/start")
async def start_loop() -> dict[str, Any]:
    await scanner.start_loop()
    return {"ok": True, "status": scanner.status.model_dump()}

@app.post("/api/loop/stop")
async def stop_loop() -> dict[str, Any]:
    await scanner.stop_loop()
    return {"ok": True, "status": scanner.status.model_dump()}

@app.get("/api/universe")
async def universe() -> dict[str, Any]:
    rows = await scanner.build_universe()
    return {"count": len(rows), "rows": rows}

@app.get("/api/early")
async def early(limit: int = Query(120, ge=1, le=500)) -> dict[str, Any]:
    rows = storage.latest_snapshots(limit)
    rows = [r for r in rows if (r.get("early_warning") or {}).get("level") in {"WATCH", "CONFIRMED", "TRAP"}]
    rows.sort(key=lambda r: (r.get("early_warning") or {}).get("final_score", 0), reverse=True)
    return {"rows": rows[:limit]}

@app.get("/api/live/state")
async def live_state(limit: int = Query(120, ge=1, le=500)) -> dict[str, Any]:
    early_rows = storage.latest_snapshots(limit)
    early_rows = [r for r in early_rows if (r.get("early_warning") or {}).get("level") in {"WATCH", "CONFIRMED", "TRAP"}]
    early_rows.sort(key=lambda r: (r.get("early_warning") or {}).get("final_score", 0), reverse=True)
    return {
        "status": scanner.status.model_dump(),
        "early": early_rows[:limit],
        "signals": storage.list_signals(limit=50, min_score=_default_visible_signal_score()),
        "runs": storage.latest_runs(10),
    }

@app.get("/api/snapshots")
async def snapshots(limit: int = Query(250, ge=1, le=500)) -> dict[str, Any]:
    return {"rows": storage.latest_snapshots(limit)}

@app.get("/api/skipped")
async def skipped(limit: int = Query(120, ge=1, le=500)) -> dict[str, Any]:
    return {"rows": storage.latest_skips(limit)}

@app.get("/api/signals")
async def signals(limit: int = Query(120, ge=1, le=1000), min_score: float | None = Query(None, ge=0, le=100), side: str | None = Query(None)) -> dict[str, Any]:
    if side is not None and side.upper() not in {"LONG", "SHORT"}:
        raise HTTPException(status_code=400, detail={"ok": False, "error": "invalid_side", "allowed": ["LONG", "SHORT"]})
    effective_min_score = _default_visible_signal_score() if min_score is None else min_score
    return {"rows": storage.list_signals(limit=limit, min_score=effective_min_score, side=side)}

@app.get("/api/dex/radar")
async def dex_radar() -> dict[str, Any]:
    try:
        return {"rows": await scanner.dex_radar()}
    except Exception as exc:  # noqa: BLE001
        scanner.log(f"DEX optional source failed: {exc}")
        return {"rows": [], "ok": False, "error": str(exc)}

@app.get("/api/coingecko/trending")
async def coingecko_trending() -> dict[str, Any]:
    try:
        return await scanner.coingecko_trending()
    except Exception as exc:  # noqa: BLE001
        scanner.log(f"CoinGecko optional source failed: {exc}")
        return {"fetched_at": "", "source": "coingecko", "ok": False, "error": str(exc), "data": {"coins": []}}

@app.get("/api/backtest/detailed/{symbol}")
async def backtest_detailed_file(symbol: str) -> dict[str, Any]:
    symbol_clean = _normalize_symbol(symbol)
    path = PROJECT_ROOT / "backtests_detailed" / f"{symbol_clean}.json"
    if not path.exists():
        raise HTTPException(status_code=404, detail={"ok": False, "error": "detailed backtest not found"})
    return json.loads(path.read_text(encoding="utf-8"))

@app.get("/api/backtest/{symbol}")
async def backtest(symbol: str, threshold: float = Query(78, ge=1, le=100), side: str = Query("SHORT")) -> dict[str, Any]:
    symbol_clean = _normalize_symbol(symbol)
    side_upper = side.upper().strip()
    if side_upper not in {"LONG", "SHORT", "BOTH"}:
        raise HTTPException(status_code=400, detail={"ok": False, "error": "invalid_side", "allowed": ["LONG", "SHORT", "BOTH"]})
    try:
        if side_upper == "BOTH":
            long_result = await scanner.quick_backtest(symbol=symbol_clean, threshold=threshold, side="LONG")
            short_result = await scanner.quick_backtest(symbol=symbol_clean, threshold=threshold, side="SHORT")
            return {"ok": True, "symbol": symbol_clean, "exchange": "binance-futures", "threshold": threshold, "side": "BOTH", "results": {"LONG": long_result, "SHORT": short_result}}
        result = await scanner.quick_backtest(symbol=symbol_clean, threshold=threshold, side=side_upper)
        result.setdefault("ok", True)
        return result
    except LiveDataError as exc:
        return {"ok": False, "symbol": symbol_clean, "exchange": "binance-futures", "threshold": threshold, "side": side_upper, "hits": 0, "rows": [], "error": str(exc)}
    except Exception as exc:  # noqa: BLE001
        scanner.log(f"backtest failed: {symbol_clean}: {exc}")
        return {"ok": False, "symbol": symbol_clean, "exchange": "binance-futures", "threshold": threshold, "side": side_upper, "hits": 0, "rows": [], "error": "backtest failed"}

@app.get("/api/export/signals.csv")
async def export_signals() -> StreamingResponse:
    rows = storage.list_signals(limit=10000, min_score=_default_visible_signal_score())
    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(["ts", "exchange", "symbol", "side", "score", "grade", "price", "quote_volume_24h", "price_change_24h", "funding_rate", "oi_change_pct", "taker_sell_pressure", "volume_spike", "spread_pct", "reasons"])
    for r in rows:
        writer.writerow([
            r.get("ts"), r.get("exchange"), r.get("symbol"), r.get("side"), r.get("score"), r.get("grade"), r.get("price"),
            r.get("quote_volume_24h"), r.get("price_change_24h"), r.get("funding_rate"), r.get("oi_change_pct"),
            r.get("taker_sell_pressure"), r.get("volume_spike"), r.get("spread_pct"), " | ".join(r.get("reasons") or []),
        ])
    out.seek(0)
    return StreamingResponse(iter([out.getvalue()]), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=live_crash_signals.csv"})

if FRONTEND_DIR.exists():
    app.mount("/assets", StaticFiles(directory=FRONTEND_DIR), name="assets")

@app.get("/", response_class=HTMLResponse)
async def index() -> str:
    index = FRONTEND_DIR / "index.html"
    return index.read_text(encoding="utf-8") if index.exists() else "<h1>Frontend not found</h1>"
