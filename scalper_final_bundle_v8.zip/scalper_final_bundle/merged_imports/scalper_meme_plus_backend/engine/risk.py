from __future__ import annotations
from .indicators import safe_float

def compute_dynamic_risk_pct(risk_pct: float, price: float, atr_value: float) -> float:
    """Dynamically adjust the risk percentage based on recent volatility.

    This helper scales the user-defined risk percentage up or down relative to the
    ratio of the ATR to the current price. Higher volatility (large ATR relative
    to price) means each position inherently has a wider stop distance, so the
    position size should shrink to maintain a similar absolute risk. Conversely,
    when volatility is very low, a modest increase to the risk percentage
    provides a reasonable position size. The adjustment factors are intentionally
    conservative to avoid unexpected spikes in risk. The returned value is
    bounded between 0.05 and 5.0 to respect the overall risk budget.

    Args:
        risk_pct: Baseline risk percentage (e.g. 0.5 for 0.5%).
        price: Current price of the instrument.
        atr_value: Average true range or other proxy for volatility.

    Returns:
        Adjusted risk percentage suitable for position sizing.
    """
    price = safe_float(price)
    atr_value = safe_float(atr_value)
    # Guard against division by zero and unrealistic inputs
    if price <= 0 or atr_value <= 0:
        return risk_pct
    # Volatility ratio expresses ATR as a fraction of price (e.g. 0.02 for 2% ATR)
    volatility_ratio = atr_value / price
    # Define thresholds for different volatility regimes
    if volatility_ratio >= 0.05:  # extremely high volatility (>5% ATR)
        return max(risk_pct * 0.5, 0.05)
    if volatility_ratio >= 0.03:  # high volatility (3–5% ATR)
        return max(risk_pct * 0.75, 0.05)
    if volatility_ratio <= 0.01:  # very low volatility (<1% ATR)
        return min(risk_pct * 1.2, 5.0)
    # moderate volatility: no change
    return risk_pct


def build_trade_plan(side: str, price: float, atr_value: float, capital: float, risk_pct: float, leverage: float) -> dict:
    price = safe_float(price)
    atr_value = safe_float(atr_value)
    if price <= 0:
        return {}
    # Dynamically adjust risk percentage based on volatility to protect capital
    adj_risk_pct = compute_dynamic_risk_pct(risk_pct, price, atr_value)
    stop_distance = max(atr_value * 1.35, price * 0.018)
    risk_usdt = max(0.0, capital * (adj_risk_pct / 100.0))
    qty = risk_usdt / stop_distance if stop_distance > 0 else 0.0
    notional = qty * price
    margin = notional / leverage if leverage > 0 else notional
    # Reward-to-risk multipliers for partial exits
    rr = [1.0, 1.7, 2.6]
    if side.upper() == "SHORT":
        entry_zone = [price * 0.998, price * 1.004]
        stop = price + stop_distance
        targets = [price - stop_distance * x for x in rr]
        invalidation = (
            "کندل ۵m بالای VWAP/EMA20 تثبیت شود، یا اسپرد/عمق اجرای واقعی بدتر از آستانه شود."
        )
    else:
        entry_zone = [price * 0.996, price * 1.002]
        stop = price - stop_distance
        targets = [price + stop_distance * x for x in rr]
        invalidation = (
            "کندل ۵m زیر VWAP/EMA20 تثبیت شود، یا اسپرد/عمق اجرای واقعی بدتر از آستانه شود."
        )
    return {
        "entry_zone": [round(max(x, 0.0), 10) for x in entry_zone],
        "stop": round(max(stop, 0.0), 10),
        "tp1": round(max(targets[0], 0.0), 10),
        "tp2": round(max(targets[1], 0.0), 10),
        "tp3": round(max(targets[2], 0.0), 10),
        "risk_usdt": round(risk_usdt, 4),
        "position_qty": round(qty, 6),
        "notional_usdt": round(notional, 2),
        "est_margin_usdt": round(margin, 2),
        "leverage_cap": leverage,
        "risk_note": "فقط برنامه‌ریزی آموزشی و هشدار است؛ هیچ سفارشی به صرافی ارسال نمی‌شود.",
        "invalidation": invalidation,
    }
