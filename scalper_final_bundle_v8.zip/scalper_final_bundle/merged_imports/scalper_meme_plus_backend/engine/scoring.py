from __future__ import annotations
from typing import Any
from .indicators import clamp, safe_float
from .risk import build_trade_plan
from .binance_microstructure import derive_microstructure
from .multisource_confidence import derive_chart_confirmation, derive_cross_feed_validation, derive_liquidity_tier, derive_model_confidence, derive_news_risk


def grade(score: float) -> str:
    if score >= 90: return "A+"
    if score >= 82: return "A"
    if score >= 72: return "B"
    if score >= 62: return "C"
    return "D"


def add(condition: bool, points: float, text: str, score: float, reasons: list[str]) -> float:
    if condition:
        reasons.append(text)
        return score + points
    return score


def _is_lbank(metrics: dict[str, Any]) -> bool:
    return str(metrics.get("exchange", "")).lower().startswith("lbank")


def hard_gates(metrics: dict[str, Any], settings: Any, side: str) -> dict[str, bool]:
    price = safe_float(metrics.get("price"))
    price_change_24h = safe_float(metrics.get("price_change_24h"))
    drawdown = safe_float(metrics.get("drawdown_from_24h_high_pct"))
    spread = safe_float(metrics.get("spread_pct"), 999)
    quote_volume = safe_float(metrics.get("quote_volume_24h"))
    min_volume_gate = safe_float(metrics.get("min_quote_volume_gate"), safe_float(getattr(settings, "min_quote_volume", 0)))
    micro = metrics.get("binance_microstructure") or derive_microstructure(metrics, settings)
    max_spread_gate = safe_float(micro.get("dynamic_spread_gate_pct"), safe_float(metrics.get("max_spread_pct_gate"), safe_float(getattr(settings, "max_spread_pct", 999))))
    min_depth_gate = safe_float(micro.get("dynamic_depth_gate_usdt"), safe_float(metrics.get("min_depth_1pct_usd_gate"), 0))
    depth_1pct = safe_float(metrics.get("depth_1pct_usd"))
    vspike = max(safe_float(metrics.get("volume_spike"), 1), safe_float(metrics.get("quote_volume_spike"), 1))
    low_break = bool(metrics.get("low_break_5m"))
    high_break = bool(metrics.get("high_break_5m"))
    below_vwap = bool(metrics.get("below_vwap_5m"))
    above_vwap = bool(metrics.get("above_vwap_5m"))
    required_sources_ok = bool(metrics.get("required_sources_ok", False))
    fresh_ok = bool(metrics.get("data_fresh_ok", False))
    rsi5 = safe_float(metrics.get("rsi_5m"), 50)
    change_15m = safe_float(metrics.get("change_15m"))
    change_1h = safe_float(metrics.get("change_1h"))
    atr_pct = (safe_float(metrics.get("atr_5m")) / price * 100.0) if price > 0 else 999.0
    planned_stop_pct = max(atr_pct * 1.35, 1.8)
    market = metrics.get("market_context") or {}
    btc_overheated = bool(market.get("btc_overbought_low_volume"))
    btc_required_vspike = safe_float(getattr(settings, "btc_overbought_required_volume_spike", 1.7))

    # Research-applied gates: liquidity, execution quality, clear price/volume trigger,
    # market-regime agreement, and anti-late-chase filters must pass before publishing.
    strong_venue_flow = quote_volume >= (min_volume_gate * 3.0) and abs(price_change_24h) >= 12.0
    volume_ok = vspike >= settings.min_volume_spike_for_trigger or strong_venue_flow

    if side == "SHORT":
        trigger_ok = (low_break or change_15m <= -2.0 or price_change_24h <= -10.0 or drawdown >= 12.0) and below_vwap
        late_chase_ok = change_1h >= -abs(safe_float(getattr(settings, "max_short_chase_1h_pct", 8.0))) and rsi5 >= safe_float(getattr(settings, "min_short_rsi_5m", 28.0))
        regime_ok = (not getattr(settings, "market_regime_filter", True)) or market.get("bias") != "risk_on" or bool(metrics.get("trend_bearish_1h"))
    else:
        trigger_ok = (high_break or change_15m >= 2.0 or price_change_24h >= 10.0) and above_vwap
        late_chase_ok = change_1h <= safe_float(getattr(settings, "max_long_chase_1h_pct", 6.0)) and rsi5 <= safe_float(getattr(settings, "max_long_rsi_5m", 72.0))
        regime_ok = (not getattr(settings, "market_regime_filter", True)) or market.get("bias") != "risk_off" or bool(metrics.get("trend_bullish_1h"))

    extreme_chase_ok = not (side == "LONG" and change_1h > safe_float(getattr(settings, "hard_block_long_if_1h_move_above", 12.0)))
    btc_context_ok = not (side == "LONG" and btc_overheated and vspike < btc_required_vspike)
    premium_ok = bool(micro.get("mark_index_premium_ok", True)) or not bool(getattr(settings, "use_mark_index_premium", True))
    buy_ratio = micro.get("taker_buy_ratio")
    if buy_ratio is None or not bool(getattr(settings, "use_taker_flow_score", True)):
        taker_flow_ok = True
    elif side == "LONG":
        taker_flow_ok = safe_float(buy_ratio) >= safe_float(getattr(settings, "min_taker_buy_ratio_for_long", 0.55))
    else:
        taker_flow_ok = safe_float(buy_ratio) <= safe_float(getattr(settings, "max_taker_buy_ratio_for_short", 0.45))

    chart = metrics.get("chart_confirmation") or derive_chart_confirmation(metrics, settings)
    if not bool(getattr(settings, "use_chart_confirmation", True)):
        chart_ok = True
    elif side == "LONG":
        chart_ok = bool(chart.get("long_confirmed", False))
    else:
        chart_ok = bool(chart.get("short_confirmed", False))
    news = metrics.get("news_risk") or derive_news_risk(metrics, settings)
    news_ok = not (bool(getattr(settings, "security_issue_hard_block", True)) and bool(news.get("security_issue", False)))
    cross = metrics.get("cross_feed_validation") or derive_cross_feed_validation(metrics, settings)
    cross_ok = (not cross.get("available", False)) or bool(cross.get("ok", True))

    return {
        "live_required_sources_ok": required_sources_ok,
        "data_fresh_ok": fresh_ok,
        "price_ok": price > 0,
        "liquidity_ok": quote_volume >= min_volume_gate,
        "execution_spread_ok": spread <= max_spread_gate,
        "depth_1pct_ok": depth_1pct >= min_depth_gate,
        "mark_index_premium_ok": premium_ok,
        "taker_flow_ok": taker_flow_ok,
        "chart_confirmation_ok": chart_ok,
        "news_security_ok": news_ok,
        "cross_feed_ok": cross_ok,
        "volume_trigger_ok": volume_ok,
        "technical_trigger_ok": trigger_ok,
        "market_regime_ok": regime_ok,
        "anti_late_chase_ok": late_chase_ok,
        "anti_extreme_chase_ok": extreme_chase_ok,
        "btc_overbought_volume_ok": btc_context_ok,
        "risk_plan_stop_ok": planned_stop_pct <= safe_float(getattr(settings, "max_stop_distance_pct", 5.5)),
    }


# Gates that must stay hard for a real, usable educational signal.  Market regime and
# anti-late-chase are intentionally left as score penalties/warnings rather than absolute
# blockers in the default profile; otherwise the app can scan a live market and still show
# zero signals for long periods even when the core data, execution quality and trigger are OK.
CRITICAL_SIGNAL_GATES = {
    "live_required_sources_ok",
    "data_fresh_ok",
    "price_ok",
    "liquidity_ok",
    "execution_spread_ok",
    "depth_1pct_ok",
    "mark_index_premium_ok",
    "volume_trigger_ok",
    "technical_trigger_ok",
    "anti_extreme_chase_ok",
    "news_security_ok",
    "risk_plan_stop_ok",
}


def publish_gates_ok(gates: dict[str, bool]) -> bool:
    """Return True when all publication-critical gates pass.

    The full gate dictionary is still stored with each signal/snapshot so the UI can show
    non-critical warnings. This avoids the previous all-or-nothing behavior where one soft
    context gate could prevent every signal from ever reaching the Signals page.
    """
    optional_default_true = {"mark_index_premium_ok", "news_security_ok"}
    return all(bool(gates.get(name, True if name in optional_default_true else False)) for name in CRITICAL_SIGNAL_GATES)



def _apply_multisource_adjustments(side: str, score: float, reasons: list[str], warnings: list[str], metrics: dict[str, Any], settings: Any) -> float:
    chart = metrics.get("chart_confirmation") or derive_chart_confirmation(metrics, settings)
    news = metrics.get("news_risk") or derive_news_risk(metrics, settings)
    liquidity = metrics.get("liquidity_tier") or derive_liquidity_tier(metrics, settings)
    cross = metrics.get("cross_feed_validation") or derive_cross_feed_validation(metrics, settings)
    confidence = metrics.get("model_confidence") or derive_model_confidence(metrics, settings)

    if bool(getattr(settings, "use_chart_confirmation", True)):
        confirmed = bool(chart.get("long_confirmed" if side == "LONG" else "short_confirmed", False))
        if confirmed:
            score += 5
            reasons.append("Multi-source chart confirmation")
        else:
            score -= 4
            warnings.append("TickerSage-style chart confirmation is not strong enough; signal remains more conservative.")
        if chart.get("overextended_long") and side == "LONG":
            score -= 5
        if chart.get("overextended_short") and side == "SHORT":
            score -= 5

    if bool(getattr(settings, "news_risk_penalty_enabled", True)):
        if news.get("security_issue"):
            score -= safe_float(getattr(settings, "negative_news_penalty", 8.0))
            warnings.append("Kraken-style news risk found security/delisting/exploit keywords; risk increased.")
        elif safe_float(news.get("positive_bonus"), 0) > 0:
            bonus = min(safe_float(getattr(settings, "positive_narrative_bonus", 4.0)), safe_float(news.get("positive_bonus"), 0))
            score += bonus
            reasons.append("Positive narrative/news context")

    if bool(getattr(settings, "use_liquidity_tier", True)):
        if liquidity.get("major_asset"):
            score += safe_float(getattr(settings, "major_asset_stability_bonus", 3.0))
            reasons.append("RealOpen-style tier-1 liquidity asset")
        elif liquidity.get("tier") == "thin":
            score -= safe_float(getattr(settings, "unknown_microcap_risk_penalty", 6.0))
            warnings.append("Unknown/thin-liquidity microcap tier; size and slippage risk increased.")

    if bool(getattr(settings, "use_alpaca_cross_feed_validation", True)) and cross.get("available") and not cross.get("ok", True):
        score -= safe_float(getattr(settings, "cross_feed_disagreement_penalty", 7.0))
        warnings.append("Alpaca-style cross-feed validation disagrees on price/spread; execution risk increased.")

    if confidence.get("level") == "LOW":
        warnings.append("Multi-source model confidence is LOW; treat as watch/small-size simulation only.")
    return score

def score_short(metrics: dict[str, Any], settings: Any) -> tuple[float, list[str], list[str], dict[str, bool]]:
    reasons: list[str] = []
    warnings: list[str] = []
    score = 0.0
    price_change_24h = safe_float(metrics.get("price_change_24h"))
    change_15m = safe_float(metrics.get("change_15m"))
    change_1h = safe_float(metrics.get("change_1h"))
    rsi5 = safe_float(metrics.get("rsi_5m"), 50)
    rsi15 = safe_float(metrics.get("rsi_15m"), 50)
    vspike = safe_float(metrics.get("volume_spike"), 1)
    qvspike = safe_float(metrics.get("quote_volume_spike"), 1)
    cvd_raw = metrics.get("cvd_proxy")
    taker_raw = metrics.get("taker_sell_pressure")
    oi_raw = metrics.get("oi_change_pct")
    funding_raw = metrics.get("funding_rate")
    cvd = safe_float(cvd_raw) if cvd_raw is not None else None
    taker_sell = safe_float(taker_raw) if taker_raw is not None else None
    oi_change = safe_float(oi_raw) if oi_raw is not None else None
    funding = safe_float(funding_raw) if funding_raw is not None else None
    spread = safe_float(metrics.get("spread_pct"), 999)
    ask_imbalance = safe_float(metrics.get("ask_bid_imbalance"))
    near_24h_low_pct = safe_float(metrics.get("near_24h_low_pct"), 999)
    drawdown = safe_float(metrics.get("drawdown_from_24h_high_pct"))
    market = metrics.get("market_context") or {}
    micro = metrics.get("binance_microstructure") or derive_microstructure(metrics, settings)
    buy_ratio = micro.get("taker_buy_ratio")
    premium_pct = micro.get("mark_index_premium_pct")

    score = add(bool(metrics.get("trend_bearish_15m")), 13, "رژیم ۱۵m نزولی", score, reasons)
    score = add(bool(metrics.get("trend_bearish_1h")), 9, "رژیم ۱h نزولی", score, reasons)
    score = add(bool(metrics.get("below_vwap_5m")), 9, "قیمت زیر VWAP زنده", score, reasons)
    score = add(bool(metrics.get("low_break_5m")), 13, "شکست کف اخیر", score, reasons)
    score = add(change_15m <= -2.0, 9, "ریزش تند ۱۵ دقیقه", score, reasons)
    score = add(change_1h <= -4.0, 7, "فشار فروش یک‌ساعته", score, reasons)
    score = add(max(vspike, qvspike) >= 1.65, 8, "جهش حجم نسبت به میانه", score, reasons)
    score = add(max(vspike, qvspike) >= 3.0, 5, "اسپایک حجم شدید", score, reasons)
    if cvd is not None:
        score = add(cvd <= -0.10, 8, "CVD تقریبی منفی", score, reasons)
    if taker_sell is not None:
        score = add(taker_sell >= 0.56, 8, "Taker Sell غالب", score, reasons)
    if buy_ratio is not None:
        score = add(safe_float(buy_ratio) <= safe_float(getattr(settings, "max_taker_buy_ratio_for_short", 0.45)), 5, "Binance Taker Flow به نفع شورت", score, reasons)
    score = add(rsi5 < 43 and rsi15 < 49, 7, "RSI ضعیف", score, reasons)
    score = add(price_change_24h <= -7, 6, "۲۴h قرمز", score, reasons)
    score = add(price_change_24h <= -12, 6, "ریزش سنگین ۲۴h", score, reasons)
    score = add(drawdown >= 12, 7, "فاصله زیاد از سقف ۲۴h", score, reasons)
    score = add(drawdown >= 25, 5, "تخلیه شدید از سقف ۲۴h", score, reasons)
    score = add(near_24h_low_pct <= 12.0, 5, "قیمت نزدیک کف ۲۴h", score, reasons)
    if oi_change is not None:
        score = add(oi_change >= 4 and change_15m < 0, 10, "OI افزایشی همراه ریزش", score, reasons)
        score = add(oi_change <= -4 and change_15m < 0, 7, "OI تخلیه‌شونده همراه ریزش", score, reasons)
    if funding is not None:
        score = add(funding > 0.00015 and change_15m < 0, 6, "Funding مثبت در ریزش", score, reasons)
        if bool(getattr(settings, "crowded_funding_penalty_enabled", True)) and funding < -safe_float(getattr(settings, "crowded_funding_abs_threshold", 0.00025)):
            score -= 4
            warnings.append("Funding خیلی منفی است؛ شورت می‌تواند crowded و مستعد squeeze باشد.")
    if premium_pct is not None and not micro.get("mark_index_premium_ok", True):
        score -= 6
        warnings.append("اختلاف Mark/Index غیرعادی است؛ ریسک اجرای Binance بالاتر است.")
    score = add(ask_imbalance > 0.15, 5, "فشار سمت Ask در Order Book", score, reasons)
    score = add(market.get("bias") == "risk_off", 5, "رژیم کلی بازار Risk-Off", score, reasons)

    if market.get("bias") == "risk_on":
        score -= 5
        warnings.append("بازار کلی Risk-On است؛ شورت روی آلت کم‌عمق ریسک اسکوئیز دارد.")
    if rsi5 < 22 and change_1h < -9:
        score -= 9
        warnings.append("حرکت خیلی کشیده شده؛ ورود دیرهنگام ریسک پولبک دارد.")
    max_spread_gate = safe_float(micro.get("dynamic_spread_gate_pct"), safe_float(metrics.get("max_spread_pct_gate"), safe_float(getattr(settings, "max_spread_pct", 999))))
    if spread > max_spread_gate:
        score -= 12
        warnings.append("اسپرد از آستانه اجرای واقعی این Venue بالاتر است.")
    min_volume_gate = safe_float(metrics.get("min_quote_volume_gate"), safe_float(getattr(settings, "min_quote_volume", 0)))
    if safe_float(metrics.get("quote_volume_24h")) < min_volume_gate * 1.2:
        score -= 4
        warnings.append("حجم ۲۴h نزدیک حداقل فیلتر همان Venue است.")
    if _is_lbank(metrics) and (cvd_raw is None or taker_raw is None or oi_raw is None):
        warnings.append("بخشی از مشتقات LBank عمومی/قابل‌اتکا نبود؛ امتیاز فقط از داده واقعی قیمت/حجم/عمق همان Venue ساخته شده.")

    score = _apply_multisource_adjustments("SHORT", score, reasons, warnings, metrics, settings)
    gates = hard_gates(metrics, settings, "SHORT")
    if not gates.get("anti_late_chase_ok", True):
        score -= safe_float(getattr(settings, "anti_chase_penalty", 8.0))
        warnings.append("حرکت شورت کشیده شده؛ اندازه پوزیشن/ورود باید محافظه‌کارانه‌تر باشد.")
    if not gates.get("market_regime_ok", True):
        score -= 6
        warnings.append("رژیم بازار با جهت شورت همسو نیست.")
    if not gates.get("risk_plan_stop_ok", True):
        score -= 8
        warnings.append("فاصله Stop نسبت به قیمت برای اسکالپ زیاد است.")
    if not publish_gates_ok(gates):
        warnings.append("یکی از Gateهای حیاتی داده/اجرا/تریگر پاس نشده و سیگنال منتشر نمی‌شود.")
    elif not all(gates.values()):
        warnings.append("چند Gate زمینه‌ای/نرم کامل نیست؛ سیگنال با هشدار و مدیریت ریسک سخت‌گیرانه‌تر نمایش داده می‌شود.")
    return clamp(score), reasons, warnings, gates


def score_long(metrics: dict[str, Any], settings: Any) -> tuple[float, list[str], list[str], dict[str, bool]]:
    reasons: list[str] = []
    warnings: list[str] = []
    score = 0.0
    change_15m = safe_float(metrics.get("change_15m"))
    change_1h = safe_float(metrics.get("change_1h"))
    rsi5 = safe_float(metrics.get("rsi_5m"), 50)
    vspike = safe_float(metrics.get("volume_spike"), 1)
    qvspike = safe_float(metrics.get("quote_volume_spike"), 1)
    cvd_raw = metrics.get("cvd_proxy")
    taker_raw = metrics.get("taker_sell_pressure")
    funding_raw = metrics.get("funding_rate")
    oi_raw = metrics.get("oi_change_pct")
    cvd = safe_float(cvd_raw) if cvd_raw is not None else None
    taker_sell = safe_float(taker_raw) if taker_raw is not None else None
    funding = safe_float(funding_raw) if funding_raw is not None else None
    oi_change = safe_float(oi_raw) if oi_raw is not None else None
    spread = safe_float(metrics.get("spread_pct"), 999)
    ask_imbalance = safe_float(metrics.get("ask_bid_imbalance"))
    market = metrics.get("market_context") or {}
    micro = metrics.get("binance_microstructure") or derive_microstructure(metrics, settings)
    buy_ratio = micro.get("taker_buy_ratio")
    premium_pct = micro.get("mark_index_premium_pct")

    score = add(bool(metrics.get("trend_bullish_15m")), 12, "رژیم ۱۵m صعودی", score, reasons)
    score = add(bool(metrics.get("above_vwap_5m")), 10, "قیمت بالای VWAP زنده", score, reasons)
    score = add(bool(metrics.get("high_break_5m")), 12, "شکست سقف اخیر", score, reasons)
    score = add(change_15m >= 2.0, 8, "مومنتوم ۱۵ دقیقه مثبت", score, reasons)
    score = add(change_1h >= 3.5, 7, "مومنتوم یک‌ساعته مثبت", score, reasons)
    score = add(max(vspike, qvspike) >= 1.65, 9, "جهش حجم نسبت به میانه", score, reasons)
    if cvd is not None:
        score = add(cvd >= 0.10, 8, "CVD تقریبی مثبت", score, reasons)
    if taker_sell is not None:
        score = add(taker_sell <= 0.44, 7, "Taker Buy غالب", score, reasons)
    if buy_ratio is not None:
        score = add(safe_float(buy_ratio) >= safe_float(getattr(settings, "min_taker_buy_ratio_for_long", 0.55)), 5, "Binance Taker Flow به نفع لانگ", score, reasons)
    score = add(rsi5 > 52, 5, "RSI برگشتی/قوی", score, reasons)
    if funding is not None:
        score = add(funding < -0.00015 and change_15m >= 0, 7, "Funding منفی؛ احتمال Short Squeeze", score, reasons)
        if bool(getattr(settings, "crowded_funding_penalty_enabled", True)) and funding > safe_float(getattr(settings, "crowded_funding_abs_threshold", 0.00025)):
            score -= 5
            warnings.append("Funding خیلی مثبت است؛ لانگ crowded و مستعد trap است.")
    if premium_pct is not None and not micro.get("mark_index_premium_ok", True):
        score -= 6
        warnings.append("اختلاف Mark/Index غیرعادی است؛ ریسک اجرای Binance بالاتر است.")
    if oi_change is not None:
        score = add(oi_change >= 4 and change_15m > 0, 8, "OI افزایشی همراه رشد", score, reasons)
    score = add(ask_imbalance < -0.15, 5, "حمایت Bid در Order Book", score, reasons)
    score = add(market.get("bias") == "risk_on", 4, "رژیم کلی بازار Risk-On", score, reasons)
    if market.get("bias") == "risk_off":
        score -= 5
        warnings.append("بازار کلی Risk-Off است؛ لانگ فقط با تأیید قوی معتبر است.")
    if market.get("btc_overbought_low_volume"):
        req_vspike = safe_float(getattr(settings, "btc_overbought_required_volume_spike", 1.7))
        if max(vspike, qvspike) < req_vspike:
            score -= safe_float(getattr(settings, "btc_overbought_long_penalty", 6.0))
            warnings.append(f"BTC در محدوده overbought با حجم ضعیف است؛ لانگ فقط با Volume Spike بالای {req_vspike:.2f} معتبرتر است.")
    if market.get("btc_macd_bearish"):
        score -= safe_float(getattr(settings, "btc_macd_bearish_long_penalty", 4.0))
        warnings.append("MACD زمینه‌ای BTC ضعیف/منفی است؛ لانگ‌های میم‌کوین با احتیاط بیشتر.")
    if rsi5 > 78 and change_1h > 8:
        score -= 9
        warnings.append("رشد کشیده شده؛ لانگ دیرهنگام خطرناک است.")
    max_spread_gate = safe_float(micro.get("dynamic_spread_gate_pct"), safe_float(metrics.get("max_spread_pct_gate"), safe_float(getattr(settings, "max_spread_pct", 999))))
    if spread > max_spread_gate:
        score -= 12
        warnings.append("اسپرد از آستانه اجرای واقعی این Venue بالاتر است.")
    score = _apply_multisource_adjustments("LONG", score, reasons, warnings, metrics, settings)
    gates = hard_gates(metrics, settings, "LONG")
    if not gates.get("anti_late_chase_ok", True):
        score -= safe_float(getattr(settings, "anti_chase_penalty", 8.0))
        warnings.append("لانگ بعد از پامپ/RSI کشیده است؛ ورود در سقف محلی محتمل است.")
    if not gates.get("anti_extreme_chase_ok", True):
        score -= 15
        warnings.append("پامپ یک‌ساعته خیلی شدید است؛ سیگنال اصلی برای جلوگیری از FOMO منتشر نمی‌شود.")
    if not gates.get("btc_overbought_volume_ok", True):
        warnings.append("BTC overbought + volume ضعیف: این Gate نرم است و فقط سطح ریسک لانگ را بالا می‌برد.")
    if not gates.get("market_regime_ok", True):
        score -= 7
        warnings.append("رژیم بازار با جهت لانگ همسو نیست.")
    if not gates.get("risk_plan_stop_ok", True):
        score -= 8
        warnings.append("فاصله Stop نسبت به قیمت برای اسکالپ زیاد است.")
    if not publish_gates_ok(gates):
        warnings.append("یکی از Gateهای حیاتی داده/اجرا/تریگر پاس نشده و سیگنال منتشر نمی‌شود.")
    elif not all(gates.values()):
        warnings.append("چند Gate زمینه‌ای/نرم کامل نیست؛ سیگنال با هشدار و مدیریت ریسک سخت‌گیرانه‌تر نمایش داده می‌شود.")
    return clamp(score), reasons, warnings, gates


def channel_text(signal: dict[str, Any]) -> str:
    side = signal.get("side")
    symbol = signal.get("symbol", "").replace("USDT", "")
    plan = signal.get("plan", {}) or {}
    lev = plan.get("leverage_cap", 3)
    direction = "ریزش" if side == "SHORT" else "رشد"
    emoji = "🔴" if side == "SHORT" else "🟢"
    entry = plan.get("entry_zone", [])
    entry_txt = f"{entry[0]} - {entry[1]}" if isinstance(entry, list) and len(entry) == 2 else "market review"
    return (
        f"{emoji} Signal: {side} #{symbol}\n"
        f"Bias: {direction} - فقط بعد از پاس شدن گیت‌های داده/اجرا\n"
        f"Entry Zone: {entry_txt}\n"
        f"Invalidation/SL: {plan.get('stop')}\n"
        f"Targets: {plan.get('tp1')} / {plan.get('tp2')} / {plan.get('tp3')}\n"
        f"Leverage Cap: {lev}X isolated\n"
        f"Risk: {plan.get('risk_usdt')} USDT | Score: {signal.get('score')} | Grade: {signal.get('grade')}\n"
        f"#{side}{emoji}"
    )


def build_signal(ts: str, symbol: str, side: str, score: float, reasons: list[str], warnings: list[str], gates: dict[str, bool], metrics: dict[str, Any], settings: Any) -> dict[str, Any]:
    sig = {
        "ts": ts,
        "symbol": symbol,
        "exchange": metrics.get("exchange", "binance-futures"),
        "side": side,
        "score": round(score, 2),
        "grade": grade(score),
        "price": safe_float(metrics.get("price")),
        "quote_volume_24h": safe_float(metrics.get("quote_volume_24h")),
        "price_change_24h": safe_float(metrics.get("price_change_24h")),
        "funding_rate": metrics.get("funding_rate"),
        "oi_change_pct": metrics.get("oi_change_pct"),
        "taker_sell_pressure": metrics.get("taker_sell_pressure"),
        "volume_spike": safe_float(metrics.get("volume_spike")),
        "spread_pct": safe_float(metrics.get("spread_pct")),
        "reasons": reasons[:14],
        "warnings": warnings[:10],
        "hard_gates": gates,
        "plan": build_trade_plan(side, safe_float(metrics.get("price")), safe_float(metrics.get("atr_5m")), settings.capital_usdt, settings.risk_per_trade_pct, settings.leverage),
        "metrics": metrics,
        "sources": metrics.get("sources", {}),
    }
    sig["channel_text"] = channel_text(sig)
    return sig
