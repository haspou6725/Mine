from __future__ import annotations

from typing import Any

from .indicators import clamp, safe_float

MAJOR_LIQUIDITY_ASSETS = {"BTC", "ETH", "BNB", "SOL", "XRP", "ADA", "MATIC", "USDT", "USDC"}
SECURITY_RISK_KEYWORDS = ("hack", "exploit", "security", "breach", "delist", "halt", "rug", "scam")
POSITIVE_NARRATIVE_KEYWORDS = ("listing", "etf", "partnership", "upgrade", "mainnet", "inflow", "adoption")


def base_asset(symbol: str | None) -> str:
    value = (symbol or "").upper().replace("-", "").replace("/", "")
    for quote in ("USDT", "USDC", "USD", "BUSD", "FDUSD"):
        if value.endswith(quote) and len(value) > len(quote):
            return value[: -len(quote)]
    return value


def derive_chart_confirmation(metrics: dict[str, Any], settings: Any | None = None) -> dict[str, Any]:
    """TickerSage-style chart confirmation computed from in-project live candles.

    The external chart tool is useful for visual validation, but the scanner must remain
    deterministic and testable.  This function mirrors that layer with EMA/VWAP/RSI/MACD-like
    evidence already present in the scanner metrics.
    """
    rsi = safe_float(metrics.get("rsi_5m"), 50.0)
    change_15m = safe_float(metrics.get("change_15m"))
    change_1h = safe_float(metrics.get("change_1h"))
    vspike = max(safe_float(metrics.get("volume_spike"), 1.0), safe_float(metrics.get("quote_volume_spike"), 1.0))
    long_points = 0.0
    short_points = 0.0
    reasons: list[str] = []
    warnings: list[str] = []

    if metrics.get("trend_bullish_15m"):
        long_points += 22
        reasons.append("EMA/VWAP context bullish")
    if metrics.get("trend_bearish_15m"):
        short_points += 22
        reasons.append("EMA/VWAP context bearish")
    if metrics.get("above_vwap_5m"):
        long_points += 14
    if metrics.get("below_vwap_5m"):
        short_points += 14
    if metrics.get("high_break_5m"):
        long_points += 18
    if metrics.get("low_break_5m"):
        short_points += 18
    if change_15m >= 1.5:
        long_points += 10
    if change_15m <= -1.5:
        short_points += 10
    if vspike >= safe_float(getattr(settings, "chart_min_volume_spike", 1.35), 1.35):
        long_points += 10
        short_points += 10
    if 52 <= rsi <= safe_float(getattr(settings, "max_long_rsi_5m", 74), 74):
        long_points += 8
    if safe_float(getattr(settings, "min_short_rsi_5m", 26), 26) <= rsi <= 48:
        short_points += 8

    overextended_long = rsi >= safe_float(getattr(settings, "chart_bollinger_overextension_rsi", 78), 78) or change_1h > safe_float(getattr(settings, "hard_block_long_if_1h_move_above", 12), 12)
    overextended_short = rsi <= safe_float(getattr(settings, "chart_short_overextension_rsi", 22), 22) or change_1h < -safe_float(getattr(settings, "max_short_chase_1h_pct", 8.5), 8.5)
    if overextended_long:
        long_points -= 18
        warnings.append("Chart overextension: long is at higher FOMO risk")
    if overextended_short:
        short_points -= 18
        warnings.append("Chart overextension: short is at higher squeeze risk")

    long_score = clamp(long_points)
    short_score = clamp(short_points)
    return {
        "enabled": bool(getattr(settings, "use_chart_confirmation", True)),
        "long_score": round(long_score, 2),
        "short_score": round(short_score, 2),
        "long_confirmed": long_score >= safe_float(getattr(settings, "chart_confirmation_min_score", 55), 55),
        "short_confirmed": short_score >= safe_float(getattr(settings, "chart_confirmation_min_score", 55), 55),
        "overextended_long": bool(overextended_long),
        "overextended_short": bool(overextended_short),
        "reasons": reasons[:8],
        "warnings": warnings[:6],
    }


def derive_liquidity_tier(metrics: dict[str, Any], settings: Any | None = None) -> dict[str, Any]:
    asset = base_asset(metrics.get("symbol"))
    qv = safe_float(metrics.get("quote_volume_24h"))
    depth = safe_float(metrics.get("depth_1pct_usd"))
    major = asset in set(getattr(settings, "tier_1_assets", MAJOR_LIQUIDITY_ASSETS))
    if major:
        tier = "tier_1"
        score = 82
    elif qv >= 100_000_000 and depth >= 250_000:
        tier = "tier_2"
        score = 72
    elif qv >= 10_000_000 and depth >= 75_000:
        tier = "tier_3"
        score = 58
    elif qv >= safe_float(getattr(settings, "min_quote_volume", 650_000), 650_000):
        tier = "microcap_liquid"
        score = 43
    else:
        tier = "thin"
        score = 25
    return {"enabled": bool(getattr(settings, "use_liquidity_tier", True)), "asset": asset, "tier": tier, "score": score, "major_asset": major, "quote_volume_24h": qv, "depth_1pct_usd": depth}


def derive_news_risk(metrics: dict[str, Any], settings: Any | None = None) -> dict[str, Any]:
    """Kraken-style narrative/news risk container.

    Live Kraken news is deliberately not required for publishing.  When an external news client
    writes headlines/summaries into metrics['news_context'], this function scores them; otherwise
    it returns a neutral, transparent unavailable state.
    """
    ctx = metrics.get("news_context") or metrics.get("kraken_news_context") or {}
    texts: list[str] = []
    if isinstance(ctx, dict):
        for key in ("headline", "summary", "narrative", "risk", "source_summary"):
            value = ctx.get(key)
            if isinstance(value, str):
                texts.append(value)
        for item in ctx.get("items", []) if isinstance(ctx.get("items"), list) else []:
            if isinstance(item, dict):
                texts.extend(str(item.get(k, "")) for k in ("title", "summary"))
    joined = " ".join(texts).lower()
    security_hits = [kw for kw in SECURITY_RISK_KEYWORDS if kw in joined]
    positive_hits = [kw for kw in POSITIVE_NARRATIVE_KEYWORDS if kw in joined]
    risk_score = min(100, len(security_hits) * 28)
    bonus_score = min(20, len(positive_hits) * 4)
    level = "UNAVAILABLE" if not texts else ("HIGH" if risk_score >= 50 else "MEDIUM" if risk_score >= 25 else "LOW")
    return {
        "enabled": bool(getattr(settings, "use_kraken_news_context", True)),
        "available": bool(texts),
        "level": level,
        "risk_score": risk_score,
        "positive_bonus": bonus_score,
        "security_issue": bool(security_hits),
        "risk_keywords": security_hits,
        "positive_keywords": positive_hits,
        "message": "neutral: no live news context attached" if not texts else "scored from attached news context",
    }


def derive_cross_feed_validation(metrics: dict[str, Any], settings: Any | None = None) -> dict[str, Any]:
    """Alpaca-style secondary feed validation.

    The scanner can attach an external quote under metrics['cross_feed'].  Missing secondary feed
    is neutral by default; disagreement raises execution risk without inventing market data.
    """
    cf = metrics.get("cross_feed") or metrics.get("alpaca_cross_feed") or {}
    price = safe_float(metrics.get("price"))
    bid = safe_float(cf.get("bid_price")) if isinstance(cf, dict) else 0.0
    ask = safe_float(cf.get("ask_price")) if isinstance(cf, dict) else 0.0
    ref_price = safe_float(cf.get("price") or ((bid + ask) / 2.0 if bid > 0 and ask > 0 else 0.0)) if isinstance(cf, dict) else 0.0
    if not isinstance(cf, dict) or ref_price <= 0 or price <= 0:
        return {"enabled": bool(getattr(settings, "use_alpaca_cross_feed_validation", True)), "available": False, "risk_level": "UNAVAILABLE", "price_deviation_pct": None, "spread_pct": None, "ok": True, "message": "secondary feed not attached"}
    deviation = abs(price - ref_price) / price * 100.0
    spread_pct = ((ask - bid) / ref_price * 100.0) if ask > bid and ref_price > 0 else None
    max_dev = safe_float(getattr(settings, "max_cross_feed_price_deviation_pct", 0.20), 0.20)
    spread_warn = safe_float(getattr(settings, "alpaca_spread_warning_pct", 0.25), 0.25)
    ok = deviation <= max_dev and (spread_pct is None or spread_pct <= spread_warn)
    risk = "LOW" if ok else ("HIGH" if deviation > max_dev * 2 else "MEDIUM")
    return {"enabled": bool(getattr(settings, "use_alpaca_cross_feed_validation", True)), "available": True, "risk_level": risk, "price_deviation_pct": round(deviation, 6), "spread_pct": round(spread_pct, 6) if spread_pct is not None else None, "ok": ok, "message": "cross-feed validation passed" if ok else "cross-feed disagreement/spread warning"}


def derive_model_confidence(metrics: dict[str, Any], settings: Any | None = None) -> dict[str, Any]:
    chart = metrics.get("chart_confirmation") or derive_chart_confirmation(metrics, settings)
    liquidity = metrics.get("liquidity_tier") or derive_liquidity_tier(metrics, settings)
    news = metrics.get("news_risk") or derive_news_risk(metrics, settings)
    cross = metrics.get("cross_feed_validation") or derive_cross_feed_validation(metrics, settings)
    micro = metrics.get("binance_microstructure") or {}
    micro_ok = bool(micro.get("execution_quality_ok", True))

    penalties = 0.0
    if not micro_ok:
        penalties += 14
    if news.get("security_issue"):
        penalties += safe_float(getattr(settings, "negative_news_penalty", 8), 8)
    if cross.get("available") and not cross.get("ok", True):
        penalties += safe_float(getattr(settings, "cross_feed_disagreement_penalty", 7), 7)
    if liquidity.get("tier") == "thin":
        penalties += safe_float(getattr(settings, "unknown_microcap_risk_penalty", 6), 6)

    base = 50.0
    base += min(18.0, safe_float(liquidity.get("score")) / 6.0)
    base += 8.0 if micro_ok else -6.0
    base += safe_float(news.get("positive_bonus"), 0)
    base -= penalties
    score = clamp(base)
    if score >= 75:
        level = "HIGH"
    elif score >= 58:
        level = "MEDIUM"
    else:
        level = "LOW"
    return {"enabled": True, "score": round(score, 2), "level": level, "components": {"chart_confirmation": chart, "liquidity_tier": liquidity, "news_risk": news, "cross_feed_validation": cross, "binance_microstructure_ok": micro_ok}, "penalties": round(penalties, 2)}
