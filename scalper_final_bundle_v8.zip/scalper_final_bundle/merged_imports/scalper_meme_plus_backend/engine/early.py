from __future__ import annotations

from typing import Any

from .indicators import candle_change, clamp, cvd_proxy, pct_change, quote_volume_spike, rsi, safe_float, taker_sell_pressure_from_klines, vwap

MEME_HINTS = {
    "DOGE", "SHIB", "PEPE", "1000PEPE", "BONK", "1000BONK", "FLOKI", "1000FLOKI", "WIF", "BOME",
    "TURBO", "MEW", "NEIRO", "MOG", "BRETT", "POPCAT", "PNUT", "GOAT", "ACT", "MOODENG", "SLERF",
    "WEN", "CATS", "HMSTR", "PUMP", "MEME", "DOG", "CAT", "WHY", "CHEEMS", "BABYDOGE",
}


def _base_asset(symbol: str) -> str:
    s = symbol.upper().replace("USDT", "")
    if s.startswith("1000"):
        s2 = s[4:]
        return s if s in MEME_HINTS else s2
    return s


def _wick_ratios(last: dict[str, Any]) -> tuple[float, float, float]:
    high = safe_float(last.get("high"))
    low = safe_float(last.get("low"))
    open_ = safe_float(last.get("open"))
    close = safe_float(last.get("close"))
    rng = max(high - low, 0.0)
    if rng <= 0:
        return 0.0, 0.0, 0.0
    upper = (high - max(open_, close)) / rng
    lower = (min(open_, close) - low) / rng
    body = abs(close - open_) / rng
    return upper, lower, body


def _add(cond: bool, points: float, text: str, score: float, reasons: list[str]) -> float:
    if cond:
        reasons.append(text)
        return score + points
    return score


def compute_early_warning(metrics: dict[str, Any], k1m: list[dict[str, Any]], k5: list[dict[str, Any]], settings: Any) -> dict[str, Any]:
    """Compute an early pump/dump warning layer without replacing the existing scalper score.

    This layer is intentionally independent from the classic SHORT/LONG score. It watches 1m pressure,
    taker flow, CVD, wick behavior and execution quality. It never invents missing data.
    """
    symbol = str(metrics.get("symbol", ""))
    asset = _base_asset(symbol)
    is_meme = asset in MEME_HINTS or any(h in asset for h in ("DOG", "CAT", "PEPE", "BONK", "SHIB", "FLOKI"))
    last1 = k1m[-1] if k1m else (k5[-1] if k5 else {})
    ref = k1m if len(k1m) >= 20 else k5

    change_1m = candle_change(ref, 1)
    change_3m = candle_change(ref, 3)
    change_5m = candle_change(k5, 1) if k5 else candle_change(ref, 5)
    vspike_1m = quote_volume_spike(ref, 40)
    cvd = cvd_proxy(ref, 60) if ref else None
    taker_sell = taker_sell_pressure_from_klines(ref, 12) if ref else None
    taker_buy = 1.0 - taker_sell if taker_sell is not None else None
    vwap_fast = vwap(ref, 60) if ref else 0.0
    price = safe_float(metrics.get("price"))
    rsi_fast = rsi([safe_float(k.get("close")) for k in ref], 14) if ref else 50.0
    upper_wick, lower_wick, body_ratio = _wick_ratios(last1)
    spread = safe_float(metrics.get("spread_pct"), 999.0)
    depth = safe_float(metrics.get("depth_1pct_usd"), 0.0)
    depth_gate = safe_float(metrics.get("min_depth_1pct_usd_gate"), safe_float(getattr(settings, "min_depth_1pct_usd", 0)))
    spread_gate = safe_float(metrics.get("max_spread_pct_gate"), safe_float(getattr(settings, "max_spread_pct", 0.25)))
    qv24 = safe_float(metrics.get("quote_volume_24h"))
    market = metrics.get("market_context") or {}

    # 1. Dynamic Volatility Adaptation
    atr_5m = safe_float(metrics.get("atr_5m"), 0.0)
    volatility_pct = (atr_5m / price * 100.0) if price > 0 else 0.05
    if volatility_pct <= 0:
        volatility_pct = 0.05
    dynamic_1m_th = clamp(volatility_pct * 0.45, 0.15, 0.85)
    dynamic_3m_th = clamp(volatility_pct * 1.05, 0.35, 1.85)

    pump_reasons: list[str] = []
    dump_reasons: list[str] = []
    trap_reasons: list[str] = []
    warnings: list[str] = []

    pump = 0.0
    dump = 0.0
    pump = _add(change_1m >= dynamic_1m_th, 11, f"شتاب مثبت ۱m (پویا: {dynamic_1m_th:.2f}%)", pump, pump_reasons)
    pump = _add(change_3m >= dynamic_3m_th, 11, f"مومنتوم مثبت ۳m (پویا: {dynamic_3m_th:.2f}%)", pump, pump_reasons)
    pump = _add(vspike_1m >= safe_float(getattr(settings, "early_volume_spike", 1.55)), 13, "اسپایک حجم ۱m", pump, pump_reasons)
    pump = _add(vspike_1m >= 3.0, 6, "جهش حجم فوق‌العاده ۱m", pump, pump_reasons)
    pump = _add(taker_buy is not None and taker_buy >= 0.58, 13, "Taker Buy غالب", pump, pump_reasons)
    pump = _add(cvd is not None and cvd >= 0.10, 10, "CVD مثبت", pump, pump_reasons)
    pump = _add(price > vwap_fast if vwap_fast else False, 8, "قیمت بالای VWAP سریع", pump, pump_reasons)
    pump = _add(body_ratio >= 0.52 and upper_wick <= 0.38, 7, "کندل بدون ویک بالایی شدید", pump, pump_reasons)
    pump = _add(market.get("bias") == "risk_on", 4, "رژیم کلی بازار Risk-On", pump, pump_reasons)

    dump = _add(change_1m <= -dynamic_1m_th, 11, f"شتاب منفی ۱m (پویا: {dynamic_1m_th:.2f}%)", dump, dump_reasons)
    dump = _add(change_3m <= -dynamic_3m_th, 11, f"مومنتوم منفی ۳m (پویا: {dynamic_3m_th:.2f}%)", dump, dump_reasons)
    dump = _add(vspike_1m >= safe_float(getattr(settings, "early_volume_spike", 1.55)), 13, "اسپایک حجم ۱m", dump, dump_reasons)
    dump = _add(vspike_1m >= 3.0, 6, "جهش حجم فوق‌العاده ۱m", dump, dump_reasons)
    dump = _add(taker_sell is not None and taker_sell >= 0.58, 13, "Taker Sell غالب", dump, dump_reasons)
    dump = _add(cvd is not None and cvd <= -0.10, 10, "CVD منفی", dump, dump_reasons)
    dump = _add(price < vwap_fast if vwap_fast else False, 8, "قیمت زیر VWAP سریع", dump, dump_reasons)
    dump = _add(body_ratio >= 0.52 and lower_wick <= 0.38, 7, "کندل بدون ویک پایینی شدید", dump, dump_reasons)
    dump = _add(market.get("bias") == "risk_off", 4, "رژیم کلی بازار Risk-Off", dump, dump_reasons)

    if is_meme and safe_float(getattr(settings, "meme_mode", True)):
        pump += 5
        dump += 5
        pump_reasons.append("Meme Mode boost")
        dump_reasons.append("Meme Mode boost")

    direction = "PUMP" if pump >= dump else "DUMP"

    trap = 0.0
    if spread > spread_gate:
        trap += 18
        trap_reasons.append("اسپرد بالاتر از حد مجاز")
    if depth_gate and depth < depth_gate:
        trap += 15
        trap_reasons.append("عمق ±1% ناکافی")
    if vspike_1m >= 2.8 and body_ratio <= 0.25:
        trap += 16
        trap_reasons.append("حجم بالا ولی بدنه کندل ضعیف")
    if upper_wick >= 0.58 and change_1m > 0:
        trap += 14
        trap_reasons.append("ویک بالایی شدید؛ احتمال فیک پامپ")
    if lower_wick >= 0.58 and change_1m < 0:
        trap += 14
        trap_reasons.append("ویک پایینی شدید؛ احتمال فیک دامپ")
    
    # CVD 3m divergence
    if cvd is not None and change_3m > 0.5 and cvd < -0.05:
        trap += 14
        trap_reasons.append("واگرایی رشد قیمت با CVD منفی")
    if cvd is not None and change_3m < -0.5 and cvd > 0.05:
        trap += 14
        trap_reasons.append("واگرایی ریزش قیمت با CVD مثبت")

    # CVD 1m divergence (New)
    if cvd is not None and change_1m > dynamic_1m_th and cvd < -0.02:
        trap += 14
        trap_reasons.append("واگرایی شتاب ۱m با CVD منفی")
    if cvd is not None and change_1m < -dynamic_1m_th and cvd > 0.02:
        trap += 14
        trap_reasons.append("واگرایی شتاب ۱m با CVD مثبت")

    # Order Book Wall detection (New)
    ask_bid_imbalance = safe_float(metrics.get("ask_bid_imbalance"), 0.0)
    if direction == "PUMP" and ask_bid_imbalance >= 0.35:
        trap += 15
        trap_reasons.append("دیوار سنگین فروش در دفتر سفارشات (Ask Wall)")
    elif direction == "DUMP" and ask_bid_imbalance <= -0.35:
        trap += 15
        trap_reasons.append("حمایت سنگین خرید در دفتر سفارشات (Bid Wall)")

    if rsi_fast >= 84 and change_3m > 1.2:
        trap += 10
        trap_reasons.append("RSI بسیار کشیده در پامپ")
    if rsi_fast <= 16 and change_3m < -1.2:
        trap += 10
        trap_reasons.append("RSI بسیار کشیده در دامپ")
    if market.get("bias") == "risk_off" and pump >= dump and pump >= 55:
        trap += 7
        trap_reasons.append("پامپ خلاف رژیم Risk-Off")
    if market.get("bias") == "risk_on" and dump > pump and dump >= 55:
        trap += 7
        trap_reasons.append("دامپ خلاف رژیم Risk-On")
    if direction == "PUMP" and market.get("btc_overbought_low_volume"):
        trap += 8
        trap_reasons.append("BTC overbought با حجم زمینه‌ای ضعیف؛ ریسک فیک پامپ بالاتر")
    if direction == "PUMP" and market.get("btc_macd_bearish") and vspike_1m < safe_float(getattr(settings, "btc_overbought_required_volume_spike", 1.7)):
        trap += 6
        trap_reasons.append("MACD زمینه‌ای BTC ضعیف و حجم تأییدکننده کافی نیست")

    execution = 100.0
    if spread_gate:
        execution -= clamp((spread / max(spread_gate, 0.01) - 1.0) * 25.0, 0, 35)
    if depth_gate and depth < depth_gate:
        execution -= clamp((1.0 - depth / max(depth_gate, 1.0)) * 35.0, 0, 35)
    if qv24 < safe_float(metrics.get("min_quote_volume_gate"), 0):
        execution -= 20
    if not metrics.get("data_fresh_ok", True):
        execution -= 25
        warnings.append("داده کندل تازه نیست")
    if not metrics.get("required_sources_ok", True):
        execution -= 25
        warnings.append("یکی از منابع لازم ناقص است")

    move_score = clamp(max(pump, dump))
    trap_score = clamp(trap)
    execution_score = clamp(execution)
    final_score = clamp(move_score * 0.72 + execution_score * 0.18 - trap_score * 0.35)
    watch_th = safe_float(getattr(settings, "early_watch_threshold", 55.0))
    confirm_th = safe_float(getattr(settings, "early_confirm_threshold", 75.0))
    trap_th = safe_float(getattr(settings, "trap_threshold", 65.0))
    if move_score >= watch_th and trap_score >= trap_th:
        level = "TRAP"
    elif move_score >= confirm_th and trap_score < trap_th and execution_score >= 60:
        level = "CONFIRMED"
    elif move_score >= watch_th:
        level = "WATCH"
    else:
        level = "INFO"

    reasons = pump_reasons if direction == "PUMP" else dump_reasons
    return {
        "enabled": bool(getattr(settings, "early_warning_enabled", True)),
        "direction": direction,
        "level": level,
        "move_score": round(move_score, 2),
        "trap_score": round(trap_score, 2),
        "execution_score": round(execution_score, 2),
        "final_score": round(final_score, 2),
        "is_meme": bool(is_meme),
        "change_1m": round(change_1m, 4),
        "change_3m": round(change_3m, 4),
        "change_5m": round(change_5m, 4),
        "volume_spike_1m": round(vspike_1m, 3),
        "taker_buy_ratio": round(taker_buy, 4) if taker_buy is not None else None,
        "taker_sell_ratio": round(taker_sell, 4) if taker_sell is not None else None,
        "cvd_fast": round(cvd, 4) if cvd is not None else None,
        "rsi_fast": round(rsi_fast, 2),
        "upper_wick_ratio": round(upper_wick, 3),
        "lower_wick_ratio": round(lower_wick, 3),
        "body_ratio": round(body_ratio, 3),
        "reasons": reasons[:10],
        "trap_reasons": trap_reasons[:10],
        "warnings": warnings[:8],
    }
