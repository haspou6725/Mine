# Deep Debug Report — v6.6.1

## هدف
بازبینی دقیق نسخه `UI_MAPPING_FIXED`، رفع ایرادهای runtime/UX باقی‌مانده، تست دوباره و آماده‌سازی ZIP تمیز.

## ایرادهای پیدا شده و اصلاح شده

1. **فایل runtime داخل ZIP مانده بود**
   - `data/live_signals.db` داخل بسته وجود داشت و audit را با finding متوسط fail می‌کرد.
   - حذف شد و قبل از بسته‌بندی نهایی، cache و `__pycache__` هم پاک شدند.

2. **Endpoint میکروساختار Binance در شرایط کندی/بلاک بودن شبکه دیر جواب می‌داد**
   - `/api/binance/microstructure?symbol=BTCUSDT` در محیطی که Binance کند/بلاک باشد تا حدود 18 ثانیه منتظر می‌ماند.
   - حالا timeout کوتاه و کنترل‌شده دارد و اگر live probe جواب ندهد، سریع با `live_probe_timeout` یا snapshot fallback برمی‌گردد.
   - این تغییر فقط read-only diagnostic است و هیچ ارتباطی به execution ندارد.

3. **Data Health ممکن بود روی provider کند معطل شود**
   - برای هر source probe محدودیت زمانی اضافه شد.
   - خطای timeout حالا واضح نمایش داده می‌شود: `source probe timed out after 7.0s`.

4. **Version bump**
   - نسخه backend از `6.6.0-multisource-confidence` به `6.6.1-deep-debugged` تغییر کرد تا مشخص باشد این build دیباگ‌شده است.

5. **تست UI mapping تقویت شد**
   - تست جدید اضافه شد که وجود mappingهای کارت سیگنال را چک می‌کند:
     - شمارنده کارت‌ها
     - Binance Microstructure
     - Multi-source Confidence
     - سطح‌های CONFIRMED / EARLY / CAUTION

6. **تست timeout میکروساختار اضافه شد**
   - تست جدید اضافه شد که اگر Binance کند باشد، endpoint سریع timeout کنترل‌شده بدهد و hang نکند.

## تست‌ها

```text
pytest: 42 passed, 1 warning
compileall: OK
project_audit quick: ok=true, high=0, medium=0, low=0
project_audit full: ok=true, high=0, medium=0, low=0
```

## Smoke test

```text
/api/health 200
/api/version 200
/api/settings 200
/api/safety 200
/api/signals 200
/api/skipped 200
/api/multisource/confidence?symbol=BTCUSDT 200
/api/design/system 200
/api/binance/microstructure?symbol=BTCUSDT 200 با timeout کنترل‌شده در صورت کندی شبکه
/api/data-health 200 با timeout واضح برای منابع کند/بلاک‌شده
```

## Safety

- هیچ order endpoint اضافه نشده است.
- هیچ API key معاملاتی اضافه نشده است.
- هیچ route برای اجرای سفارش، پوزیشن واقعی، leverage واقعی یا execution واقعی وجود ندارد.
- خروجی‌ها صرفاً آموزشی/تحلیلی/Simulation هستند.
