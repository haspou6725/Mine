@echo off
SETLOCAL EnableExtensions
SET "REPO_ROOT=%~dp0"
CD /D "%REPO_ROOT%"
SET "PYTHONPATH=%REPO_ROOT%"
SET "VENV_PY=%REPO_ROOT%.venv\Scripts\python.exe"
IF NOT EXIST "%VENV_PY%" (
    echo [ERROR] Virtual environment not found. Run START_ONE_CLICK.bat first.
    PAUSE
    EXIT /B 1
)
"%VENV_PY%" "%REPO_ROOT%tools\project_audit.py" --mode full --output "%REPO_ROOT%reports\project_audit_latest.json"
PAUSE
