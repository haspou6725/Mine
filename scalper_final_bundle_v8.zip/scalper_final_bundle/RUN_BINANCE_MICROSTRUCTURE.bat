@echo off
setlocal
cd /d "%~dp0"
python tools\binance_microstructure_snapshot.py --symbols BTCUSDT ETHUSDT DOGEUSDT
pause
