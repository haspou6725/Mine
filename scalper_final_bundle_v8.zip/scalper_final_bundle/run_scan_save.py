from app.data.binance_futures import scan_symbols
import json

matches = scan_symbols(price_lt=1.0, vol24_gt=100_000.0, limit=500)
with open('scan_results.json','w',encoding='utf-8') as f:
    json.dump(matches, f, ensure_ascii=False, indent=2)
print('WROTE', len(matches), 'matches to scan_results.json')
