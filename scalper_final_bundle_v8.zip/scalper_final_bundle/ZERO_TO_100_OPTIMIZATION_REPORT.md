# Zero-to-100 Optimization Report — Scalper Meme+ v6.4

تاریخ: 2026-07-03

## خلاصه اجرایی

پروژه از روی بستهٔ `scalper_final_bundle_AUDITED_2.zip` بازبینی، تست، سخت‌سازی و دوباره بسته‌بندی شد. هدف این نسخه این بود که خروجی نهایی فقط یک پروژهٔ قابل اجرا نباشد، بلکه لانچر یک‌کلیکی، audit آفلاین، قرارداد ایمنی واضح، تست بیشتر و گزارش نهایی هم داخل خود ZIP باشد.

## نتیجه نهایی

| بخش | وضعیت |
|---|---:|
| ساختار پروژه | PASS |
| FastAPI backend | PASS |
| Frontend static assets | PASS |
| Streamlit dashboard | PASS |
| Backtester / simulator tests | PASS |
| Safety guard برای اجرای سفارش | PASS |
| Audit آفلاین quick/full | PASS |
| Runtime/cache cleanup | PASS |
| ZIP نهایی | آماده تحویل |

## اصلاحات اعمال‌شده

### 1. لانچر یک‌کلیکی واقعی

فایل جدید اضافه شد:

```text
START_ONE_CLICK.bat
```

این فایل:

- venv می‌سازد؛
- dependencyها را با hash-stamp نصب/آپدیت می‌کند؛
- متغیرهای امن `SCALPER_SAFE_MODE=1` و `SCALPER_ORDER_EXECUTION=0` را ست می‌کند؛
- audit آفلاین سریع را اجرا می‌کند؛
- backend و Streamlit را در دو پنجره جدا اجرا می‌کند؛
- آدرس‌های مرورگر را باز می‌کند.

`START.bat` به wrapper تبدیل شد تا پروژه‌های قدیمی که آن را صدا می‌زنند خراب نشوند.

### 2. فایل‌های اجرای جداگانه و عیب‌یابی

اضافه/به‌روزرسانی شد:

- `RUN_BACKEND.bat`
- `RUN_STREAMLIT.bat`
- `RUN_TESTS.bat`
- `RUN_DIAGNOSTIC.bat`

### 3. سخت‌سازی بک‌اند FastAPI

در `merged_imports/scalper_meme_plus_backend/main.py` اضافه شد:

- `APP_VERSION = 6.4.0-zero-to-100-optimized`
- endpoint جدید `/api/safety`
- endpoint جدید `/api/version`
- headerهای امنیتی:
  - `X-Content-Type-Options: nosniff`
  - `X-Frame-Options: DENY`
  - `Referrer-Policy: no-referrer`
  - `Cache-Control: no-store`

### 4. حذف امکان برداشت اشتباه از اجرای سفارش

در `app/execution/executor.py`، کلاس `LiveExecutor` به guard صریح تبدیل شد:

- credentials یا order options قبول نمی‌کند؛
- هرگونه `place_order` همچنان `NotImplementedError` می‌دهد؛
- `PortfolioSimulator` برای simulation باقی ماند.

### 5. بهبود HTTP client داده زنده

در `clients/http.py`:

- cache محدود شد تا رشد بی‌نهایت نداشته باشد؛
- connection limits تنظیم شد؛
- timeout ساختاری شد؛
- JSON decode error به `LiveDataError` خوانا تبدیل شد؛
- retry برای HTTP 429 با `Retry-After` اضافه شد.

### 6. تست‌های جدید

فایل جدید:

```text
tests/test_safety_and_http.py
```

پوشش اضافه‌شده:

- `/api/safety` اعلام کند real order execution غیرفعال است؛
- security headers روی پاسخ‌ها وجود داشته باشد؛
- `LiveExecutor` credentials/order را رد کند؛
- `PortfolioSimulator` همچنان کار کند؛
- cache در HTTP client bounded باشد.

### 7. audit آفلاین خودکار

فایل جدید:

```text
tools/project_audit.py
```

این ابزار بررسی می‌کند:

- فایل‌های ضروری پروژه وجود دارند؛
- فایل runtime/cache/database داخل release نباشد؛
- نشانهٔ credential واقعی یا order execution مشکوک وجود نداشته باشد؛
- تنظیمات پیش‌فرض safe باشند.

خروجی‌های ساخته‌شده:

- `reports/project_audit_latest.json`
- `reports/project_audit_full.json`

### 8. UI و Streamlit به‌روزرسانی شد

- عنوان‌ها به v6.4 تغییر کرد؛
- پیام ایمنی `Simulation Only • No Real Orders` اضافه شد؛
- Dashboard یادآوری می‌کند پروژه آموزشی/تحلیلی است؛
- `scan_interval_sec` در UI با validation بک‌اند هماهنگ شد.

### 9. Documentation نهایی

اضافه/به‌روزرسانی شد:

- `README.md`
- `FINAL_README.md`
- `ZERO_TO_100_OPTIMIZATION_REPORT.md`

## تست‌های اجراشده

```text
python3 -m compileall -q merged_imports app tools tests
python3 -m pytest -q
python3 tools/project_audit.py --mode quick --output reports/project_audit_latest.json
python3 tools/project_audit.py --mode full --output reports/project_audit_full.json
```

نتیجه:

```text
pytest: pending latest test run, 1 warning
project_audit quick: ok=true, high=0, medium=0, low=0
project_audit full : ok=true, high=0, medium=0, low=0
backend smoke: /api/health و /api/safety روی localhost پاسخ 200 دادند
```

## محدودیت باقی‌مانده

در این محیط، live network برای Binance/DEX/CoinGecko به‌صورت تضمینی validate نشده است. کد طوری طراحی شده که اگر منبع live در سیستم مقصد قطع باشد، دادهٔ ساختگی نسازد و خطا/skip ثبت کند. برای تایید کامل بازار زنده باید روی سیستم یا VPS دارای دسترسی به منابع اجرا شود.

## جمع‌بندی ایمنی

- معامله واقعی: ندارد.
- order endpoint: ندارد.
- credentialed exchange-order client: ندارد.
- پوزیشن/اهرم/ریسک: فقط آموزشی و simulation.
- پیش‌فرض اجرا: localhost.

## Update 6.4.1 — Signal tuning and web navigation fix

- Balanced live signal defaults applied: `score_threshold=78`, `min_volume_spike_for_trigger=1.70`, `max_spread_pct=0.22`, `min_depth_1pct_usd=70000`, `early_confirm_threshold=72`, `trap_threshold=62`.
- Web tabs are now hash-aware and browser Back/Forward friendly.
- Added quick `بازگشت به Signals` button.
- CSV export now opens/downloads without replacing the app page.
- `/api/signals` now respects the current saved `score_threshold` when `min_score` is not explicitly provided.

See `SIGNAL_TUNING_AND_UI_FIX_REPORT.md` for details.
