from app.data.binance_futures import scan_symbols
import json

from project_paths import SCAN_RESULTS

out_path = str(SCAN_RESULTS)
matches = scan_symbols(price_lt=1.0, vol24_gt=100_000.0, limit=500)
with open(out_path,'w',encoding='utf-8') as f:
    json.dump(matches, f, ensure_ascii=False, indent=2)
print('WROTE', len(matches), 'matches to', out_path)
