# LONA Trading Assistant Upgrade - Final Report

## انجام‌شده

- Strategy سازگار با LONA/Backtrader ساخته شد.
- LONA Strategy ID: `686df81b-74f0-4cab-abad-c184261165b8`
- فایل کد strategy داخل پروژه اضافه شد: `app/backtest/lona_signal_strategy.py`
- ابزار خروجی دیتاست تحقیقاتی اضافه شد: `tools/export_lona_dataset.py`
- ابزار grid-search / walk-forward اضافه شد: `tools/lona_walk_forward_optimizer.py`
- بازه پارامترهای قابل تست اضافه شد: `data/lona_tuning_config.json`
- فایل‌های اجرای ویندوز اضافه شد:
  - `RUN_LONA_EXPORT.bat`
  - `RUN_LONA_OPTIMIZER.bat`
- راهنمای LONA اضافه شد: `docs/lona/LONA_BACKTEST_GUIDE.md`
- یک باگ بالقوه در Gate مربوط به BTC overbought/low-volume اصلاح و تست شد.

## تست‌ها

```text
pytest: 29 passed, 1 warning
backend smoke: /api/health, /api/settings, /api/signals OK
project_audit quick: ok=true, high=0, medium=0, low=0
project_audit full: ok=true, high=0, medium=0, low=0
```

## نکته مهم

این نسخه عمداً بک‌تست فیک تولید نمی‌کند. اگر دیتاست live فعلاً خالی باشد، خروجی `signals_dataset.csv` هم خالی می‌ماند. بعد از اجرای چند scan واقعی، exporter همان داده‌های واقعی را به CSV تبدیل می‌کند. برای ادعای سوددهی، CSV باید با نتیجه آینده کندل‌ها enrich شود یا Strategy در LONA روی دیتای OHLCV واقعی اجرا شود.

## مسیر پیشنهادی بعدی

1. اجرای چند ساعت/چند روز live scan روی سیستم دارای اینترنت پایدار.
2. اجرای `RUN_LONA_EXPORT.bat`.
3. آپلود CSV/strategy در LONA یا اجرای strategy ساخته‌شده با ID بالا.
4. مقایسه پارامترها بر اساس profit factor، drawdown، win rate، trade count و trap rate.
5. برگشت بهترین پارامترها به `data/settings.json`.
