# Signal Tuning + Web UI Navigation Fix Report

نسخه: `6.4.1-signal-tuned-ui-fixed`

## خلاصه اصلاحات

این مرحله دو بخش اصلی را اصلاح کرد:

1. **بهینه‌سازی عددهای سیگنال** از حالت خیلی سخت‌گیرانه به پروفایل متعادل برای میم‌کوین‌های زیر ۱ دلار.
2. **رفع مشکل برگشت به صفحه Signals در وب** با hash-aware tabs، دکمه برگشت سریع و جلوگیری از خروج ناخواسته از صفحه هنگام CSV.

> نکته: این بهینه‌سازی بر اساس ساختار فعلی موتور، گیت‌های سخت‌گیرانه Live Data، منطق Early Warning و محدودیت عدم وجود دیتاست بک‌تست پرشده در ZIP انجام شد. مسیر اجرای سفارش واقعی همچنان وجود ندارد و پروژه فقط آموزشی/تحلیلی/Simulation است.

## تنظیمات بهینه‌شده سیگنال

| پارامتر | قبل | بعد | دلیل |
|---|---:|---:|---|
| `score_threshold` | 82 | 78 | افزایش تعداد سیگنال قابل‌بررسی بدون حذف Hard Gateها |
| `early_watch_threshold` | 55 | 52 | زودتر دیده‌شدن حرکت‌های اولیه |
| `early_confirm_threshold` | 75 | 72 | تأیید زودهنگام کمی عملی‌تر |
| `trap_threshold` | 65 | 62 | سخت‌گیری بیشتر روی تشخیص Trap |
| `early_volume_spike` | 1.55 | 1.40 | حساسیت بهتر به شروع پامپ/دامپ |
| `min_volume_spike_for_trigger` | 2.0 | 1.70 | کاهش از دست‌دادن سیگنال‌های زودتر |
| `max_spread_pct` | 0.18 | 0.22 | سازگارتر با میم‌کوین‌های کم‌عمق، اما هنوز محدود |
| `min_depth_1pct_usd` | 100,000 | 70,000 | افزایش پوشش نمادهای زیر ۱ دلار |
| `lbank_min_quote_volume` | 300,000 | 250,000 | پوشش بهتر LBank/Inno در صورت فعال‌سازی |
| `lbank_max_spread_pct` | 0.60 | 0.75 | واقع‌بینانه‌تر برای Venue کم‌عمق‌تر |
| `lbank_min_depth_1pct_usd` | 20,000 | 15,000 | کاهش skip بی‌مورد در LBank |
| `max_long_chase_1h_pct` | 6.0 | 7.5 | جلوگیری از حذف لانگ‌های قوی ولی نه بیش‌ازحد کشیده |
| `max_short_chase_1h_pct` | 8.0 | 9.0 | سازگارتر با دامپ‌های سریع میم‌کوین |
| `max_long_rsi_5m` | 72 | 76 | لانگ‌های momentum کمی بیشتر مجاز شدند |
| `min_short_rsi_5m` | 28 | 24 | شورت‌های breakdown کمی بیشتر مجاز شدند |
| `max_stop_distance_pct` | 5.5 | 6.5 | جلوگیری از حذف ستاپ‌های ولتیل اما قابل مدیریت |
| `cooldown_minutes` | 25 | 18 | امکان سیگنال تکراری منطقی‌تر بعد از تغییر ساختار بازار |
| `scan_interval_sec` | 20 | 25 | کاهش فشار API و rate-limit در پروفایل متعادل |
| `concurrent_requests` | 12 | 10 | پایداری بهتر در اجرای واقعی روی اینترنت ضعیف/VPS |

## نکات ایمنی که تغییر نکردند

- `strict_live_data = true`
- `early_confirmed_to_signals = false`
- `rate_limit_safe_mode = true`
- `risk_per_trade_pct = 0.5`
- `leverage = 3`
- هیچ route یا client برای ارسال سفارش واقعی فعال نشده است.

## اصلاح UI وب

- Tabها حالا با hash URL کار می‌کنند: `#signals`, `#watchlist`, `#backtest`, ...
- دکمه «بازگشت به Signals» به نوار بالایی اضافه شد.
- دکمه‌های tab و action به `type="button"` تغییر کردند تا رفتار ناخواسته browser ایجاد نشود.
- Back/Forward مرورگر با تب‌ها هماهنگ شد.
- لینک CSV به شکل download/open-new-tab تغییر کرد تا کاربر از اپ خارج نشود.
- مقدار پیش‌فرض quick backtest از 72 به 78 هماهنگ شد.
- endpoint `/api/signals` اگر `min_score` نگیرد از `scanner.settings.score_threshold` استفاده می‌کند، نه عدد hardcoded قدیمی 82.

## تست‌های اضافه‌شده

- `tests/test_signal_tuning_and_frontend_navigation.py`
  - اعتبارسنجی پروفایل عددی جدید
  - چک static برای hash-aware navigation و دکمه برگشت Signals

## نتیجه تست نهایی

```text
pytest: 25 passed, 1 warning
project_audit quick: ok=true, high=0, medium=0, low=0
project_audit full : ok=true, high=0, medium=0, low=0
backend smoke: /api/health, /api/safety, /api/version, /api/settings, /api/signals پاسخ 200 دادند
```
