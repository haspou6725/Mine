# Starts the Scalper project backend + Streamlit dashboard.
# If dependencies are not installed yet, use START.bat first.

$ProjectRoot = $PSScriptRoot
$VenvPython = Join-Path $ProjectRoot '.venv\Scripts\python.exe'

Write-Host "Project root: $ProjectRoot"

if (-not (Test-Path $VenvPython)) {
    Write-Host '[ERROR] Virtual environment not found.' -ForegroundColor Red
    Write-Host 'Run START.bat first; it creates .venv and installs requirements.'
    exit 1
}

$env:PYTHONPATH = $ProjectRoot

$BackendScript = Join-Path $ProjectRoot 'RUN_BACKEND.bat'
$StreamlitScript = Join-Path $ProjectRoot 'RUN_STREAMLIT.bat'

Start-Process -FilePath 'cmd.exe' -ArgumentList '/k', "call `"$BackendScript`"" -WorkingDirectory $ProjectRoot
Start-Process -FilePath 'cmd.exe' -ArgumentList '/k', "call `"$StreamlitScript`"" -WorkingDirectory $ProjectRoot

Start-Sleep -Seconds 3
Start-Process 'http://127.0.0.1:8787'
Start-Process 'http://127.0.0.1:8501'
