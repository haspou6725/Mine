from app.execution.executor import PortfolioSimulator


def test_portfolio_simulator_buy_sell():
    sim = PortfolioSimulator(cash=1000.0, commission=0.001, slippage=0.0)
    # buy 10% notional at price 10 -> notional 100 -> qty 10
    fill = sim.place_market_order('FOOUSDT', 'buy', notional=100.0, price=10.0)
    assert fill.side.lower() == 'buy'
    assert sim.positions.get('FOOUSDT', 0) > 0
    # sell the position
    sell = sim.place_market_order('FOOUSDT', 'sell', notional=100.0, price=12.0)
    assert sell.side.lower() == 'sell'
    # after selling, position should be zero or reduced
    assert sim.positions.get('FOOUSDT', 0) >= 0
