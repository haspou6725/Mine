from pathlib import Path
import sys
BASE = Path(__file__).resolve().parents[1] if Path(__file__).resolve().parent.name == "tools" else Path(__file__).resolve().parent
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))

import json
from app.data.binance_futures import get_klines
from app.features.indicators import klines_to_df, add_basic_features
from app.strategy.scalper import generate_signals
from app.backtest.simple_backtester import backtest

from project_paths import SCAN_RESULTS, BACKTEST_RESULTS

scan_path = str(SCAN_RESULTS)
with open(scan_path, 'r', encoding='utf-8') as f:
    matches = json.load(f)

symbol = matches[0]['symbol']
print('Backtest symbol:', symbol)
kl = get_klines(symbol, interval='1m', limit=1000)
df = klines_to_df(kl)
df = add_basic_features(df)
df = generate_signals(df, vol_z_threshold=2.0, profit_target=0.02, stop_loss=0.01)
res = backtest(df, initial_capital=1000.0, leverage=1.0, commission=0.0004, slippage=0.0005, position_size_pct=0.1, profit_target=0.02, stop_loss=0.01)
out_path = str(BACKTEST_RESULTS)
with open(out_path, 'w', encoding='utf-8') as f:
    json.dump({'symbol':symbol,'result':res}, f, ensure_ascii=False, indent=2)
print('WROTE backtest results to', out_path)
