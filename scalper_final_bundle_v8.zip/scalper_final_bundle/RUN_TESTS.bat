@echo off
SETLOCAL EnableExtensions
SET "REPO_ROOT=%~dp0"
CD /D "%REPO_ROOT%"
SET "PYTHONPATH=%REPO_ROOT%"
SET "VENV_PY=%REPO_ROOT%.venv\Scripts\python.exe"
IF NOT EXIST "%VENV_PY%" (
    echo [ERROR] Virtual environment not found. Run START_ONE_CLICK.bat first.
    PAUSE
    EXIT /B 1
)
"%VENV_PY%" -m pip install -r requirements-dev.txt
IF ERRORLEVEL 1 EXIT /B 1
"%VENV_PY%" -m compileall -q merged_imports app tools tests
IF ERRORLEVEL 1 EXIT /B 1
"%VENV_PY%" -m pytest -q
PAUSE
