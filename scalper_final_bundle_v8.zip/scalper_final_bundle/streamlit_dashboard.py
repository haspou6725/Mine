import streamlit as st
import httpx
import json
from pathlib import Path
import pandas as pd
import time

st.set_page_config(page_title='Scalper Dashboard', layout='wide')

BACKEND_BASE = 'http://127.0.0.1:8787'
from project_paths import PROJECT_ROOT

FILES_ROOT = PROJECT_ROOT

st.title('Meme-coin Scalper — Dashboard')

col1, col2 = st.columns([2,1])

with col1:
    st.subheader('Live Market Snapshot (Binance Public)')
    symbol = st.text_input('Symbol (e.g. BTCUSDT)', value='BTCUSDT')
    if st.button('Fetch Live Ticker'):
        try:
            r = httpx.get(f'https://fapi.binance.com/fapi/v1/ticker/24hr?symbol={symbol}', timeout=10.0)
            r.raise_for_status()
            data = r.json()
            st.json(data)
        except Exception as e:
            st.error(f'Error fetching ticker: {e}')

    st.subheader('Recent Signals')
    signals_file = FILES_ROOT / 'signals' / 'scan_results_master.json'
    if signals_file.exists():
        try:
            with open(signals_file, 'r', encoding='utf-8') as fh:
                master = json.load(fh)
            df = pd.DataFrame(master)
            if not df.empty:
                # show top signals by score if available
                if 'score' in df.columns:
                    df = df.sort_values('score', ascending=False)
                st.dataframe(df.head(50))
            else:
                st.info('Signals file empty')
        except Exception as e:
            st.error(f'Error reading signals: {e}')
    else:
        st.info('Signals file not found — run scanning/tuning to generate signals')

    st.subheader('Risk Metrics Summary')
    risk_file = FILES_ROOT / 'reports' / 'risk_metrics_summary.json'
    if risk_file.exists():
        try:
            with open(risk_file, 'r', encoding='utf-8') as fh:
                risks = json.load(fh)
            rdf = pd.DataFrame(risks)
            st.dataframe(rdf.sort_values('cagr_note', na_position='first').head(50))
        except Exception as e:
            st.error(f'Error reading risk metrics: {e}')
    else:
        st.info('Risk metrics file not found — run compute_risk_metrics')

with col2:
    st.subheader('Portfolio Snapshot (Simulated)')
    port_file = FILES_ROOT / 'reports' / 'portfolio_simulation.json'
    if port_file.exists():
        try:
            with open(port_file, 'r', encoding='utf-8') as fh:
                port = json.load(fh)
            st.json(port)
        except Exception as e:
            st.error(f'Error reading portfolio: {e}')
    else:
        st.info('Portfolio snapshot not found — run portfolio simulation')

    st.subheader('Backend Health')
    try:
        r = httpx.get(f'{BACKEND_BASE}/api/health', timeout=3.0)
        if r.status_code == 200:
            st.success('Backend reachable')
            st.write(r.json())
        else:
            st.warning(f'Backend responded: {r.status_code}')
    except Exception as e:
        st.error(f'Backend unreachable: {e}')

st.markdown('---')

st.write('Notes: This dashboard is read-only. Live execution is disabled. Ensure backend at http://127.0.0.1:8787 is running before expecting live endpoints.')

# small utility to show latest equity curve for a chosen symbol
st.sidebar.header('Quick Chart')
symbol_choice = st.sidebar.text_input('Symbol for equity chart', value='btcusdt')
if st.sidebar.button('Show equity curve'):
    # load detailed backtest if exists
    candidate = FILES_ROOT / 'backtests_detailed' / f'{symbol_choice.upper()}.json'
    if candidate.exists():
        try:
            with open(candidate, 'r', encoding='utf-8') as fh:
                b = json.load(fh)
            eq = b.get('equity_curve', [])
            if eq:
                df = pd.DataFrame(eq)
                df = df.dropna(subset=['equity']).reset_index(drop=True)
                st.line_chart(df['equity'])
            else:
                st.info('No equity curve in backtest file')
        except Exception as e:
            st.error(f'Error reading backtest file: {e}')
    else:
        st.info('Backtest file not found for symbol')

# small CTA
st.sidebar.markdown('---')
if st.sidebar.button('Refresh data files'):
    st.experimental_rerun()

# footer
st.caption('Dashboard connected to local workspace files. For production, deploy backend and host frontend separately.')
