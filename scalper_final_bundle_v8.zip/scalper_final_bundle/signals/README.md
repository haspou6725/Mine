# Runtime signal outputs

This folder is intentionally empty in the audited package.

- `scan_results_master.json` must contain only final signals that passed hard gates.
- `watchlist_candidates.json` is for candidates only, not trade signals.
- `rejected_candidates.json` is for rejected/skipped candidates with reasons.

Regenerate these files only from a live run after validating data sources.
