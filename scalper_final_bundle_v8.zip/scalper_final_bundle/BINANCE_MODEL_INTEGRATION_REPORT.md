# Binance Model Integration Report

## خلاصه

این نسخه لایه Binance Microstructure را به مدل سیگنال اضافه می‌کند. تمرکز روی کیفیت اجرای زنده، جلوگیری از fake pump، جلوگیری از crowded trade و تشخیص ریسک mark/index premium است.

## تغییرات کد

- `merged_imports/scalper_meme_plus_backend/engine/binance_microstructure.py`
- `app/features/binance_microstructure.py`
- `tools/binance_microstructure_snapshot.py`
- `tools/binance_feature_export.py`
- `data/binance_microstructure_config.json`
- `docs/binance/BINANCE_MICROSTRUCTURE_GUIDE.md`
- `RUN_BINANCE_MICROSTRUCTURE.bat`
- `RUN_BINANCE_FEATURE_EXPORT.bat`

## تغییرات مدل

- Dynamic Spread Threshold
- Dynamic Depth Threshold
- Taker Buy/Sell Pressure
- Open Interest Delta Score
- Funding Crowded Penalty
- Mark/Index Premium Gate
- Binance read-only diagnostic endpoint

## ایمنی

این پروژه همچنان فقط آموزشی/تحلیلی/Simulation است. هیچ مسیر سفارش واقعی، API key معاملاتی، position واقعی یا execution واقعی اضافه نشده است.
