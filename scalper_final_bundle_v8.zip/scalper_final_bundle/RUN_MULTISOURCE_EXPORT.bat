@echo off
setlocal
cd /d "%~dp0"
python tools\multisource_feature_export.py
pause
