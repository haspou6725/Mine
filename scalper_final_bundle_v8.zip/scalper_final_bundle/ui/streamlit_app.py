"""Compatibility wrapper for older launch scripts.
The active Streamlit dashboard is ../streamlit_dashboard_v2.py.
"""
from pathlib import Path
import runpy

runpy.run_path(str(Path(__file__).resolve().parents[1] / "streamlit_dashboard_v2.py"), run_name="__main__")
