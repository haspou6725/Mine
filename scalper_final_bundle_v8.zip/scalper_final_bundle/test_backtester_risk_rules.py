import pandas as pd
from app.backtest.simple_backtester import backtest


def test_stop_loss_and_profit_target_trigger():
    # create scenario where entry occurs and pnl hits profit target
    data = [
        {'open_time': 0, 'open': 100.0, 'signal': 1},
        {'open_time': 60, 'open': 100.0, 'signal': 0},
        {'open_time': 120, 'open': 111.0, 'signal': 0},  # big jump triggers profit
        {'open_time': 180, 'open': 90.0, 'signal': 0},   # would trigger stop if reached
    ]
    df = pd.DataFrame(data)
    res = backtest(df, initial_capital=1000.0, position_size_pct=0.1, profit_target=0.10, stop_loss=0.05)
    trades = res.get('trades', [])
    assert len(trades) >= 1
    # check at least one trade action is EXIT (closed)
    assert any(t.get('action') == 'EXIT' for t in trades)
    # final equity should reflect realized profits or losses
    assert isinstance(res['final_equity'], float)
