from merged_imports.scalper_meme_plus_backend.engine.binance_microstructure import derive_microstructure, dynamic_depth_gate, dynamic_spread_gate
from merged_imports.scalper_meme_plus_backend.engine.scoring import hard_gates, publish_gates_ok
from merged_imports.scalper_meme_plus_backend.models import Settings


def test_dynamic_spread_and_depth_tighten_for_high_volume():
    settings = Settings(max_spread_pct=0.28, min_depth_1pct_usd=45_000)
    low = {"quote_volume_24h": 2_000_000, "max_spread_pct_gate": 0.28, "min_depth_1pct_usd_gate": 45_000}
    high = {"quote_volume_24h": 100_000_000, "max_spread_pct_gate": 0.28, "min_depth_1pct_usd_gate": 45_000}
    assert dynamic_spread_gate(high, settings) < dynamic_spread_gate(low, settings)
    assert dynamic_depth_gate(high, settings) > dynamic_depth_gate(low, settings)


def test_mark_index_premium_gate_blocks_bad_premium():
    settings = Settings(max_mark_index_premium_pct=0.12)
    metrics = {
        "price": 1.0,
        "mark_price": 1.0,
        "index_price": 0.98,
        "spread_pct": 0.01,
        "depth_1pct_usd": 100_000,
        "quote_volume_24h": 10_000_000,
        "min_quote_volume_gate": 100_000,
        "max_spread_pct_gate": 0.28,
        "min_depth_1pct_usd_gate": 45_000,
        "volume_spike": 2.0,
        "quote_volume_spike": 2.0,
        "high_break_5m": True,
        "above_vwap_5m": True,
        "data_fresh_ok": True,
        "required_sources_ok": True,
        "atr_5m": 0.01,
        "change_15m": 2.5,
        "change_1h": 2.0,
        "rsi_5m": 55,
        "market_context": {"bias": "neutral"},
    }
    metrics["binance_microstructure"] = derive_microstructure(metrics, settings)
    gates = hard_gates(metrics, settings, "LONG")
    assert gates["mark_index_premium_ok"] is False
    assert publish_gates_ok(gates) is False


def test_taker_flow_soft_gate_does_not_block_publish():
    settings = Settings(min_taker_buy_ratio_for_long=0.55)
    metrics = {
        "price": 1.0,
        "mark_price": 1.0,
        "index_price": 1.0,
        "spread_pct": 0.01,
        "depth_1pct_usd": 100_000,
        "quote_volume_24h": 10_000_000,
        "min_quote_volume_gate": 100_000,
        "max_spread_pct_gate": 0.28,
        "min_depth_1pct_usd_gate": 45_000,
        "volume_spike": 2.0,
        "quote_volume_spike": 2.0,
        "high_break_5m": True,
        "above_vwap_5m": True,
        "data_fresh_ok": True,
        "required_sources_ok": True,
        "atr_5m": 0.01,
        "change_15m": 2.5,
        "change_1h": 2.0,
        "rsi_5m": 55,
        "taker_sell_pressure": 0.60,
        "market_context": {"bias": "neutral"},
    }
    metrics["binance_microstructure"] = derive_microstructure(metrics, settings)
    gates = hard_gates(metrics, settings, "LONG")
    assert gates["taker_flow_ok"] is False
    assert publish_gates_ok(gates) is True


def test_microstructure_context_times_out_fast_without_hanging(tmp_path):
    import asyncio
    import time

    from merged_imports.scalper_meme_plus_backend.services.scanner import ScannerService
    from merged_imports.scalper_meme_plus_backend.services.storage import Storage

    class SlowBinance:
        async def ticker_24h(self):
            await asyncio.sleep(1)
            return []

        async def premium_index(self):
            await asyncio.sleep(1)
            return []

        async def klines(self, symbol, interval, limit):
            await asyncio.sleep(1)
            return []

        async def depth(self, symbol, limit):
            await asyncio.sleep(1)
            return {}

        async def open_interest_hist(self, symbol, period, limit):
            await asyncio.sleep(1)
            return []

        async def taker_buy_sell_volume(self, symbol, period, limit):
            await asyncio.sleep(1)
            return []

    service = ScannerService(Storage(tmp_path / "signals.db"))
    service._binance = SlowBinance()
    service._microstructure_timeout_sec = 0.01

    started = time.perf_counter()
    result = asyncio.run(service.binance_microstructure_context("BTCUSDT"))
    elapsed = time.perf_counter() - started

    assert elapsed < 0.5
    assert result["ok"] is False
    assert result["fallback"] is False
    assert result["fallback_reason"] == "live_probe_timeout"
