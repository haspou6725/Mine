from __future__ import annotations

from merged_imports.scalper_meme_plus_backend.engine.early import compute_early_warning
from merged_imports.scalper_meme_plus_backend.engine.risk import build_trade_plan
from merged_imports.scalper_meme_plus_backend.engine.scoring import hard_gates, publish_gates_ok
from merged_imports.scalper_meme_plus_backend.models import Settings


def test_hard_gates_reject_missing_live_sources_and_bad_execution():
    settings = Settings()
    metrics = {
        "price": 1.0,
        "price_change_24h": 20,
        "drawdown_from_24h_high_pct": 1,
        "spread_pct": 999,
        "quote_volume_24h": 10,
        "min_quote_volume_gate": settings.min_quote_volume,
        "min_depth_1pct_usd_gate": settings.min_depth_1pct_usd,
        "depth_1pct_usd": 0,
        "volume_spike": 3.0,
        "quote_volume_spike": 3.0,
        "high_break_5m": True,
        "above_vwap_5m": True,
        "rsi_5m": 55,
        "change_15m": 3.0,
        "change_1h": 1.0,
        "atr_5m": 0.01,
        "required_sources_ok": False,
        "data_fresh_ok": False,
        "market_context": {"bias": "risk_on"},
    }
    gates = hard_gates(metrics, settings, "LONG")
    assert gates["live_required_sources_ok"] is False
    assert gates["data_fresh_ok"] is False
    assert gates["liquidity_ok"] is False
    assert gates["execution_spread_ok"] is False
    assert gates["depth_1pct_ok"] is False
    assert not all(gates.values())
    assert publish_gates_ok(gates) is False


def test_soft_context_gates_do_not_block_publish_when_critical_gates_pass():
    gates = {
        "live_required_sources_ok": True,
        "data_fresh_ok": True,
        "price_ok": True,
        "liquidity_ok": True,
        "execution_spread_ok": True,
        "depth_1pct_ok": True,
        "volume_trigger_ok": True,
        "technical_trigger_ok": True,
        "risk_plan_stop_ok": True,
        "market_regime_ok": False,
        "anti_late_chase_ok": False,
        "anti_extreme_chase_ok": True,
    }
    assert all(gates.values()) is False
    assert publish_gates_ok(gates) is True


def test_early_trap_level_blocks_high_trap_scenarios():
    settings = Settings()
    metrics = {
        "symbol": "PEPEUSDT",
        "price": 1.0,
        "atr_5m": 0.02,
        "spread_pct": 5.0,
        "depth_1pct_usd": 1,
        "min_depth_1pct_usd_gate": settings.min_depth_1pct_usd,
        "max_spread_pct_gate": settings.max_spread_pct,
        "quote_volume_24h": 10,
        "min_quote_volume_gate": settings.min_quote_volume,
        "data_fresh_ok": True,
        "required_sources_ok": True,
        "market_context": {"bias": "risk_off"},
        "ask_bid_imbalance": 0.5,
    }
    k1m = []
    price = 1.0
    for i in range(45):
        # Strong last-minute pump with large upper wick + terrible execution -> TRAP, not CONFIRMED.
        is_last = i == 44
        close = price * (1.05 if is_last else 1.0)
        vol = 10_000 if is_last else 1_000
        k1m.append({"open_time": i * 60_000, "open": price, "high": close * 1.08, "low": price * 0.999, "close": close, "volume": vol, "quote_volume": vol * close, "taker_buy_quote_volume": vol * 0.9 * close})
        price = close
    early = compute_early_warning(metrics, k1m, k1m, settings)
    assert early["level"] == "TRAP"
    assert early["trap_score"] >= settings.trap_threshold


def test_risk_plan_never_sends_orders_and_sizes_by_risk():
    plan = build_trade_plan("SHORT", price=10.0, atr_value=0.2, capital=1000.0, risk_pct=0.5, leverage=3)
    assert plan["risk_usdt"] == 5.0
    assert plan["position_qty"] > 0
    assert plan["est_margin_usdt"] > 0
    assert "هیچ سفارشی" in plan["risk_note"]
    assert plan["stop"] > 10.0
    assert plan["tp1"] < 10.0


def test_btc_overbought_low_volume_gate_does_not_raise_name_error():
    settings = Settings()
    metrics = {
        "price": 1.0,
        "price_change_24h": 11,
        "drawdown_from_24h_high_pct": 1,
        "spread_pct": 0.05,
        "quote_volume_24h": settings.min_quote_volume * 2,
        "min_quote_volume_gate": settings.min_quote_volume,
        "max_spread_pct_gate": settings.max_spread_pct,
        "min_depth_1pct_usd_gate": settings.min_depth_1pct_usd,
        "depth_1pct_usd": settings.min_depth_1pct_usd * 2,
        "volume_spike": 1.2,
        "quote_volume_spike": 1.1,
        "high_break_5m": True,
        "above_vwap_5m": True,
        "rsi_5m": 60,
        "change_15m": 3.0,
        "change_1h": 2.0,
        "atr_5m": 0.01,
        "required_sources_ok": True,
        "data_fresh_ok": True,
        "market_context": {"bias": "risk_on", "btc_overbought_low_volume": True},
    }
    gates = hard_gates(metrics, settings, "LONG")
    assert gates["btc_overbought_volume_ok"] is False
    assert isinstance(gates["technical_trigger_ok"], bool)
