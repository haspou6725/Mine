from merged_imports.scalper_meme_plus_backend.engine.multisource_confidence import (
    derive_chart_confirmation,
    derive_cross_feed_validation,
    derive_liquidity_tier,
    derive_model_confidence,
    derive_news_risk,
)
from merged_imports.scalper_meme_plus_backend.engine.scoring import hard_gates, publish_gates_ok, score_long
from merged_imports.scalper_meme_plus_backend.models import Settings


def sample_metrics():
    return {
        "exchange": "binance-futures",
        "symbol": "SOLUSDT",
        "price": 80.0,
        "quote_volume_24h": 120_000_000,
        "depth_1pct_usd": 300_000,
        "spread_pct": 0.02,
        "max_spread_pct_gate": 0.28,
        "min_depth_1pct_usd_gate": 45_000,
        "min_quote_volume_gate": 650_000,
        "volume_spike": 2.0,
        "quote_volume_spike": 2.1,
        "rsi_5m": 58,
        "rsi_15m": 56,
        "change_15m": 2.4,
        "change_1h": 4.0,
        "trend_bullish_15m": True,
        "trend_bullish_1h": True,
        "above_vwap_5m": True,
        "high_break_5m": True,
        "data_fresh_ok": True,
        "required_sources_ok": True,
        "atr_5m": 0.5,
        "mark_price": 80.0,
        "index_price": 80.0,
        "market_context": {"bias": "neutral"},
    }


def test_chart_confirmation_scores_bullish_context():
    chart = derive_chart_confirmation(sample_metrics(), Settings())
    assert chart["long_confirmed"] is True
    assert chart["long_score"] > chart["short_score"]


def test_news_security_issue_can_hard_block_publish():
    settings = Settings(security_issue_hard_block=True)
    metrics = sample_metrics()
    metrics["news_context"] = {"headline": "token exploit and security issue reported"}
    metrics["news_risk"] = derive_news_risk(metrics, settings)
    gates = hard_gates(metrics, settings, "LONG")
    assert gates["news_security_ok"] is False
    assert publish_gates_ok(gates) is False


def test_missing_cross_feed_is_neutral():
    settings = Settings()
    cross = derive_cross_feed_validation(sample_metrics(), settings)
    assert cross["available"] is False
    assert cross["ok"] is True


def test_liquidity_tier_major_asset_bonus_and_confidence():
    settings = Settings()
    metrics = sample_metrics()
    liq = derive_liquidity_tier(metrics, settings)
    conf = derive_model_confidence(metrics, settings)
    assert liq["major_asset"] is True
    assert conf["level"] in {"MEDIUM", "HIGH"}


def test_multisource_adjustment_adds_long_reason():
    settings = Settings()
    metrics = sample_metrics()
    metrics["chart_confirmation"] = derive_chart_confirmation(metrics, settings)
    metrics["liquidity_tier"] = derive_liquidity_tier(metrics, settings)
    metrics["news_risk"] = derive_news_risk(metrics, settings)
    metrics["cross_feed_validation"] = derive_cross_feed_validation(metrics, settings)
    metrics["model_confidence"] = derive_model_confidence(metrics, settings)
    score, reasons, warnings, gates = score_long(metrics, settings)
    assert score > 0
    assert any("chart" in r.lower() or "liquidity" in r.lower() for r in reasons)
    assert gates["chart_confirmation_ok"] is True
