from __future__ import annotations

import csv
import json
import sqlite3
from pathlib import Path

from tools.export_lona_dataset import export_dataset


def test_export_lona_dataset_from_sqlite(tmp_path: Path):
    db_path = tmp_path / "live_signals.db"
    con = sqlite3.connect(db_path)
    con.execute("CREATE TABLE signals(id INTEGER PRIMARY KEY AUTOINCREMENT, payload_json TEXT NOT NULL)")
    con.execute("CREATE TABLE snapshots(symbol TEXT PRIMARY KEY, ts TEXT, payload_json TEXT NOT NULL)")
    con.execute("CREATE TABLE skipped(id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, symbol TEXT, reason TEXT, details_json TEXT NOT NULL)")
    payload = {
        "ts": "2026-01-01T00:00:00Z",
        "symbol": "PEPEUSDT",
        "exchange": "binance-futures",
        "side": "LONG",
        "score": 73,
        "grade": "B",
        "price": 0.0001,
        "metrics": {
            "volume_spike": 2.0,
            "depth_1pct_usd": 50000,
            "rsi_5m": 61,
            "market_context": {"bias": "risk_on", "btc_rsi": 66},
        },
        "plan": {"entry_zone": [0.0001, 0.000101], "stop": 0.000095, "tp1": 0.00011},
    }
    con.execute("INSERT INTO signals(payload_json) VALUES (?)", (json.dumps(payload),))
    con.commit()
    con.close()

    out_path = tmp_path / "dataset.csv"
    export_dataset(db_path, out_path)
    rows = list(csv.DictReader(out_path.open(newline="", encoding="utf-8")))
    assert len(rows) == 1
    assert rows[0]["symbol"] == "PEPEUSDT"
    assert rows[0]["source"] == "signals"
    assert rows[0]["label_ready"] == "False"
    assert (tmp_path / "dataset.meta.json").exists()
