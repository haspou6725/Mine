from __future__ import annotations

import json
from pathlib import Path

from merged_imports.scalper_meme_plus_backend.models import Settings

ROOT = Path(__file__).resolve().parents[1]


def test_balanced_signal_defaults_are_applied_and_validated():
    settings_data = json.loads((ROOT / "data" / "settings.json").read_text(encoding="utf-8"))
    settings = Settings(**settings_data)

    assert settings.score_threshold == 72.0
    assert settings.early_watch_threshold == 50.0
    assert settings.early_confirm_threshold == 66.0
    assert settings.trap_threshold == 68.0
    assert settings.min_volume_spike_for_trigger == 1.45
    assert settings.early_volume_spike == 1.25
    assert settings.max_spread_pct == 0.28
    assert settings.min_depth_1pct_usd == 45_000.0
    assert settings.cooldown_minutes == 20
    assert settings.strict_live_data is True
    assert settings.early_confirmed_to_signals is True
    assert settings.require_open_interest is False
    assert settings.require_taker_flow is False
    assert settings.require_funding is False
    assert settings.risk_per_trade_pct <= 0.5
    assert settings.leverage <= 3
    assert settings.max_long_chase_1h_pct == 5.5
    assert settings.max_short_chase_1h_pct == 8.5
    assert settings.max_long_rsi_5m == 74.0
    assert settings.min_short_rsi_5m == 26.0
    assert settings.btc_overbought_rsi == 70.0
    assert settings.btc_overbought_required_volume_spike == 1.70
    assert settings.hard_block_long_if_1h_move_above == 12.0


def test_frontend_tabs_are_hash_aware_and_have_signal_return_button():
    html = (ROOT / "merged_frontend" / "index.html").read_text(encoding="utf-8")
    js = (ROOT / "merged_frontend" / "app.js").read_text(encoding="utf-8")

    assert 'id="goSignals"' in html
    assert 'download="live_crash_signals.csv"' in html
    assert 'type="button" data-tab="signals"' in html
    assert "history.pushState({tab: next}" in js
    assert "window.addEventListener('popstate'" in js
    assert "window.addEventListener('hashchange'" in js
    assert "$('goSignals').onclick = () => setTab('signals');" in js


def test_frontend_signal_count_and_source_mapping_are_present():
    js = (ROOT / "merged_frontend" / "app.js").read_text(encoding="utf-8")

    assert "visibleSignalCount = rows.length" in js
    assert "setText(SIGNAL_COUNT, visibleSignalCount)" in js
    assert "microstructureHtml(s.metrics)" in js
    assert "modelConfidenceHtml(s.metrics)" in js
    assert "dynamic_spread_gate_pct" in js
    assert "dynamic_depth_gate_usdt" in js
    assert "model_confidence" in js
    assert "CAUTION / WATCH ONLY" in js
    assert "EARLY SIGNAL" in js
    assert "CONFIRMED SIGNAL" in js
