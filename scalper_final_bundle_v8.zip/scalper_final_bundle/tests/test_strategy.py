from app.features.indicators import klines_to_df, add_basic_features
from app.strategy.scalper import generate_signals


def test_generate_signals_basic():
    # prepare a df where ema9 crosses above ema21
    klines = []
    base = 1.0
    for i in range(30):
        o = base
        c = base + (i * 0.001)
        klines.append([1620000000000 + i*60000, str(o), str(o+0.001), str(o-0.001), str(c), '10', 1620000000000 + i*60000 + 59999, '10', 1, '0', '0', '0'])
    df = klines_to_df(klines)
    df2 = add_basic_features(df)
    out = generate_signals(df2, vol_z_threshold=-999)  # low threshold to force entries by ema cross
    assert 'signal' in out.columns
