from __future__ import annotations

import sqlite3
from pathlib import Path

from fastapi.testclient import TestClient

import merged_imports.scalper_meme_plus_backend.main as main_module
from merged_imports.scalper_meme_plus_backend.services.storage import Storage
from merged_imports.scalper_meme_plus_backend.timeutil import utc_now


def test_bad_inputs_return_structured_json_without_500(monkeypatch):
    async def fake_backtest(symbol: str, threshold: float, side: str = "SHORT"):
        return {"ok": True, "symbol": symbol, "threshold": threshold, "side": side, "hits": 0, "rows": []}

    monkeypatch.setattr(main_module.scanner, "quick_backtest", fake_backtest)
    client = TestClient(main_module.app, raise_server_exceptions=False)

    cases = [
        ("GET", "/api/signals?side=BAD", None, 400),
        ("GET", "/api/signals?limit=0", None, 422),
        ("GET", "/api/backtest/BTCUSDT?side=BAD", None, 400),
        ("GET", "/api/backtest/!!!", None, 400),
        ("POST", "/api/settings", {"score_threshold": 0}, 422),
        ("POST", "/api/settings", {"prefer_side": "BAD"}, 422),
        ("POST", "/api/settings", {"concurrent_requests": 13}, 422),
        ("POST", "/api/settings", {"scan_interval_sec": 19}, 422),
        ("POST", "/api/settings", {"leverage": 999}, 422),
    ]
    for method, url, payload, expected in cases:
        response = client.request(method, url, json=payload)
        assert response.status_code == expected
        body = response.json()
        assert body["ok"] is False
        assert "error" in body
        assert response.status_code < 500


def test_invalid_json_body_is_structured_422():
    client = TestClient(main_module.app, raise_server_exceptions=False)
    response = client.post("/api/settings", data="{bad", headers={"content-type": "application/json"})
    assert response.status_code == 422
    assert response.json()["ok"] is False
    assert response.json()["error"] == "validation_error"


def test_storage_skips_corrupted_payload_rows(tmp_path: Path):
    db_path = tmp_path / "signals.db"
    storage = Storage(db_path)
    signal = {
        "ts": utc_now(),
        "symbol": "BTCUSDT",
        "side": "LONG",
        "score": 90.0,
        "grade": "A+",
        "price": 100.0,
        "quote_volume_24h": 1_000_000,
        "price_change_24h": 3.0,
        "reasons": [],
        "warnings": [],
        "hard_gates": {},
        "plan": {},
        "metrics": {},
        "sources": {},
    }
    storage.insert_signal(signal)
    with sqlite3.connect(db_path) as db:
        db.execute(
            "INSERT INTO signals(ts, symbol, side, score, grade, price, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (utc_now(), "BADUSDT", "LONG", 99, "A+", 1.0, "{broken-json"),
        )
        db.execute("INSERT INTO skipped(ts, symbol, reason, details_json) VALUES (?, ?, ?, ?)", (utc_now(), "BADUSDT", "bad", "{broken-json"))
        db.commit()

    signals = storage.list_signals(limit=10)
    assert len(signals) == 1
    assert signals[0]["symbol"] == "BTCUSDT"
    skips = storage.latest_skips(limit=10)
    assert any(row["details"].get("corrupt_payload") is True for row in skips)


def test_default_signals_view_includes_early_confirmed_signals(monkeypatch, tmp_path: Path):
    """Early-confirmed signals must not be inserted and then hidden by score_threshold.

    The default UI calls /api/signals without min_score.  When early-to-signal mode is enabled,
    valid confirmed early warnings can score between early_confirm_threshold and score_threshold;
    those rows must remain visible in Signals.
    """
    temp_storage = Storage(tmp_path / "signals.db")
    monkeypatch.setattr(main_module, "storage", temp_storage)
    monkeypatch.setattr(main_module.scanner.settings, "score_threshold", 72.0)
    monkeypatch.setattr(main_module.scanner.settings, "early_confirm_threshold", 66.0)
    monkeypatch.setattr(main_module.scanner.settings, "early_warning_enabled", True)
    monkeypatch.setattr(main_module.scanner.settings, "early_confirmed_to_signals", True)

    temp_storage.insert_signal({
        "ts": utc_now(),
        "symbol": "TESTUSDT",
        "exchange": "binance-futures",
        "side": "LONG",
        "score": 66.0,
        "grade": "C",
        "price": 1.0,
        "quote_volume_24h": 1_000_000,
        "price_change_24h": 5.0,
        "reasons": ["Early PUMP CONFIRMED"],
        "warnings": [],
        "hard_gates": {"early_score_ok": True},
        "plan": {},
        "metrics": {},
        "sources": {},
    })

    client = TestClient(main_module.app, raise_server_exceptions=False)
    body = client.get("/api/signals").json()
    assert [row["symbol"] for row in body["rows"]] == ["TESTUSDT"]
