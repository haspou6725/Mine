from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from app.data.financial_datasets_client import normalize_ohlcv_rows, to_fd_ticker, write_ohlcv_csv
from app.features.market_regime import add_market_regime_features, latest_regime_summary
from tools.fd_build_feature_dataset import build_dataset
from tools.fd_walk_forward_optimizer import walk_forward


def test_fd_ticker_conversion_and_normalization(tmp_path: Path):
    assert to_fd_ticker("BTCUSDT") == "BTC-USD"
    assert to_fd_ticker("ETH-USD") == "ETH-USD"
    rows = normalize_ohlcv_rows({"prices": [{"date": "2026-01-01", "open": 1, "high": 2, "low": 0.5, "close": 1.5, "volume": 100}]})
    assert rows[0]["timestamp"] == "2026-01-01"
    assert rows[0]["close"] == 1.5
    path = write_ohlcv_csv(rows, tmp_path / "ohlcv.csv")
    assert path.exists()


def test_market_regime_features_are_generated():
    df = pd.DataFrame({
        "timestamp": pd.date_range("2026-01-01", periods=80, freq="D"),
        "open": [100 + i for i in range(80)],
        "high": [101 + i for i in range(80)],
        "low": [99 + i for i in range(80)],
        "close": [100 + i for i in range(80)],
        "volume": [1000 + i for i in range(80)],
    })
    out = add_market_regime_features(df)
    assert "rsi_14" in out.columns
    assert "macd_hist" in out.columns
    summary = latest_regime_summary(df)
    assert summary["ok"] is True
    assert isinstance(summary["trend_up"], bool)


def test_feature_dataset_and_walk_forward(tmp_path: Path):
    source = tmp_path / "ohlcv.csv"
    df = pd.DataFrame({
        "timestamp": pd.date_range("2026-01-01", periods=120, freq="min"),
        "open": [1 + i * 0.001 for i in range(120)],
        "high": [1.002 + i * 0.001 for i in range(120)],
        "low": [0.998 + i * 0.001 for i in range(120)],
        "close": [1 + i * 0.001 for i in range(120)],
        "volume": [1000 + (i % 7) * 100 for i in range(120)],
    })
    df.to_csv(source, index=False)
    out_csv = tmp_path / "features.csv"
    built = build_dataset(source, out_csv, symbol="TESTUSDT", horizon_bars=5)
    assert out_csv.exists()
    assert "label_win" in built.columns
    results = walk_forward(built)
    assert results
    assert "params" in results[0]
