from app.backtest.simple_backtester import backtest
from app.features.indicators import klines_to_df, add_basic_features


def test_backtester_no_trades():
    # create flat series with no signals
    klines = []
    for i in range(50):
        klines.append([1620000000000 + i*60000, '1', '1', '1', '1', '0', 1620000000000 + i*60000 + 59999, '0', 0, '0', '0', '0'])
    df = klines_to_df(klines)
    df2 = add_basic_features(df)
    # no signals column -> backtest should run and return final_equity == initial
    res = backtest(df2, initial_capital=1000.0)
    assert res['final_equity'] == 1000.0
