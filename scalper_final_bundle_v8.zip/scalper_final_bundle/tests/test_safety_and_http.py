from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

import merged_imports.scalper_meme_plus_backend.main as main_module
from app.execution.executor import LiveExecutor, PortfolioSimulator
from merged_imports.scalper_meme_plus_backend.clients.http import LiveHTTPClient


def test_safety_endpoint_declares_no_order_execution():
    client = TestClient(main_module.app, raise_server_exceptions=False)
    response = client.get("/api/safety")
    assert response.status_code == 200
    body = response.json()
    assert body["ok"] is True
    assert body["real_order_execution_enabled"] is False
    assert body["execution_endpoints"] == []
    assert body["order_routes"] == "absent"


def test_security_headers_are_present():
    client = TestClient(main_module.app, raise_server_exceptions=False)
    response = client.get("/api/health")
    assert response.headers["x-content-type-options"] == "nosniff"
    assert response.headers["x-frame-options"] == "DENY"
    assert response.headers["cache-control"] == "no-store"


def test_live_executor_refuses_credentials_and_orders():
    with pytest.raises(RuntimeError):
        LiveExecutor("anything")
    executor = LiveExecutor()
    with pytest.raises(NotImplementedError):
        executor.place_order("BTCUSDT", "BUY", 1)


def test_portfolio_simulator_is_still_available():
    sim = PortfolioSimulator(cash=1000.0)
    fill = sim.place_market_order("BTCUSDT", "buy", notional=50, price=100)
    assert fill.qty > 0
    assert sim.cash < 1000


def test_http_cache_is_bounded_without_network_calls():
    client = LiveHTTPClient("https://example.invalid", "test", max_cache_items=2)
    client._remember_cache("a", {"a": 1})
    client._remember_cache("b", {"b": 1})
    client._remember_cache("c", {"c": 1})
    assert len(client._cache) == 2
    assert "c" in client._cache
