import pandas as pd
from app.features.indicators import klines_to_df, add_basic_features


def test_klines_to_df_and_features():
    # minimal synthetic klines: 3 candles
    klines = [
        [1620000000000, '1', '1.1', '0.9', '1.0', '10', 1620000059999, '10', 5, '0', '0', '0'],
        [1620000060000, '1.0', '1.2', '0.95', '1.1', '12', 1620000119999, '13.2', 6, '0', '0', '0'],
        [1620000120000, '1.1', '1.3', '1.05', '1.2', '14', 1620000179999, '16.8', 7, '0', '0', '0']
    ]
    df = klines_to_df(klines)
    assert 'close' in df.columns
    df2 = add_basic_features(df)
    assert 'close_ema_9' in df2.columns
    assert not df2['close_ema_9'].isnull().all()
