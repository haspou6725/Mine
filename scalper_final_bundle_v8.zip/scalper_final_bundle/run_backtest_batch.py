from pathlib import Path
import sys
BASE = Path(__file__).resolve().parents[1] if Path(__file__).resolve().parent.name == "tools" else Path(__file__).resolve().parent
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))

import json
from app.data.binance_futures import get_klines
from app.features.indicators import klines_to_df, add_basic_features
from app.strategy.scalper import generate_signals
from app.backtest.simple_backtester import backtest

from project_paths import SCAN_RESULTS, BACKTEST_BATCH

scan_path = str(SCAN_RESULTS)
with open(scan_path, 'r', encoding='utf-8') as f:
    matches = json.load(f)

results = []
for m in matches[:20]:
    symbol = m['symbol']
    try:
        kl = get_klines(symbol, interval='1m', limit=500)
        df = klines_to_df(kl)
        df = add_basic_features(df)
        df = generate_signals(df, vol_z_threshold=1.5, profit_target=0.02, stop_loss=0.01)
        res = backtest(df, initial_capital=1000.0, position_size_pct=0.1, profit_target=0.02, stop_loss=0.01)
        results.append({'symbol':symbol, 'final_equity':res['final_equity'], 'trades':len(res['trades'])})
    except Exception as e:
        results.append({'symbol':symbol, 'error':str(e)})

out_path = str(BACKTEST_BATCH)
with open(out_path, 'w', encoding='utf-8') as f:
    json.dump(results, f, ensure_ascii=False, indent=2)
print('WROTE batch backtest to', out_path)
