@echo off
setlocal
cd /d "%~dp0"
if not exist .venv (
  py -3 -m venv .venv
)
call .venv\Scripts\activate.bat
python -m pip install -r requirements.txt -r requirements-financial-datasets.txt
set DATA=data\financial_datasets\BTC-USD_day_2026-01-01_2026-07-01.csv
python tools\fd_fetch_ohlcv.py --symbol BTCUSDT --interval day --start 2026-01-01 --end 2026-07-01 --out %DATA%
python tools\fd_build_feature_dataset.py --ohlcv %DATA% --symbol BTCUSDT --out data\financial_datasets\feature_dataset.csv
python tools\fd_benchmark_report.py --dataset data\financial_datasets\feature_dataset.csv
python tools\fd_walk_forward_optimizer.py --dataset data\financial_datasets\feature_dataset.csv
pause
