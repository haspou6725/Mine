import pandas as pd
from app.backtest.simple_backtester import backtest


def test_entry_at_next_candle():
    # signal at index 0 should execute at next candle open (index 1 price)
    data = [
        {'open_time': 0, 'open': 100.0, 'signal': 1},
        {'open_time': 60, 'open': 105.0, 'signal': 0},
        {'open_time': 120, 'open': 110.0, 'signal': 0},
    ]
    df = pd.DataFrame(data)
    res = backtest(df, initial_capital=1000.0, position_size_pct=0.1, profit_target=0.1, stop_loss=0.05)
    trades = res.get('trades', [])
    # expect one ENTRY at price 105 (next candle open)
    assert len(trades) >= 1
    buy = trades[0]
    assert buy.get('action') == 'ENTRY'
    # backtester applies slippage (price * (1+slippage)) for long fills by default
    expected_fill = 105.0 * (1 + 0.0005)
    assert abs(buy.get('price') - expected_fill) < 1e-8
    assert res['final_equity'] >= 1000.0
