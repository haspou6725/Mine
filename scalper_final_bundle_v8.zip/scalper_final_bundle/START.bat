@echo off
REM Compatibility wrapper. The primary one-click launcher is START_ONE_CLICK.bat.
call "%~dp0START_ONE_CLICK.bat"
